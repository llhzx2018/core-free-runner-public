#!/usr/bin/env bash
set -Eeuo pipefail

INSTALL_DIR="${P07_INSTALL_DIR:-/opt/vf-server-ops}"
PREVIOUS_DIR="${P07_PREVIOUS_DIR:-/opt/vf-server-ops.previous}"
BIN_LINK="${P07_BIN_LINK:-/usr/local/bin/vfops}"
PUBLIC_ROOT="${P07_PUBLIC_ROOT:-https://raw.githubusercontent.com/llhzx2018/core-free-runner-public/main}"

BASE_URL="${PUBLIC_ROOT}/dist/p07/0.1.0-rc2"
BASE_PACKAGE="P07_VF_SERVER_OPS_0.1.0-rc2.tar.gz"
BASE_SHA256="de28a5e9dada500357be725e78e9e5cbacd51d26f1ec9bbb55ff92d21d49ada5"
RUNTIME_URL="${PUBLIC_ROOT}/dist/p07/0.1.0/overlay"
RUNTIME_MANIFEST_BLOB="f57e114e0ef23f73a1ec12ba864d8f2e67a5bd30"

EXPECTED_VERSION="VF Server Ops 0.1.0"
EXPECTED_BUILD_ID="0.1.0-release135"

say() { printf '\n[服务器工具箱] %s\n' "$*"; }
fail() { printf '\n[服务器工具箱] 错误：%s\n' "$*" >&2; exit 1; }

verify_git_blob() {
  local file="$1" expected="$2"
  python3 - "$file" "$expected" <<'PY'
import hashlib,sys
path,expected=sys.argv[1:]
data=open(path,'rb').read()
actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
if actual != expected:
    print(f'文件身份不匹配：{path}', file=sys.stderr)
    raise SystemExit(1)
PY
}

verify_tree_from_manifest() {
  local root="$1" manifest="$2" expected path
  while read -r expected path; do
    [[ -n "$expected" && -n "$path" ]] || continue
    [[ -f "$root/$path" ]] || return 1
    verify_git_blob "$root/$path" "$expected" >/dev/null 2>&1 || return 1
  done < "$manifest"
}

verify_installed_current() {
  [[ -x "$BIN_LINK" ]] || return 1
  [[ -f "$INSTALL_DIR/.runtime-manifest.gitblob" ]] || return 1
  verify_git_blob "$INSTALL_DIR/.runtime-manifest.gitblob" "$RUNTIME_MANIFEST_BLOB" >/dev/null 2>&1 || return 1
  [[ "$(NO_COLOR=1 "$BIN_LINK" --version 2>/dev/null || true)" == "$EXPECTED_VERSION" ]] || return 1
  [[ "$(NO_COLOR=1 "$BIN_LINK" --build-id 2>/dev/null || true)" == "$EXPECTED_BUILD_ID" ]] || return 1
  verify_tree_from_manifest "$INSTALL_DIR" "$INSTALL_DIR/.runtime-manifest.gitblob"
}

# P07-M03 网站与数据: before ANY upgrade of an existing runtime, prove
# its own on-disk manifest, paths and build identity are self-consistent.
# An unknown/corrupt or symlinked directory is never displaced or renamed.
# No site/DB/SQLite/config/DNS content is opened or migrated here.
verify_existing_module_before_upgrade() {
  local root="$INSTALL_DIR"
  [[ -d "$root" && ! -L "$root" &&
     -f "$root/BUILD_ID" && ! -L "$root/BUILD_ID" &&
     -f "$root/.runtime-manifest.gitblob" &&
     ! -L "$root/.runtime-manifest.gitblob" &&
     -f "$root/bin/vfops-user" && ! -L "$root/bin/vfops-user" &&
     -L "$BIN_LINK" ]] || return 1
  [[ "$(readlink "$BIN_LINK" 2>/dev/null || true)" == "$root/bin/vfops-user" ]] || return 1
  python3 -B - "$root" <<'PY'
import hashlib
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
try:
    build = (root / "BUILD_ID").read_text(encoding="utf-8").strip()
    if re.fullmatch(r"0\.1\.0-release[0-9]+", build) is None:
        raise ValueError("foreign M03 build")
    rows = (root / ".runtime-manifest.gitblob").read_text(encoding="utf-8").splitlines()
    if not 50 <= len(rows) <= 240:
        raise ValueError("unknown M03 manifest size")
    seen = set()
    for row in rows:
        item = re.fullmatch(
            r"([a-f0-9]{40})  ((?:bin|lib)/[A-Za-z0-9_./-]+|BUILD_ID)", row
        )
        if item is None:
            raise ValueError("unexpected M03 manifest item")
        sha, name = item.groups()
        parts = pathlib.PurePosixPath(name).parts
        if ".." in parts or name in seen:
            raise ValueError("duplicate or escaped M03 path")
        seen.add(name)
        f = root / name
        if f.is_symlink() or not f.is_file():
            raise ValueError("missing or linked M03 file")
        data = f.read_bytes()
        actual = hashlib.sha1(
            b"blob " + str(len(data)).encode("ascii") + b"\0" + data
        ).hexdigest()
        if actual != sha:
            raise ValueError("changed M03 file")
    if not {"BUILD_ID", "bin/vfops-user"}.issubset(seen):
        raise ValueError("missing M03 identity")
except (OSError, UnicodeError, ValueError, TypeError, KeyError, RecursionError):
    sys.exit(13)
PY
}

if verify_installed_current; then
  say "网站与数据功能已是当前版本，无需下载或重复安装 ✓"
  if [[ -t 0 && -t 1 && "${P07_NO_EXEC:-0}" != "1" ]]; then exec "$BIN_LINK"; fi
  exit 0
fi

# M03 install must never remove an unknown existing rollback snapshot or
# existing staged directory. Only the M03 owner may decide how to retain it.
if [[ -e "$PREVIOUS_DIR" || -L "$PREVIOUS_DIR" ]]; then
  fail "P07-M03 网站与数据：存在上次升级的恢复目录；拒绝覆盖或删除。"
fi
if [[ -e "${INSTALL_DIR}.new" || -L "${INSTALL_DIR}.new" ]]; then
  fail "P07-M03 网站与数据：目标临时目录已有内容；拒绝清理或覆盖。"
fi

# Guard any previous runtime before downloading/upgrading it. A verified
# earlier M03 build is upgradeable; a dirty or foreign M03 must be preserved.
if [[ -e "$INSTALL_DIR" || -L "$INSTALL_DIR" ]]; then
  verify_existing_module_before_upgrade ||
    fail "P07-M03 网站与数据：原运行时归属或完整性无法确认，拒绝升级覆盖。"
fi

if [[ "${P07_ALLOW_NONROOT:-0}" != "1" ]]; then
  [[ ${EUID:-$(id -u)} -eq 0 ]] || fail "请使用 root 运行。"
fi

missing=()
command -v curl >/dev/null 2>&1 || missing+=(curl)
command -v tar >/dev/null 2>&1 || missing+=(tar)
command -v python3 >/dev/null 2>&1 || missing+=(python3)
command -v sha256sum >/dev/null 2>&1 || missing+=(coreutils)
if (("${#missing[@]}")); then
  command -v apt-get >/dev/null 2>&1 || fail "缺少安装所需基础工具：${missing[*]}"
  say "按需安装当前安装过程必需的基础工具：${missing[*]}"
  apt-get update -y >/dev/null
  DEBIAN_FRONTEND=noninteractive apt-get install -y "${missing[@]}" >/dev/null
fi
for cmd in curl tar python3 sha256sum; do
  command -v "$cmd" >/dev/null 2>&1 || fail "缺少基础工具：$cmd"
done

TMP_DIR="$(mktemp -d -t p07-current.XXXXXX)"
NEW_DIR="${INSTALL_DIR}.new"
COMMITTED=0
OLD_MOVED=0
NEW_INSTALLED=0

cleanup() {
  local rc=$?
  trap - EXIT
  # Abort after a partially completed path swap must leave the old runtime
  # available. The flags are set only after this invocation moved each path.
  if (( rc != 0 && COMMITTED == 0 )); then
    if (( NEW_INSTALLED == 1 )); then
      rm -rf "$INSTALL_DIR" 2>/dev/null || true
    fi
    if (( OLD_MOVED == 1 )); then
      if mv "$PREVIOUS_DIR" "$INSTALL_DIR"; then
        # Existing links to the canonical install path become valid again.
        # If the link location itself caused the failure, keep the old tree.
        ln -sfn "$INSTALL_DIR/bin/vfops-user" "$BIN_LINK" 2>/dev/null || true
        say "安装失败，已恢复安装前的旧版本目录。"
      else
        printf '安装失败且自动恢复旧版失败；旧版备份位于：%s\n' "$PREVIOUS_DIR" >&2
      fi
    elif (( NEW_INSTALLED == 1 )) && [[ -L "$BIN_LINK" ]] && \
         [[ "$(readlink "$BIN_LINK" 2>/dev/null || true)" == "$INSTALL_DIR/bin/vfops-user" ]]; then
      rm -f "$BIN_LINK" 2>/dev/null || true
    fi
  fi
  rm -rf "$TMP_DIR" "$NEW_DIR" 2>/dev/null || true
  exit "$rc"
}
trap cleanup EXIT

say "下载当前正式运行时..."
curl -fsSL --retry 3 --retry-all-errors --retry-delay 1 --connect-timeout 15   "${BASE_URL}/${BASE_PACKAGE}" -o "$TMP_DIR/base.tar.gz" || fail "基础运行包下载失败。"
printf '%s  %s\n' "$BASE_SHA256" "$TMP_DIR/base.tar.gz" | sha256sum -c - >/dev/null || fail "基础运行包校验失败。"
tar -tzf "$TMP_DIR/base.tar.gz" >/dev/null 2>&1 || fail "基础运行包格式异常。"
mkdir -p "$TMP_DIR/extracted"
tar -xzf "$TMP_DIR/base.tar.gz" -C "$TMP_DIR/extracted"
SRC_DIR="$TMP_DIR/extracted/vf-server-ops"
[[ -f "$SRC_DIR/VERSION" && -f "$SRC_DIR/bin/vfops" ]] || fail "基础运行包结构异常。"

curl -fsSL --retry 3 --retry-all-errors --retry-delay 1 --connect-timeout 15   "${RUNTIME_URL}/RUNTIME.gitblob" -o "$TMP_DIR/RUNTIME.gitblob" || fail "当前运行时清单下载失败。"
verify_git_blob "$TMP_DIR/RUNTIME.gitblob" "$RUNTIME_MANIFEST_BLOB" || fail "当前运行时清单身份校验失败。"

while read -r expected path; do
  [[ -n "$expected" && -n "$path" ]] || continue
  case "$path" in
    /*|../*|*/../*|*/..) fail "运行时清单包含非法路径：$path" ;;
  esac
  mkdir -p "$SRC_DIR/$(dirname "$path")"
  curl -fsSL --retry 3 --retry-all-errors --retry-delay 1 --connect-timeout 15     "${RUNTIME_URL}/${path}" -o "$SRC_DIR/$path" || fail "当前运行时文件下载失败：$path"
  verify_git_blob "$SRC_DIR/$path" "$expected" || fail "当前运行时文件身份校验失败：$path"
done < "$TMP_DIR/RUNTIME.gitblob"
cp "$TMP_DIR/RUNTIME.gitblob" "$SRC_DIR/.runtime-manifest.gitblob"
chmod 0644 "$SRC_DIR/.runtime-manifest.gitblob"

say "执行轻量安装前自检..."
for file in "$SRC_DIR"/bin/* "$SRC_DIR"/lib/cloudpanel_ui_*.sh "$SRC_DIR"/lib/terminal_ui.sh "$SRC_DIR"/lib/restore_failure_ui.sh; do
  [[ -f "$file" ]] || continue
  bash -n "$file"
done
chmod +x "$SRC_DIR"/bin/*
python3 -m py_compile "$SRC_DIR"/lib/*.py
find "$SRC_DIR/lib" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
[[ "$(NO_COLOR=1 bash "$SRC_DIR/bin/vfops-user" --version)" == "$EXPECTED_VERSION" ]] || fail "版本自检失败。"
[[ "$(NO_COLOR=1 bash "$SRC_DIR/bin/vfops-user" --build-id)" == "$EXPECTED_BUILD_ID" ]] || fail "构建身份自检失败。"
verify_tree_from_manifest "$SRC_DIR" "$TMP_DIR/RUNTIME.gitblob" || fail "运行时完整性自检失败。"

say "安装当前版本..."
[[ ! -e "$NEW_DIR" && ! -L "$NEW_DIR" ]] || fail "M03 临时路径发生并发冲突，拒绝覆盖。"
mkdir -p "$NEW_DIR"
cp -a "$SRC_DIR"/. "$NEW_DIR"/

if [[ -e "$INSTALL_DIR" ]]; then
  [[ ! -e "$PREVIOUS_DIR" && ! -L "$PREVIOUS_DIR" ]] || fail "M03 原恢复版本已存在，拒绝覆盖。"
  mv "$INSTALL_DIR" "$PREVIOUS_DIR"
  OLD_MOVED=1
fi
mv "$NEW_DIR" "$INSTALL_DIR"
NEW_INSTALLED=1
mkdir -p "$(dirname "$BIN_LINK")"
ln -sfn "$INSTALL_DIR/bin/vfops-user" "$BIN_LINK"

if ! verify_installed_current; then
  fail "安装后自检未通过，将恢复安装前版本。"
fi

COMMITTED=1
say "网站与数据功能安装 / 升级完成 ✓"
printf '版本：%s\n' "$EXPECTED_VERSION"
printf '构建：%s\n' "$EXPECTED_BUILD_ID"
printf '更新方式：只更新当前正式功能，不重复执行历史升级步骤。\n'
printf '按需组件：使用异地备份或服务器迁移时，才准备对应的远程连接与文件同步工具。\n'
printf '安全边界：不自动改 DNS、不自动删除源服务器、不自动覆盖已有目标服务器。\n'

if [[ -t 0 && -t 1 && "${P07_NO_EXEC:-0}" != "1" ]]; then
  exec "$BIN_LINK"
fi
