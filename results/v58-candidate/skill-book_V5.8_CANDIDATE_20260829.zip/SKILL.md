---
name: skill-book
description: 开发图书、电子书、教程、课程与知识产品。最高目标是“读得下去、学得会、练得到、做得出”。FULL_BOOK 必须优先保证连续阅读价值、章节实质深度、训练与实操闭环，再由 Evidence 证明；不得用章节数、字数、模板数、ZIP 或机器 PASS 冒充一本好书。仅用于明确的书籍、教程、课程或知识产品任务。
---

# skill-book V5.8 Candidate

Status: `CANDIDATE / NOT CURRENT`  
Scope: `Reader-First Rebalance / Full-Book Substance / Product Packaging`  
Base: `skill-book V5.7 Current`  
Runtime Contract ID: `SB58-RUNTIME-CONTRACT-BF41D2E7`

V5.8 是一次 **rebase，不是 append-only verifier release**。V5.7 已能证明 Depth / Transfer / Freeze，但真实 A1 生成暴露出：结构完整、Evidence 完整、章节齐全，仍可能只是薄的讲义；Reader-facing 交付也可能被工程目录和英文文件名淹没。

因此 V5.8 的优先级固定为：

```text
BOOK FIRST
→ CONTINUOUS READING
→ SUBSTANCE
→ LEARN / TRAIN / DO
→ READER-FACING PRODUCT
→ EVIDENCE
```

Evidence 的职责是证明书，不是让书服务 Evidence。

---

## 0. Reader Outcome Doctrine

所有 Gate 的上位合同只有四项：

```text
READ  — 愿意继续读，连续阅读不疲劳，能跟得上问题推进
LEARN — 能解释为什么，并在新情境中判断
TRAIN — 真正做过判断/产出，得到反馈并能纠错
DO    — 能把关键路径做出来，得到可验证输出
```

硬规则：

1. 技术 Gate PASS 不能覆盖 Reader Outcome FAIL。
2. 字数、页数、章节数、模板数、Reference 数、ZIP 大小都不能单独证明质量。
3. “短”不是天然高级；“长”也不是天然完整。长度只能作为 shell-risk 信号，最终看职责是否写透。
4. FULL_BOOK 与 HANDBOOK / COURSE_NOTES / QUICK_GUIDE 是不同产品类型，禁止用后者的密度冒充前者。
5. 如果目标承诺是“一本完整实战书”，最终读者必须能明显感到自己在读一本书，而不是测试包、课程提纲、Checklist 集合或工程目录。

---

## 1. V5.8 Full-Book Class Gate

生成前先声明：

```text
PRODUCT_CLASS = FULL_BOOK | HANDBOOK | COURSE_NOTES | QUICK_GUIDE
```

如果用户明确要求“书 / 电子书 / 完整实战书”，默认 `FULL_BOOK`，除非用户主动要求浓缩手册。

`FULL_BOOK` 的核心章节必须完成一个真实 Reader Job，而不是只有：

```text
定义 → 三个要点 → 小案例 → Checklist → 结束
```

核心章节至少应按职责需要展开以下多数元素：

- Reader Situation / 为什么现在会卡住
- Causal Explanation / 原理和因果
- Decision Rule / 如何判断
- Near-miss / 看起来对但实际错的路径
- Worked Example / 具体推演
- Failure / 会怎么失败
- Recovery / 失败后如何修
- Practice / 读者主动做一次
- Feedback / 如何知道做得对不对
- Operational Output / 形成什么真实产物
- Bridge / 这一章如何把读者带到下一章

不是每章机械套 11 段；允许叙事、案例、图表、操作、对话、诊断等不同形态。但**关键职责不能只出现标题而没有展开**。

### Thin-shell hard stop

对 `FULL_BOOK`：

- 如果大量核心章节明显只有提纲级展开，必须 `FULL_BOOK_SUBSTANCE = BLOCK`。
- 字符/词数仅作 shell-risk 检测；例如核心章节中大量低于约 1800 个中文字符（或等量英文词量）时，必须触发语义深度复核，生成者不得仅凭“章节齐全”自我放行。
- 如果 >= 40% 核心章节被判为 `THIN_SHELL / OUTLINE_EXPANSION / CHECKLIST_DOMINANT`，直接返回 Depth Plan 重写，不允许先 Freeze 再补字。

详细合同：`references/full_book_substance_contract.md`。

---

## 2. Continuous Reading Gate

Random Open 只能证明局部页面，不足以证明一本书。

FULL_BOOK 在 Freeze 前必须做 **连续三章阅读检查**，至少抽两组相邻章节：

```text
Chapter N → N+1 → N+2
```

检查：

1. 上一章形成的问题/产物是否被下一章接住。
2. 是否每章都像重新开机，重复定义、重复总结、重复“本章你将学到”。
3. 阅读节奏是否有变化：解释、案例、操作、判断、故事不能全部同模板。
4. 读完三章后，Reader State 是否明显推进。
5. 删除任一章是否会造成真实能力断层；如果不会，章节可能是 filler。

连续阅读 FAIL 时，不得用 Random Open PASS 抵消。

详细合同：`references/continuous_reading_contract.md`。

---

## 3. Chapter Substance Plan · 写之前先决定要写透什么

每个核心章节写作前建立内部 Depth Plan，至少包含：

```text
Reader Entry State
Chapter Job
Must Explain
Must Judge
Must Demonstrate
Near-miss / Failure Modes
Worked Example
Practice + Feedback
Operational Output
Completion Criteria
Bridge to Next Chapter
```

写作采用三轮，而不是一次“生成完整章节”：

```text
Pass A — Causal Core
把事情讲明白，建立因果、边界和判断。

Pass B — Human Reading
加入真实情境、具体例子、反例、节奏和过渡；消除 AI 模板感。

Pass C — Transfer + Operation
加入训练、反馈、输出、验证、失败恢复和下一步。
```

三轮完成前不得为了“简洁”大规模压缩。精简只能删除重复，不能删除理解所需的因果、示例和判断过程。

详细合同：`references/generation_depth_contract.md`。

---

## 4. Book-First Writing Rules

正文写作时优先回答：

> 一个第一次遇到这个问题的真实读者，在这里最容易误解什么、做错什么、为什么、如何看出自己错了、下一步具体做什么？

禁止：

- AI 大纲扩写；
- 每章同一模板；
- 标题很多、正文很薄；
- 用表格和 bullet 替代解释；
- “可以用 AI / 可以搜索 / 可以考虑”式空泛建议；
- 只给原则，不给判断；
- 只给案例，不提炼可迁移规则；
- 只给 Checklist，不解释为什么；
- 为显得专业堆术语和工具名；
- 把 Reference 当正文，让读者自己去补课。

鼓励：

- 从读者真实困境进入；
- 先给可理解的心智模型，再给术语；
- 对 near-miss 做对比；
- 展示失败与恢复，而不是只展示成功路径；
- 用一个贯穿案例跨章演化；
- 让每章的产物自然成为下一章输入。

---

## 5. LEARN / TRAIN / DO

### LEARN
关键能力至少完成：

```text
Recall → Explain Why → Judge a Changed Case
```

只会复述术语不算学会。

### TRAIN
重要判断必须让读者主动做一次：

```text
Task → Reader Attempt → Feedback / Decision Rule → Correction
```

“思考一下”“复习本章”不算 TRAIN。

### DO
实战关键路径必须具备：

```text
Task
Input
Preconditions
Steps
Output
Validation
Failure Recovery
Completion Criteria
```

能真实运行则运行；环境不能运行时明确 `NOT_RUN / BLOCK`，不得用 prose 假装已执行。

Practical Asset 必须自足：单独打开也知道何时用、怎么填、怎么判断、失败怎么办、何时算完成。Workbook/Worked Example 不能替薄模板兜底。

沿用 V5.6 Practical Asset Depth 合同：`references/practical_asset_depth_contract.md`。

---

## 6. Reader-facing Product Packaging

内部工程资产与读者产品必须分层。

### Reader-facing 顶层

最终 ZIP 顶层必须让普通读者一眼看到“书在哪里”。默认至少提供：

```text
<书名>_完整正文.md
<书名>_阅读版.html 或 PDF/EPUB（按任务能力）
<书名>_实战工作簿/
<书名>_实操模板/
<书名>_快速参考.md
```

用户-facing 文件名默认跟随书的主要语言。中文书不得只暴露：

```text
A1_FULL_MANUSCRIPT.md
BOOK/
WORKBOOK/
TEMPLATES/
```

这些内部名可存在于 `_internal/` 或 `evidence/`，但不能成为唯一入口。

### Packaging hard rules

1. 书名是产品身份，不是工程代号。
2. Reader-facing 目录/文件默认本地化、可读、可辨认。
3. Evidence / Audit / Manifest / evaluator 不能淹没正文入口。
4. Blind Reader Packet 与 Evaluator Key 必须物理隔离。
5. 最终交付先回答“怎么读这本书”，再回答“怎么验证这个包”。

详细合同：`references/reader_facing_packaging_contract.md`。

---

## 7. Evidence Budget · 证明不能反客为主

FULL_BOOK 的生成主流程不得以制造 Evidence 文件为主要工作。

V5.8 核心 mandatory evidence 收敛为：

```text
evidence/runtime_entry_receipt.json
evidence/reader_transformation_contract.json
evidence/baseline_applicability_pre_draft.json
evidence/full_book_substance_contract.json
evidence/full_book_substance_audit.json
evidence/continuous_reading_audit.json
evidence/training_feedback_pre_freeze.json
evidence/operational_closure_pre_freeze.json
evidence/reader_facing_packaging_audit.json
evidence/freeze_record.json
evidence/freeze_integrity_audit.json
evidence/reader_transfer_contract.json
evidence/runtime_authority_status.json
evidence/runtime_acceptance_audit.json
```

V5.7 的 Adequacy / Practical Asset Depth / Reader Transfer / Baseline / Holdout verifiers 仍保留为权威检查能力，但不得为了“文件更多”重复写同义证据。能从一个 canonical input 推导的结果，不再创建多个 prose 镜像。

规则详见：`references/evidence_budget_contract.md`。

---

## 8. Runtime Entry

FULL_BOOK / SEALED_STANDALONE_FORWARD 开始时先写 `runtime_entry_receipt.json`：

```text
RUNTIME_CONTRACT_ID = SB58-RUNTIME-CONTRACT-BF41D2E7
declared_skill_version = 5.8
entry_stage = PRE_DRAFT
```

如果 Personal Skill Runtime 不暴露独立 Skill metadata：

```text
RUNTIME_SELF_INTROSPECTION = NOT_EXPOSED
```

继续执行，不得把“没有独立 Tool/Connector”误判为 Skill 未加载。

如果正式 verifier 无法真实执行：

```text
machine_execution_status = NOT_RUN
```

不能另写弱版检查然后宣称 PASS。

---

## 9. Research

需要当前事实时必须研究，优先：

1. 官方文档 / 第一方资料；
2. 权威标准；
3. 高质量一手资料；
4. 需要真实用户语言时再用社区讨论。

研究服务正文，不把书写成链接目录或平台手册。对软件、政策、价格、SEO、支付、安全等会变化的事实必须按任务时点验证。

---

## 10. Historical Baseline / Sealed Generation

如果是 SEALED 新稿：

1. PRE_DRAFT 先声明 Baseline Applicability。
2. FIRST_FREEZE 前禁止读取同书历史 Canonical、旧稿、旧比较报告、历史 patch/evaluator 结论。
3. FIRST_FREEZE 后才允许 evaluator-only 检索历史同书。
4. 找到历史 Canonical 后，可做新旧比较，但历史稿不得反向成为新稿补丁模板，除非任务明确转为 revision。
5. “旧版更长/新版更多文件”都不是结论；比较回到 READ / LEARN / TRAIN / DO / Chapter Value / Substance / Packaging。

---

## 11. FIRST_FREEZE 前硬门

在建立 FIRST_FREEZE 之前，至少确认：

```text
PRODUCT_CLASS = correct
BOOK_ARCHITECTURE = complete
FULL_BOOK_SUBSTANCE = PASS
CONTINUOUS_READING = PASS
LEARN_TRANSFER_PRECHECK = PASS
TRAIN_FEEDBACK = PASS
DO_OPERATIONAL_CLOSURE = PASS
PRACTICAL_ASSET_DEPTH = PASS or machine NOT_RUN honestly recorded
READER_FACING_PACKAGING = PASS
PREFREEZE_RANDOM_OPEN = PASS
```

其中 `FULL_BOOK_SUBSTANCE`、`CONTINUOUS_READING`、`READER_FACING_PACKAGING` 任一 FAIL 时，不允许 Freeze。

修正文 Reader-facing bytes 后必须重建 Freeze identity。

---

## 12. Reader Transfer

沿用 V5.7 Blind Reader Transfer 权威边界：

- fresh blind proxy 必须 blind to generation contract / verifier / canonical；
- READ 取回顺序、边界和 next decision；
- LEARN 处理 changed case + near-miss；
- TRAIN 要有 first-attempt responsibility / feedback / retry 机制（如设计要求触发）；
- DO 要产出 actionable artifact + acceptance / handoff；
- `BLIND_READER_PROXY_PASS != REAL_READER_PASS`。

生成窗口不得把自己冒充 fresh independent reader。

无法提供独立 reader session 时：

```text
FRESH_ISOLATED_BLIND_PROXY = NOT_RUN / PENDING_EXTERNAL_READER
REAL_READER_EVIDENCE = NOT_RUN
```

详细合同：`references/reader_transfer_contract.md`。

---

## 13. Final Delivery

FULL_BOOK 最终交付必须同时有两层：

### A. Reader Product

读者第一眼能找到：正文、阅读版、工作簿、模板、快速参考。

### B. Verification Layer

`evidence/`、Audit、Manifest、SHA256、Blind Reader Packet、Evaluator Key（隔离）。

最终状态必须分别报告：

```text
BOOK_GENERATION
FULL_BOOK_SUBSTANCE
CONTINUOUS_READING
READER_FACING_PACKAGING
MACHINE_GATES
FIRST_FREEZE
FRESH_ISOLATED_BLIND_PROXY
REAL_READER_EVIDENCE
HISTORICAL_COMPARISON
```

任何适用硬门为 `FAIL / BLOCK / NOT_RUN / UNKNOWN` 时，不能把整个产品写成 `FINAL PASS / REPLACE / PROMOTE`。

---

## 14. V5.8 Regression Definition

V5.8 必须专门拒绝以下历史失败形态：

```text
18章/多章齐全
+ 每章方向正确
+ Workbook/Templates/Audit 齐全
+ ZIP 完整
BUT
核心章节普遍只有提纲级展开
+ 连续阅读像课程笔记
+ 中文书主要入口仍是英文工程文件名
```

这类结果必须判：

```text
PACKAGE_INTEGRITY = PASS
STRUCTURE = PASS
FULL_BOOK_SUBSTANCE = BLOCK
READER_FACING_PACKAGING = BLOCK (if applicable)
FINAL_BOOK = NOT_READY
```

不得再出现“机器完整所以书完成”的 false green。

---

## 15. Authority

本 Skill 独立于软件开发链。软件项目、电子书资产与 Skill 方法身份不得混成同一对象、版本或 Release。

Source Current 在 OWNER 明确 promotion 前仍由 GOV-DOC `CURRENT.md` 决定；V5.8 Candidate 的生成或回归 PASS 不自动改变 Current。
