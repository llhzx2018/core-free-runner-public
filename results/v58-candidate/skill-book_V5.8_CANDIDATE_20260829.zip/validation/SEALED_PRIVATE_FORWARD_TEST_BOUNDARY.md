# Sealed Standalone Forward Boundary · V4.6

Formal Runtime benchmarks use `SEALED_STANDALONE_FORWARD`.

Before first Candidate freeze, old book prose, templates, References, responsibility maps, structural budgets and prior book assets are unavailable to the generation path. Only the installed Skill, fixed Book Input Contract, and newly researched legal/current sources are allowed.

After freeze, an independent Evaluator may read Canonical only for responsibility / adequacy / regression comparison. If regression is found, the frozen Standalone result stays BLOCK; repairing it with old-book knowledge cannot retroactively convert the same run into a pure Standalone PASS.
