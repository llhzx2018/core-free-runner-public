# SEALED PRIVATE RUNTIME FALSE-POSITIVE DETECTION · V4.7 sample under V4.8 verifier

A private sealed V4.7 backend output was replayed only inside the private validation environment. No book title, prose, template body, or private content is included in this distribution.

V4.8 correctly returned `BLOCK` and classified missing or false-green evidence including:

- `RUNTIME_ENTRY_RECEIPT_MISSING`
- `ADEQUACY_CONTRACT_EVIDENCE_MISSING`
- `ADEQUACY_AUDIT_EVIDENCE_MISSING`
- `RUNTIME_ACCEPTANCE_EVIDENCE_MISSING`
- `ADEQUACY_EXTERNAL_REAUDIT_BLOCK`
- `POST_DRAFT_BASELINE_DIFFERENTIAL_BLOCK`
- `RANDOM_OPEN_HOLDOUT_EVIDENCE_MISSING`
- `RANDOM_OPEN_HOLDOUT_FAIL`
- `FINAL_DECISION_FALSE_GREEN`

Generation Depth discovery also found the real nested chapter path and the governance depth-plan path instead of misreporting zero chapters. The sample still blocked because the discovered plan lacked chapter-level Depth Contracts.

Decision: `PASS_V47_FALSE_GREEN_REPLAY_BLOCKED`.
