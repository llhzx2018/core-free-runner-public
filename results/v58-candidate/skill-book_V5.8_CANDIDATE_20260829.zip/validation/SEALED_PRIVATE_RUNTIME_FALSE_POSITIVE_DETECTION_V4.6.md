# Sealed Private Runtime False-positive Detection · V4.6

A previously completed private full-book Runtime forward sample was re-evaluated without distributing its title, manuscript, raw evidence, or per-chapter text.

The prior Candidate had materially improved reader-facing rhythm and anti-formula behavior, but an independent post-draft comparison still found under-sized high-value practical instruments and a substantially thinner aggregate learning bundle.

V4.6 detected:

```text
ADEQUACY_CONTRACT_MISSING
COMPLEXITY_CALIBRATED_CHAPTER_DEPTH
PRACTICAL_ASSET_ADEQUACY
PRACTICAL_ASSET_BASELINE_DIFFERENTIAL
LEARNING_BUNDLE_DEPTH_DIFFERENTIAL
```

The post-draft evaluator found five substantial practical-asset regressions in the sealed sample. This validates the new false-positive detection class; it does not prove V4.6 can yet generate a superior new book.

No private book title, manuscript text, raw evidence, source links, or per-chapter content are included in this distributed validation summary.
