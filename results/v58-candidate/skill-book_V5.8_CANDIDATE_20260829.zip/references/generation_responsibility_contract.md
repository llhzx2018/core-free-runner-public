# Generation Responsibility Contract · V5.6 WIP

V4.9 的目标不是让书更长，而是把 **Freeze 后才发现的职责缩水** 前移到生成期。

## 1. Machine-readable Reader Contract

FULL_BOOK 在 Draft 前必须同时生成：

- `governance/READER_TRANSFORMATION_CONTRACT.md`（读者可读）
- `evidence/reader_transformation_contract.json`（机器可读）

JSON 至少包含：

`TARGET_READER / CURRENT_STATE / DESIRED_STATE / MUST_UNDERSTAND / MUST_BE_ABLE_TO_JUDGE / MUST_BE_ABLE_TO_DO / MUST_AVOID / COMPLETION_EVIDENCE`。

`MUST_BE_ABLE_TO_JUDGE` 与 `MUST_BE_ABLE_TO_DO` 中的关键能力不得在后续计划中静默消失。

## 2. Lifecycle Responsibility Matrix

对实战型书籍，Draft 前必须生成：

`evidence/generation_responsibility_contract.json`

它不是旧 Canonical 的资产清单，而是基于本轮 Reader Transformation Contract 独立建立的新书责任图。

PRACTICAL_PROJECT 默认审视八个阶段：

`DISCOVER → DECIDE → PLAN → EXECUTE → VERIFY → RELEASE_OR_USE → OBSERVE → ITERATE`

每个阶段都必须显式登记 `REQUIRED / OPTIONAL / N_A`。`N_A` 必须写任务理由；不得通过不登记来绕过责任。

PRACTICAL_SKILL 至少硬覆盖：`DECIDE / PLAN / EXECUTE / VERIFY / ITERATE`。

## 3. Critical Capability Traceability

每个关键 `MUST_BE_ABLE_TO_JUDGE / MUST_BE_ABLE_TO_DO` 必须映射到：

- 一个或多个章节；
- 对 DO 能力，至少一个 reader-facing practical asset；
- 对 JUDGE 能力，必须能定位到明确判断规则、案例或决策工具；
- Completion / Validation / Failure Recovery 不得只存在于计划说明里。

## 4. Operator Responsibility Classes

PRACTICAL_PROJECT 必须逐项审视以下通用责任器械，不得把某一具体书名或领域字段写进 Skill：

- `evidence_capture`
- `decision_record`
- `plan_or_contract`
- `execution_brief_or_log`
- `acceptance_record`
- `baseline_snapshot`
- `iteration_log`
- `next_decision`

PRACTICAL_SKILL 至少审视：

- `decision_record`
- `plan_or_contract`
- `execution_brief_or_log`
- `acceptance_record`
- `iteration_log`

同一个资产可以承担相邻责任，但不得用一个万能空表宣称覆盖全部。HIGH 责任必须由自足工具承载；Shell-risk 字符/结构 floor 只能作为薄壳反证，不能证明质量。

## 5. Two-stage Audit

必须真实运行同一个 Authority：

```text
PRE_DRAFT
→ contract completeness / lifecycle / capability mappings

PRE_FREEZE
→ actual chapter paths / actual asset paths / practical responsibility closure
```

Evidence：

- `evidence/generation_responsibility_pre_draft.json`
- `evidence/generation_responsibility_pre_freeze.json`

任一 BLOCK：不得 Freeze。

## 6. SEALED Boundary

SEALED_STANDALONE_FORWARD 在 Freeze 前仍不得读取旧 Canonical。Generation Responsibility Floor 只能依赖当前 Skill、Book Input、Reader Contract 与本轮研究。

旧 Canonical 仍只在 Freeze 后进入 Post-Draft Baseline Differential。V4.9 的作用是减少“到 Freeze 后才发现职责大面积缺失”，不是提前偷看旧书。

## 7. V5.3 Book-Promise Responsibility Depth

Before Draft, infer promise responsibilities from the current book title/Reader Transformation Contract. Each inferred responsibility must exist in `promise_responsibilities` and map to all three layers: Reading Core, differentiated Operator Reference, and Practical Asset. PRE_FREEZE verifies actual depth, decision/action/validation/recovery signals and structure. Missing promise coverage = `BOOK_PROMISE_RESPONSIBILITY_GAP` and FIRST_FREEZE is forbidden. See `book_promise_responsibility_contract.md`.

## 8. V5.4 Phase Depth Preservation + Pre-build Closure

The broad lifecycle remains for compatibility, but PRACTICAL_PROJECT now also requires the finer `phase_depth` matrix defined in `phase_depth_preservation_contract.md`. When the current Reader Transformation promises demand/problem-to-build, V5.4 independently infers opportunity selection, alternative pressure, pre-build behavioral validation, and a development-entry decision. Missing any inferred responsibility or phase blocks FIRST_FREEZE. This is Canonical-independent and must not reproduce historical book structure.

## 9. V5.6 Practical Asset Responsibility Depth · WIP

V5.6 adds a second question after responsibility coverage:

`Does the asset merely mention the dimension, or does it contain enough sub-responsibility structure for independent operator use?`

For every reader-facing practical asset required by `MUST_BE_ABLE_TO_DO`, promise responsibilities, lifecycle/phase responsibilities, or Operational Closure, Draft planning must assign one or more generic asset roles and applicable depth dimensions.

Before Draft, practical runs must create:

`evidence/practical_asset_depth_contract.json`

The contract is derived only from this run's Reader Transformation, Book Promise, lifecycle/phase responsibility and asset role. Historical Canonical is forbidden as a PRE_DRAFT source.

Each HIGH asset profile must include at least:

```json
{
  "path": "templates/example.md",
  "roles": ["decision_record"],
  "complexity": "HIGH",
  "required_dimensions": ["input_evidence", "decision_rule", "completion"],
  "n_a": {},
  "promise_links": ["..."],
  "lifecycle_links": ["..."]
}
```

Before FIRST_FREEZE, after actual practical assets exist, run:

```text
python scripts/practical_asset_depth_audit.py --new <ROOT> --json evidence/practical_asset_depth_audit.json
```

The verifier independently recalculates role-sensitive mandatory anchors. A profile cannot false-green a HIGH asset by declaring only easy dimensions or by inserting one keyword per dimension.

Examples of role-sensitive depth:

- evidence capture requires provenance, evidence item, uncertainty/quality and downstream decision linkage;
- decision records require options, criteria, outcome, rationale and revisit trigger;
- execution briefs/logs require ordered execution, reconstructable evidence trace and a real failure/retry/escalation loop;
- plan/contract assets must not reduce change control to a version field;
- example/guidance must not reduce to one sample value.

Any applicable BLOCK from the depth audit forbids FIRST_FREEZE. The existing Adequacy Gate remains in force; V5.6 depth does not replace it.

Detailed authority: `references/practical_asset_depth_contract.md`.

## 10. V5.6 Anti-overfit Guard · WIP

Before Candidate authorization, the practical-asset depth verifier must pass adversarial fixtures from at least one non-software domain. Current design-gate domain: independently organize a 20-person offline reading-club event.

The generic verifier must distinguish strong and thin evidence capture, decision/change control, execution trace, recovery loop and example guidance without website, SEO, deployment, AI-build or software vocabulary.

Current targeted evidence: `12/12 PASS` non-A1 depth cases plus inherited Adequacy `6/6 PASS`.

These are WIP machine results only; they do not authorize Candidate or Current status and are not Real Reader Evidence.
