# Reader Transfer / Blind Reader Proxy Contract · V5.7 WIP

Status: `DESIGN_GATE / WIP / NOT CANDIDATE / NOT CURRENT`

This contract evaluates whether reader-facing material transfers enough responsibility for a fresh, blind proxy reader to retrieve, adapt, train, and act. It does **not** create Real Reader evidence.

## Authority boundary

`BLIND_READER_PROXY_PASS != REAL_READER_PASS`.

A valid proxy receipt must declare:

- `kind = BLIND_READER_PROXY`;
- `fresh = true`;
- blind to `generation_contract`, `verifier`, and `canonical`;
- `real_reader = false`.

The contract authority must keep `real_reader_derivation = FORBIDDEN` and `real_reader_evidence = NOT_RUN`. `reader_transfer_audit.py` never reads legacy `real_reader.json` to authorize a human outcome.

## Required transfer axes

### READ

The first attempt must recover the task sequence, a blocking/exception boundary, and the next decision from reader-facing material without generation or verifier context.

### LEARN

The reader must apply the rule and rationale to a changed case and distinguish an intentionally plausible near-miss from the correct judgment. A surface-token answer that chooses the near-miss is a transfer failure.

### TRAIN

At least one required training task must expose a real first-attempt responsibility error, targeted feedback, and a materially changed retry. The retry must repair every failed required responsibility rather than merely relabel the same answer PASS.

### DO

The reader must produce an actionable artifact with multiple concrete steps and explicit acceptance results. When handoff is required, operator 2 must receive enough linked state, evidence, next action, and acceptance context to reconstruct and continue the work.

## Hard blocks

- `PROXY_NOT_FRESH`
- `PROXY_NOT_BLIND`
- `PROXY_REAL_READER_AUTHORITY_COLLISION`
- `REAL_READER_AUTHORITY_BOUNDARY_INVALID`
- `TRANSFER_TASK_COVERAGE_GAP`
- `READ_RETRIEVAL_GAP`
- `NEAR_MISS_CONFUSION`
- `LEARN_TRANSFER_GAP`
- `TRAIN_FEEDBACK_LOOP_MISSING`
- `RETRY_DID_NOT_REPAIR_RESPONSIBILITY`
- `DO_OUTPUT_NOT_ACTIONABLE`
- `OPERATOR_HANDOFF_NOT_SELF_SUFFICIENT`

Machine fixtures prove verifier behavior only. Candidate authorization later requires a fresh isolated proxy execution method distinct from unit fixtures; if that execution cannot be obtained, record it `NOT_RUN / BLOCK` rather than synthesizing evidence. Real Reader evidence remains independently `NOT_RUN` until actual human evidence exists.
