# Reader-facing Packaging Contract · V5.8

## Principle

A book package is a reader product first and a verification bundle second.

Internal engineering names are allowed inside verification layers. They must not be the only or primary entry points offered to readers.

## Language rule

Reader-facing filenames and folder names default to the primary language of the book.

For a Chinese book, acceptable examples include:

- `<书名>_完整正文.md`
- `<书名>_阅读版.html`
- `<书名>_实战工作簿/`
- `<书名>_实操模板/`
- `<书名>_快速参考.md`

Engineering aliases such as `FULL_MANUSCRIPT.md`, `BOOK/`, `WORKBOOK/`, `TEMPLATES/` may exist under `_internal/` or as mirrors, but cannot be the sole reader route.

## Required audit

`evidence/reader_facing_packaging_audit.json` records:

- book language
- book title
- top-level reader entries
- localized filename status
- obvious-reading-entry status
- evidence separation status
- blind/evaluator isolation status
- duplicate/confusing entry points
- final decision

## Hard blocks

`READER_FACING_PACKAGING = BLOCK` when:

1. a normal reader cannot identify the manuscript from the top level without opening Manifest/Audit files;
2. the book's primary language and visible reader-facing filenames are materially mismatched without user request;
3. Evidence/Audit/Verifier files dominate or precede the reader product entry;
4. Blind Reader Packet contains evaluator key, hidden generation contract, canonical answer key, or historical comparison material;
5. reader-facing templates use opaque engineering IDs with no human title/index;
6. the delivered ZIP is organized like a software test artifact rather than a book product.

## Separation model

Recommended:

```text
<书名>_完整正文.md
<书名>_阅读版.html
<书名>_快速参考.md
<书名>_实战工作簿/
<书名>_实操模板/

_verification/
  evidence/
  audit/
  manifest/
  evaluator/
```

Exact folders may vary, but the reader path must be obvious and localized.

## Non-goal

This contract does not require decorative design, PDF, EPUB, cover art, or a specific publishing format unless requested. It requires product clarity, not visual ornament.
