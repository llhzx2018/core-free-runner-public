# Runtime Authority Fidelity Contract · V5.8

Personal Skill execution and machine acceptance are separate facts. Generation may succeed while bundled verifiers are not exposed as executable tools. V5.8 preserves truth by recording machine authority status instead of allowing a weaker prose/self-audit to impersonate verifier PASS.

Final FULL_BOOK / SEALED packages include:

`evidence/runtime_authority_status.json`

Minimum identity:

```json
{
  "runtime_contract_id": "SB58-RUNTIME-CONTRACT-BF41D2E7",
  "declared_skill_version": "5.8",
  "authority_mode": "BUNDLED_VERIFIER | EXTERNAL_VERIFIER_PENDING",
  "machine_execution_status": "EXECUTED | NOT_RUN",
  "runtime_acceptance_claim": "PASS_RUNTIME_ACCEPTANCE | BLOCK | BLOCK_PENDING_EXTERNAL_VERIFIER",
  "canonical_inputs": ["evidence/runtime_entry_receipt.json", "..."]
}
```

## V5.8 canonical authority set

The compact Reader-first set includes:

- runtime entry receipt
- Reader Transformation
- Baseline Applicability pre-draft declaration
- Full Book Substance contract/audit
- Continuous Reading audit
- Training Feedback pre-freeze
- Operational Closure pre-freeze
- Reader-facing Packaging audit
- FIRST_FREEZE record + Freeze Integrity
- Reader Transfer contract
- Runtime Acceptance audit

Retained functional authorities also remain required when applicable:

- Practical Asset Depth contract/audit
- Reader Transfer proxy/audit

Evidence Budget removes duplicate prose/status mirrors; it does not remove these functional authorities.

## Rules

1. If bundled verifier execution is unavailable, generation may continue, but `machine_execution_status = NOT_RUN`, `authority_mode = EXTERNAL_VERIFIER_PENDING`, and acceptance claim remains BLOCK/NOT_RUN.
2. Even when execution is unavailable, exact canonical JSON inputs must exist for external verification.
3. A weaker `audit/run_audit.json`, prose checklist, or alternate PASS cannot authorize Runtime Acceptance.
4. `FULL_BOOK_SUBSTANCE`, `CONTINUOUS_READING`, and `READER_FACING_PACKAGING` are V5.8 hard inputs. Missing/blocked inputs forbid Runtime PASS even if V5.7-era Random Open, Freeze, Practical Asset Depth, and Reader Transfer are green.
5. Machine shell-risk is not literary judgment. It can force semantic review and BLOCK obvious thinness; it cannot prove the book is excellent.
6. `BLIND_READER_PROXY_PASS != REAL_READER_PASS`. Real Reader status remains a separate authority category.
7. Historical Canonical stays FIRST_FREEZE+ evaluator-only and is never a generation template in SEALED runs.
