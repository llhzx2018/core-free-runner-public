# V5.0 Shadow External Local-Value Contract

Freeze 前必须额外运行一套与 Runtime Acceptance 同类、但独立于 generation Random Open 的局部价值 Gate：`shadow_local_value_audit.py`。

其目的不是替代 strict unseen holdout，而是减少 generation verifier 与 runtime verifier 的判定规则漂移。它使用不同抽样空间和更高的局部 action/decision cue floor；FAIL 允许 Freeze 前系统性修复，但修复结果仍须经过 canonical evidence promotion。
