# Runtime Enforcement Contract · V5.8

V5.8 retains V5.7 truth/freeze/transfer authorities and changes the priority order: runtime evidence must prove a real FULL_BOOK, not merely a structurally complete package.

## Runtime identity

FULL_BOOK / SEALED_STANDALONE_FORWARD must create `evidence/runtime_entry_receipt.json` before Draft.

```text
RUNTIME_CONTRACT_ID = SB58-RUNTIME-CONTRACT-BF41D2E7
DECLARED_SKILL_VERSION = 5.8
```

If product runtime metadata is not exposed, record `RUNTIME_SELF_INTROSPECTION = NOT_EXPOSED` and continue. Do not invent introspection.

## V5.8 pre-Freeze hard gates

For `PRODUCT_CLASS = FULL_BOOK`, FIRST_FREEZE cannot be created unless the applicable evidence closes:

- Reader Transformation
- Full Book Substance
- Continuous Reading
- Training Feedback
- Operational Closure
- Practical Asset Depth
- Reader-facing Packaging
- Generation Random Open

The new hard gates are not aliases for old ones:

```text
Random Open PASS != Continuous Reading PASS
Chapter Coverage PASS != Full Book Substance PASS
Package Integrity PASS != Reader-facing Packaging PASS
```

A machine shell-risk check may BLOCK obvious thinness. It cannot independently prove literary quality.

## Declarative Evidence First / External Verifier Authority

Personal Skill sessions do not assume packaged Python is exposed as a Tool.

- If bundled verifier runs: record official JSON outputs.
- If it cannot run: `machine_execution_status = NOT_RUN` and acceptance remains BLOCK / pending external verifier.
- Never create a weaker audit and call it authoritative PASS.

## Retained V5.6/V5.7 authorities

V5.8 continues to enforce:

- Practical Asset self-sufficiency and role-sensitive depth;
- Workbook / worked examples cannot rescue a thin blank tool;
- Baseline Applicability declared PRE_DRAFT and resolved only after FIRST_FREEZE;
- deterministic Freeze Record and Freeze Integrity;
- post-Freeze local holdout where the retained Runtime lane requires it;
- Reader Transfer changed-case / near-miss / retry / actionable DO / operator handoff;
- `BLIND_READER_PROXY_PASS != REAL_READER_PASS`;
- canonical evidence promotion when the applicable external Runtime path requires it.

Historical Canonical is FIRST_FREEZE+ evaluator-only and never a SEALED generation template.

## Evidence Budget

V5.8 reduces duplicate evidence, not functional truth gates. Use the compact mandatory set in `references/runtime_entry_receipt_contract.md`; create legacy/retained inputs when a retained verifier actually consumes them. Do not manufacture prose mirrors simply to match an older package file count.

## Reader-facing product enforcement

For a Chinese FULL_BOOK, the reader should see obvious localized top-level entry points, e.g. `<书名>_完整正文.md` and `<书名>_阅读版.html`. Engineering folders like `BOOK/`, `WORKBOOK/`, `TEMPLATES/` may exist internally but cannot be the sole product route.

Blind Reader material and Evaluator material must remain physically isolated.

## Final decision truth

If any applicable hard gate is `BLOCK / FAIL / NOT_RUN / UNKNOWN`:

- Generation/Packaging may be described accurately;
- FIRST_FREEZE may not be claimed if a pre-Freeze hard gate failed;
- Runtime Acceptance may not be called PASS;
- do not output `ACCEPT / REPLACE / PROMOTE / READY` as the overall book decision.

V5.8 Candidate evidence does not change Source Current. OWNER promotion remains a separate gate.
