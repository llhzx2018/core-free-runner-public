# Reader Outcome & Test Contract · V4.6

## Highest Reader Outcome

完整教学/实战书的最高质量合同固定为：

```text
READ — 看得下去 / 愿意继续读
LEARN — 看完真正学会并能迁移
TRAIN — 经过主动练习、反馈和纠错
DO — 能实际完成关键任务并验证输出
```

简称：**读得下去 / 学得会 / 练得到 / 做得出**。

任何 Baseline、Regression、Depth、Random Open 或 Machine Audit PASS 都不能替代这四项。

## Evidence Levels

Reader evidence分为 `SIMULATED_READER_EVIDENCE` 与 `REAL_READER_EVIDENCE`。没有真人样本时不得写 `REAL_READER_PASS`。

### READ

至少检查 Reader Attraction、Reading Drop-off、Random Open、Chapter Value 与 Structural Diversity。正文如果主要依赖固定AI章节模板、术语堆积、重复总结或“详见Reference”才能成立，READ不得PASS。

### LEARN

至少验证：`Recall → Explain Why → Judge New Scenario`。能复述不等于会迁移。

### TRAIN

关键能力必须有主动训练资产，最少包括：

```text
Prompt / Input
Reader Action
Expected Output
Feedback / Reference Judgment
Error Correction / Retry
```

只有“想一想 / 回顾一下 / 自测是否理解”但没有读者产出和反馈路径，不构成TRAIN Evidence。

### DO

关键实操至少记录：`Task / Input / Preconditions / Steps / Output / Validation / Failure Recovery / Completion Criteria`。可执行条件具备时应实际执行；未执行必须为 `NOT_RUN`，不可用模拟结果冒充。

## Random Open

Random Open必须抽取正文、Reference、Template/Worksheet真实局部；只有指针、标题、空字段、通用壳或无法形成判断/动作/产出的局部为FAIL。

## Book-level Decision

书级质量汇总使用：

```text
READ_CONTINUE
LEARN_TRANSFER
TRAIN_FEEDBACK
DO_VERIFIED_OUTPUT
```

任何适用项为 `FAIL / BLOCK / NOT_RUN / UNKNOWN` 时，不得宣称“达到最高读者价值”“新版更好”或“可替换旧版”。


## V4.5 Reader-facing Closure

READ还必须检查内部写作/回归脚手架泄漏和跨章教学节奏重复。TRAIN不接受练习数量作为Evidence；关键能力必须有Expected Output、Reference Judgment、Common Error、Correction和Retry。DO需要独立执行Evidence；空Workbook不构成PASS。


## V4.6 Instrument Strength
TRAIN审计同时检查“反馈闭环是否存在”和“承载训练的器械是否足够”。一个只有少量空字段的复杂工作表，即使写了纠错/重试字样，也不能自动形成TRAIN PASS。
