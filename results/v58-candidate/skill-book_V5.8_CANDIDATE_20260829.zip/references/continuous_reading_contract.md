# Continuous Reading Contract · V5.8

## Purpose

Random Open catches local value. It does not prove that a FULL_BOOK works as a continuous reading experience.

Before FIRST_FREEZE, a FULL_BOOK must pass at least two contiguous reading windows of three adjacent chapters.

## Required audit

`evidence/continuous_reading_audit.json` records for each sampled window:

- chapter ids/titles
- entry reader state
- carry-over from previous chapter
- new capability gained per chapter
- variation in reading mode
- repetition detected
- unresolved context breaks
- output/input handoff across chapters
- end reader state
- remove-one-chapter impact
- decision: PASS / BLOCK

## What PASS means

A passing three-chapter window should show:

1. `State progression` — the reader ends materially more capable than at the start.
2. `Carry-over` — outputs/questions from N are used in N+1 or N+2 where appropriate.
3. `Narrative/decision continuity` — chapters do not behave like unrelated blog posts.
4. `Rhythm variation` — explanation, example, judgment, practice and operation are not forced into identical templates.
5. `Low restart tax` — the reader is not repeatedly reintroduced to the whole book promise.
6. `Real necessity` — removing a core chapter creates an observable learning/operational gap.

## Block signals

- every chapter begins with near-identical framing and ends with near-identical summary;
- repeated definitions exceed new learning;
- chapter outputs disappear and are never used;
- adjacent chapters could be arbitrarily reordered with no consequence;
- the sequence is mostly a taxonomy rather than a transformation;
- checklist density repeatedly interrupts explanation;
- the reader must infer missing bridges on their own;
- three chapters can be read in minutes despite representing high-complexity steps, because they are only summaries.

## Repair

Repair continuity by changing chapter responsibilities, merging filler chapters, strengthening bridges, reusing real artifacts, and varying form. Do not solve continuity by adding transition sentences to otherwise disconnected chapters.

`CONTINUOUS_READING = PASS` cannot be inferred from Random Open, chapter count, table of contents quality, or the generator's prose assertion.
