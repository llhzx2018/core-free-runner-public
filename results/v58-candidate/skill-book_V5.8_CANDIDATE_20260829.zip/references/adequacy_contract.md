# Adequacy Contract · V5.4

V4.6解决的不是“再写长一点”，而是：**复杂任务必须有足够的功能责任、判断机制和操作器械，不能因阅读更自然就把学习/实操深度一起压掉。**

## 1. Chapter Adequacy Profile

FULL_BOOK在Draft前必须生成`evidence/adequacy_contract.json`（也可位于`frontmatter/`），每章至少登记：

```json
{
  "path": "chapters/01_x.md",
  "complexity": "HIGH",
  "must_explain": ["..."],
  "must_judge": ["..."],
  "boundaries": ["..."],
  "failure_modes": ["..."],
  "worked_examples": ["..."],
  "practice_outputs": ["..."],
  "template_assets": ["templates/...md"]
}
```

机器重新计算复杂度，不信任作者自报：责任点越多、绑定的执行资产越多，复杂度越高。HIGH章节不能用一个短Depth Plan自证“已经够深”。

## 2. Practical Asset Responsibility Dimensions

每个Template / Worksheet / Acceptance Record必须单独登记，不允许“模板总数够了”代替单体充分度。适用维度包括：

- Context / Task：谁在什么任务中使用；
- Input / Evidence：输入、来源、前置条件、证据；
- Decision Rule：判断规则、阈值、状态裁决；
- State / Boundary：边界、异常状态、UNKNOWN、Non-goals；
- Execution Steps：执行流程；
- Validation / Acceptance：如何验证结果；
- Evidence Log：如何留痕与回读；
- Failure Recovery：错误、失败、恢复、重试；
- Change Control：版本、冻结、变更、Authority；
- Completion：完成/进入下一阶段条件；
- Example / Guidance：必要示例、参考判断。

不要求每个资产机械包含全部维度；但HIGH复杂度资产必须覆盖足够多的适用责任，任何N/A必须有任务理由，不得为了过Gate删责任。

## 3. Shell-risk Floor

字符数、字段数、表格数永远不能证明充分度；但极薄资产可以作为**反证风险**。V4.6允许机器使用最低Shell-risk floor阻止“几百字却承担复杂裁决”的表单通过。该Floor只会触发补审，不能单独证明资产优秀。

## 4. Training Instrument Strength

训练闭环存在不代表训练器械足够。标记为training_instrument的资产至少必须让读者看到：Expected Output / Reference Judgment / Common Error / Correction / Retry中的四类，并且实际需要产出。


## 5. V4.7 Self-Sufficient Asset Rule

Blank Practical Asset必须独立可用。以下都不能替代该资产本体的充分度：

- 一个填写完整的Worked Example；
- Workbook里的单行表头；
- 正文章节里的解释；
- “后续由AI判断”的自由文本框。

HIGH复杂度资产如果Reader-facing空白工具低于Shell-risk floor或缺少关键职责，即使上述辅助层很丰富仍为`PRACTICAL_ASSET_ADEQUACY = BLOCK`。

## 6. Runtime Evidence Form

Adequacy不能只写Markdown结论。必须生成机器可读：
`evidence/adequacy_contract.json`和`evidence/adequacy_audit.json`。
缺少任一文件时，不允许Final Decision写ACCEPT。


## 7. V5.4 Layer Adequacy, not Layer Presence

For HIGH practical assets, declaring a tiny subset of responsibility dimensions can no longer false-green the asset. HIGH assets must declare a sufficiently rich applicable responsibility surface; decision/validation/contract-like assets must include Decision Rule, Validation/Acceptance, Failure Recovery, and Completion unless a task-specific N/A rationale is explicitly represented in the profile. Training instruments must close Expected Output + Reference Judgment + Common Error + Correction + Retry and also expose a completion condition.

This still does not reward length: character/structure floors remain shell-risk detectors only.
