# VF Agent Runtime Contract · skill-book V4.6

长任务按批次施工；窗口切换保存Reader Contract、目录、Depth Plan、Baseline/Preservation Pointer、章节状态、Gate、风险、唯一下一步。Source Current与Candidate必须显式区分；Candidate不得静默覆盖Current。
