# Book-Promise Responsibility Contract · V5.4

Purpose: stop a book from becoming easier to read by silently deleting the professional responsibilities implied by its own title, target reader and desired outcome. This is **Canonical-independent** and is therefore legal before FIRST_FREEZE in SEALED mode.

`generation_responsibility_contract.json` may include `promise_responsibilities`. V5.3 automatically infers applicable generic promise families from the current Reader Transformation Contract:

- `real_world_delivery`
- `access_identity_routing`
- `discoverability_distribution`
- `user_acquisition_activation`
- `observability_decision`
- `rollback_recovery`

For a web/site task, a delivery promise also forces access/identity/routing plus rollback/recovery. A web/site task that promises real/first users also forces discoverability/distribution. This does not hard-code one historical book; it derives responsibility from the current book promise.

Each inferred REQUIRED promise must declare:

`dimensions + chapter_paths + operator_reference_paths + asset_paths + judgment + execution + validation + failure_recovery + completion`.

PRE_FREEZE then verifies a three-layer Operator Depth Bundle:

`Reading Core + Operator Reference + Practical Asset`.

For high book-promise responsibilities, a thin pointer/reference/template cannot satisfy the bundle. Character and signal floors are only shell-risk detectors; they never by themselves prove quality.

SEALED mode still forbids reading historical Canonical content or structural budgets before FIRST_FREEZE. Book-Promise Responsibility is a first-principles floor, not a disguised baseline leak.


V5.4 delegates phase-level pre-build coverage to `phase_depth_preservation_contract.md`; Book-Promise Responsibility still protects domain/operator promises such as delivery, access, discoverability, acquisition, observability and recovery.
