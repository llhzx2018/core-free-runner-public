# V5.0 Canonical Evidence Promotion Contract

修复后的 PASS 不能用 `*_after_repair.json` 与旧 BLOCK 并存后继续 Freeze。每个适用 Gate 只有一个 canonical evidence path。

流程：

1. verifier 先写 candidate result；
2. candidate decision 必须 PASS；
3. 使用 `promote_canonical_evidence.py` 原子替换 canonical path；
4. promotion 同时写 `canonical_evidence_state.json`，记录 gate、run_id、promoted_at、candidate_sha256、canonical_sha256；
5. `canonical_evidence_promotion_audit.py` 校验 canonical 文件 hash、run_id、timestamp、gate 与 PASS decision；
6. Freeze / Runtime Acceptance 只信 canonical path。

```bash
python scripts/promote_canonical_evidence.py \
  --candidate evidence/<gate>.candidate.json \
  --canonical evidence/<gate>.json \
  --state evidence/canonical_evidence_state.json \
  --gate <GATE_ID> --run-id <RUN_ID>
```

`canonical_evidence_requirements.json` 列出本轮必须晋升的 Gate。任一 required gate 未晋升或 hash/run_id/timestamp drift：BLOCK。
