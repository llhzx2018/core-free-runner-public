# V5.0 Operational Closure Contract

实战型 FULL_BOOK 在 Depth Plan 前必须建立 `evidence/operational_closure_contract.json`，避免“Reader Contract 一开始就没声明高级运营职责”造成静默缩水。

至少逐项审视：

`economics_viability / acquisition_funnel / execution_implementation / measurement_attribution / experiment_change_control / diagnosis_incident_recovery / quality_acceptance / scale_resource_constraints / operating_cadence / end_to_end_repeatable_workflow`

PRACTICAL_PROJECT / PRACTICAL_SKILL 的 execution、measurement、experiment/change、diagnosis/recovery、quality/acceptance、operating cadence、repeatable workflow 默认 REQUIRED；economics/acquisition/scale 根据 Reader Transformation Contract 的商业、流量、转化、预算、扩量等信号自动升级为 REQUIRED。

每个 REQUIRED 项必须同时给出：`chapter_paths + asset_paths + judgment + execution + validation`。N/A 必须有具体任务理由，且不得覆盖 Reader Contract 已明确命中的职责。

执行：

```bash
python scripts/operational_closure_audit.py --new <ROOT> --stage PRE_DRAFT --json evidence/operational_closure_pre_draft.candidate.json
python scripts/operational_closure_audit.py --new <ROOT> --stage PRE_FREEZE --json evidence/operational_closure_pre_freeze.candidate.json
```

PASS 结果仍须经过 Canonical Evidence Promotion 才成为 Freeze Authority。
