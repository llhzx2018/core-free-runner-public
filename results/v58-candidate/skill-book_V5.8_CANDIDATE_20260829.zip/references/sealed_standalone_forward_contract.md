# Sealed Standalone Forward Contract · V4.6

## Purpose

正式Skill Runtime基准使用`SEALED_STANDALONE_FORWARD`。目标是测Skill本身，而不是测旧稿改写能力。

## Before Freeze

Candidate冻结前禁止读取、搜索、引用或利用旧书正文、旧模板、旧Reference、旧章节责任清单与旧版字数预算。唯一允许输入：

1. 当前安装Skill；
2. 固定Book Input Contract；
3. 本轮重新研究的一手/合法资料。

若工具发现阶段意外暴露旧稿snippet，必须记录`INCIDENTAL_EXPOSURE`，Purity降为PARTIAL；不得把snippet用于写作。

## Freeze

完整Candidate首次封存后记录：

- Full Master hash；
- 章节/模板/Reference清单；
- adequacy contract；
- generation evidence；
- package identity。

此时才允许独立Evaluator读取旧Canonical。

## Post-Draft Baseline Differential

Evaluator只比较职责、机制、训练器械和实操资产，不向被冻结Candidate回填旧表达。

发现回归时：

- 本次Standalone结果保持FAIL/BLOCK；
- 不把修补后的同一Candidate继续称为纯Standalone PASS；
- 缺口应进入下一Skill版本或新的独立Forward Run。

这样同时保护“盲测纯度”和“不会因为没看旧书就把成熟职责丢掉”。


## V4.7 Runtime enforcement

Post-Draft Baseline Differential不是“可选增强”。正式SEALED Runtime基准中：
- Canonical可取得：必须运行；
- Canonical不可取得：明确`NOT_RUN`并保持`FINAL_DECISION = BLOCK`；
- 不得用“没有读取旧稿所以更纯”替代Baseline Differential；
- Frozen Candidate保持不变，Evaluator只出差异报告。

Freeze Evidence还必须包含`adequacy_contract.json`；没有它的Freeze不是V4.7完整Freeze。

## V5.1 New-book baseline applicability

SEALED purity does not require inventing a baseline for a book that has never had a Canonical. V5.1 splits the gate:

- PRE_DRAFT: declare `REQUIRED_EXISTING_CANONICAL` or `NOT_APPLICABLE_NEW_BOOK` without searching old content; canonical-promote the declaration audit.
- POST_FREEZE: independently search for **same-book** Canonical identity.
- If same-book Canonical exists, normal Post-Draft Baseline Differential is mandatory.
- If none exists and the N/A declaration was genuinely PRE_DRAFT, `PASS_NOT_APPLICABLE_NEW_BOOK` may close baseline applicability.
- Different-book substitution is forbidden.

A valid N/A does not prove replacement superiority and does not close Real Reader evidence.


## V5.2 Freeze Integrity active delta

A Freeze Record filename or self-declared boolean is not enough. FIRST_FREEZE must be created from the deterministic reader surface and externally re-audited. Any reader-facing add/delete/modify after Freeze invalidates the same SEALED identity. Baseline Applicability POST_FREEZE is downstream of `PASS_FREEZE_INTEGRITY`.


## V5.3 Freeze-first holdout and promise-depth active delta

V5.3 keeps the pre-Freeze Canonical ban. It adds a Canonical-independent Book-Promise Responsibility floor so professional depth is protected from the current book promise itself. FIRST_FREEZE no longer waits for an unavailable external opaque evaluator. After Freeze Integrity passes, the frozen reader tree must pass deterministic local post-freeze holdout; external opaque holdout is optional stronger evidence. Any repair changes reader bytes and therefore requires a new Freeze identity before another holdout can count.


## V5.4 phase-depth and authority-fidelity active delta

V5.4 does not read Canonical before Freeze. It derives pre-build responsibility from the current Reader Transformation and Book Promise, then requires phase-depth applicability and Layer Adequacy. If the Personal Skill runtime cannot execute the bundled verifier, the book may still be generated and frozen, but Runtime Acceptance remains `BLOCK_PENDING_EXTERNAL_VERIFIER` until the published V5.4 verifier re-runs the exact canonical evidence inputs.

## V5.5 Deferred External Closure lane

V5.5 separates generator obligations from external-machine obligations. The generator must finish declarative contracts, root Manifest, Reader-facing bytes, and FIRST_FREEZE snapshot before handoff. If bundled verification is unavailable, canonical audit outputs remain `NOT_RUN`, and the published external verifier closes them on frozen bytes. External closure never upgrades evidence to Real Reader Outcome and never permits Reader mutation after Freeze.
