# Reader Outcome Closure Contract · V4.6

## Purpose

V4.5不增加“更多文字”目标，只阻止技术Gate全绿却损害READ / TRAIN / DO的假成功。

## Hard Gates

```text
BOOK-GATE-READER-FACING-CLEANLINESS
BOOK-GATE-PEDAGOGICAL-RHYTHM-DIVERSITY
BOOK-GATE-PRACTICE-QUALITY-NOT-QUANTITY
BOOK-GATE-FEEDBACK-CLOSURE
BOOK-GATE-PRACTICAL-ASSET-FIDELITY
BOOK-GATE-PRESERVATION-STATE-EVIDENCE
BOOK-GATE-PRESERVATION-MAPPING-SPECIFICITY
BOOK-GATE-DO-FORWARD-EXECUTION
BOOK-GATE-REAL-READER-OUTCOME-CLOSURE
```

### Reader-facing Cleanliness

内部 repair/audit/preservation instruction 必须留在 Evidence/Editorial 层，不得进入最终 Reader Path。

### Rhythm

检测长段落骨架与教学序列，不以“标题已经不同”代替阅读节奏差异。

### Practice

训练以能力和反馈闭环为单位，不以题目数量为单位。关键训练需要 Expected Output、Reference Judgment、Common Error、Correction、Retry。

### Practical Asset Fidelity

旧版高价值模板或工作簿不得被通用壳替换。PRESERVED必须有功能等价Evidence；review未完成只能UNKNOWN/PARTIAL。旧资产映射必须具体到新文件/资产路径，`appendices/（待审）`、`mapped delivery asset` 等目录级或承诺式映射不能证明保全。

### DO

能真实运行的关键路径至少独立执行一次；外部或长期环节明确NOT_RUN，不伪造。

### DO Evidence Separation

Reader Workbook可以并且通常应该保持空白；它不是Skill Forward Validation Evidence。DO验证必须保存在独立Forward Execution Evidence中，记录测试环境、真实输入、步骤、输出、验证和边界。禁止预填Reader Workbook制造PASS。


### Real Reader Evidence is not optional for replacement

机器与AI模拟只能用于预检。完整替换裁决必须读取独立Real Reader Forward Evidence，至少分别关闭：

```text
READ_CONTINUE = PASS
LEARN_TRANSFER = PASS
TRAIN_FEEDBACK = PASS
```

如果真人Evidence未提供、解析失败，或任一项不是`PASS`，即使DO Forward Execution已PASS，仍必须`BLOCK_REPLACEMENT`。不得用`PASS_SIMULATED_ONLY / PASS_STRUCTURE_ONLY`冒充真人Reader Outcome。


## V4.6 Adequacy prerequisites
Reader Outcome Closure前，适用时必须先通过`COMPLEXITY_CALIBRATED_CHAPTER_DEPTH`、`PRACTICAL_ASSET_ADEQUACY`与`TRAINING_INSTRUMENT_STRENGTH`。DO示例执行成功不能抵消读者拿到的工作表/合同过薄。正式Runtime基准还必须保持SEALED_STANDALONE_FORWARD边界，并在封存后运行独立Baseline Differential。


## V4.7 Real Reader status discipline

`REAL_READER_EVIDENCE`只描述“真人是否测试了当前Candidate”，不描述市场研究。
若只有社区帖子、用户痛点研究、公开讨论或专家资料：
`REAL_READER_EVIDENCE = NOT_RUN`。
将这些证据写成PARTIAL属于`REAL_READER_EVIDENCE_CATEGORY_ERROR`并阻断Acceptance。

## V5.0 Reader Outcome active delta

V5.0 保留以上历史 Reader Outcome 合同，并增加两项 active rule：

### Mapping-aware Practical Asset Fidelity

Post-Draft / Replacement 审计不得只按同名文件比较旧新 practical asset。若 Preservation Ledger 提供具体 `old_path -> new_path` 映射，必须优先按映射后的新资产做功能等价检查，至少比较：Context/Task、Input/Evidence、Decision Rule、Execution、Validation/Acceptance、Failure Recovery、Completion、Tracking/Log、Change Control。

对于 substantial 旧资产：
- 没有具体映射：`PRACTICAL_ASSET_FIDELITY_REGRESSION`；
- 映射后功能维度保留率显著不足：BLOCK；
- 只换名但没有可用器械：不能标 PRESERVED。

### Workbook discovery robustness

Reader Outcome / Training 审计必须能发现：
- root `WORKBOOK.md`；
- `workbook/` 目录；
- Manifest 明确声明的 `WORKBOOK_PATH / workbook_path / reader_assets.workbook_path`。

路径发现失败不得被解释成“Workbook 不存在”。Reader Workbook 仍保持读者填写资产身份，不能替代 Forward Execution Evidence。

## V5.1 New-book baseline N/A and Reader Outcome

Reader Outcome accepts `PASS_NOT_APPLICABLE_NEW_BOOK` as a closed **baseline applicability** state for a genuinely new book. It must not create a practical-asset regression comparison against a different book.

This does not weaken the replacement doctrine: READ / LEARN / TRAIN still require genuine Real Reader evidence for full closure, and DO still requires forward execution evidence. New-book baseline N/A is therefore orthogonal to Real Reader closure.


## V5.2 Freeze Integrity and Reader Outcome

Reader Outcome cannot rely on a mutated post-Freeze Candidate while citing earlier machine evidence. When Freeze Integrity evidence is provided/discovered, a non-PASS Freeze report adds `FREEZE_INTEGRITY_NOT_CLOSED`. This does not replace Real Reader READ / LEARN / TRAIN evidence.
