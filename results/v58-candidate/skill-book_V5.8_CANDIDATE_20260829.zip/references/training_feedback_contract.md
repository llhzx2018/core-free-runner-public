# V5.0 Training Feedback Coverage Contract

HIGH training chapter 不能只“有练习”。每个 HIGH chapter 必须在 `evidence/training_feedback_contract.json` 声明至少一个完整反馈环：

`TASK -> EXPECTED OUTPUT -> REFERENCE JUDGMENT -> ERROR CLASS -> CORRECTION -> RETRY -> COMPLETION CONDITION`

PRE_FREEZE 时，声明不能只存在机器 JSON；chapter 或其 `feedback_asset_paths` 中必须存在读者可见的对应反馈信号，例如“参考判断 / 为什么错 / 纠错 / 重试 / 完成条件”。

执行：

```bash
python scripts/training_feedback_audit.py --new <ROOT> --stage PRE_FREEZE --json evidence/training_feedback_pre_freeze.candidate.json
```

任何 HIGH chapter 未映射或反馈闭环不完整：`BOOK-GATE-TRAINING-FEEDBACK-COVERAGE = BLOCK`。
