# Freeze Integrity Contract · V5.3

## Purpose

A file named `freeze_record.json` is not proof that a Candidate was actually frozen. Earlier runtime could accept a structurally trivial record such as `{"freeze":"ok"}` on the new-book N/A path. V5.3 preserves recomputable Freeze a recomputable machine authority.

## FIRST_FREEZE record

After every PRE_FREEZE generation/training gate is closed — including generation Random Open and Shadow Local-Value, but **before post-freeze holdout and before any old same-book lookup** — create:

`evidence/freeze_record.json`

with `create_freeze_record.py`.

The record must contain:

- `version = V5.3_FREEZE_RECORD`
- `stage = FIRST_FREEZE`
- `decision = FROZEN`
- non-empty `book_id` and `book_title`
- `discovery_contract = V5.3_READER_SURFACE_V1`
- complete reader-facing asset list with `path / bytes / sha256`
- `reader_asset_count`
- deterministic `reader_tree_sha256`
- SHA-256 of `evidence/canonical_evidence_state.json`
- `created_at` timestamp

## Deterministic reader surface

The V5.3 discovery contract includes reader-facing files under these roots when present:

`manuscript/`, `chapters/`, `book/chapters/`, `templates/`, `frontmatter/`, `appendices/`, `workbook/`, `operator_reference/`, `operator/`, `examples/`, `delivery/`, `references/`, `reader/`.

It also includes recognized root reader entry files such as `BOOK.*`, `WORKBOOK.*`, `REFERENCES.*`, `README.*`, `TOC.*`, `START_HERE.*`, and numbered `00_*` reader entry files.

Machine evidence, governance, research, audit, cache, scripts and tests are outside the reader surface.

## Audit

Run:

`freeze_integrity_audit.py --new <book_root> --json evidence/freeze_integrity_audit.json`

The audit independently re-discovers the reader surface and recomputes every byte/hash/tree identity.

HARD BLOCK if:

- Freeze Record is missing/invalid or has wrong stage/version/decision;
- book identity is missing;
- reader asset list is empty, duplicated, unsafe, incomplete or contains machine paths;
- any frozen reader file is modified or deleted;
- any newly discoverable reader-facing file appears after Freeze;
- byte count or SHA differs;
- `reader_tree_sha256` differs;
- Canonical Evidence State hash differs or is missing.

A valid result is `PASS_FREEZE_INTEGRITY`.

## Runtime semantics

V5.3 Runtime Acceptance must independently re-run Freeze Integrity before baseline applicability or Post-Draft Baseline logic. Baseline Applicability POST_FREEZE cannot close when Freeze Integrity is not closed.

Freeze Integrity is machine evidence only. It does not replace READ / LEARN / TRAIN / DO Reader Outcome.


## V5.3 ordering rule

`external opaque holdout unavailable` is no longer a reason to postpone FIRST_FREEZE. The mandatory standalone order is `PRE_FREEZE gates → FIRST_FREEZE → PASS_FREEZE_INTEGRITY → local frozen holdout → baseline applicability/differential → Runtime Acceptance`. External opaque holdout, when available, is an additional stronger post-freeze lane.

## V5.5 non-deferable snapshot rule

`FIRST_FREEZE` is a snapshot operation, not a machine-acceptance claim. Therefore Personal Skill inability to execute bundled audits does not excuse a missing `freeze_record.json`. A deferred package without a real deterministic Freeze Record is incomplete and must not be handed off as a V5.5 SEALED package.
