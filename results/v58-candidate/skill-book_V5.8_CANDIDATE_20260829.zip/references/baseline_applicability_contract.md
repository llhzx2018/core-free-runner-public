# Baseline Applicability Contract · V5.3

## Purpose

V5.0 correctly made Post-Draft Baseline Differential a hard gate for replacement/evolution runs, but a fresh C1 benchmark exposed one missing state: a genuinely new book may have no same-book Canonical to compare against. Using a different book as the baseline is invalid; blocking every new-book run forever is also invalid.

V5.1 therefore separates **baseline applicability** from **baseline comparison result**.

## PRE_DRAFT declaration

For `FULL_BOOK / SEALED_STANDALONE_FORWARD`, after Runtime Entry Receipt and before reader-facing Draft, create:

`evidence/baseline_applicability_contract.json`

Allowed applicability values:

- `REQUIRED_EXISTING_CANONICAL`
- `NOT_APPLICABLE_NEW_BOOK`

Minimum fields:

```json
{
  "version": "V5.3_BASELINE_APPLICABILITY_CONTRACT",
  "book_id": "C1",
  "book_title": "...",
  "declaration_stage": "PRE_DRAFT",
  "applicability": "NOT_APPLICABLE_NEW_BOOK",
  "basis": "Book input identifies a new book identity; no prior same-book Canonical is expected.",
  "same_book_identity_required": true,
  "different_book_substitution_forbidden": true,
  "postfreeze_confirmation_required": true
}
```

The PRE_DRAFT declaration **must not search, read, or inspect old book content**. It is an expected applicability declaration, not proof that no Canonical exists.

Run `baseline_applicability_audit.py --stage PRE_DRAFT` and promote the PASS result as a canonical pre-freeze evidence gate.

## POST_FREEZE confirmation

Only after the Candidate is Frozen may an evaluator search for same-book historical Canonical identity.

For `NOT_APPLICABLE_NEW_BOOK`, create:

`evidence/baseline_applicability_postfreeze.json`

Minimum truth:

- same `book_id` and `book_title` as the PRE_DRAFT contract;
- `searched_after_freeze = true`;
- `matching_same_book_canonical_found = false`;
- `different_book_substitution_used = false`;
- `frozen_candidate_modified_after_search = false`;
- exact SHA-256 of the PRE_DRAFT contract;
- exact SHA-256 of `evidence/freeze_record.json`;
- decision `PASS_NOT_APPLICABLE_NEW_BOOK`.

`baseline_applicability_audit.py --stage POST_FREEZE` validates the declaration + Freeze + confirmation.

## Hard anti-bypass rules

1. Existing/replacement book → `REQUIRED_EXISTING_CANONICAL`; no old baseline means BLOCK.
2. `NOT_APPLICABLE_NEW_BOOK` declared after Draft/Freeze → BLOCK.
3. Same-book Canonical discovered after Freeze → N/A invalid, BLOCK; run the normal Post-Draft Baseline Differential.
4. Passing `--old` while declaring N/A → contradiction, BLOCK.
5. A different book, adjacent title, prior series volume, or generic corpus cannot substitute for same-book Canonical.
6. Missing post-Freeze search evidence → BLOCK.
7. Frozen Candidate may not be repaired after seeing baseline/search evidence and still keep the same SEALED PASS identity.
8. `PASS_NOT_APPLICABLE_NEW_BOOK` closes only the **baseline applicability** gate. It does not prove replacement superiority and does not replace Real Reader READ / LEARN / TRAIN evidence.

## Runtime semantics

For SEALED Runtime:

- `REQUIRED_EXISTING_CANONICAL` + valid old Canonical → run Post-Draft Baseline Differential as before.
- `REQUIRED_EXISTING_CANONICAL` + no old Canonical → `POST_DRAFT_BASELINE_DIFFERENTIAL_NOT_RUN / BLOCK`.
- `NOT_APPLICABLE_NEW_BOOK` + valid PRE_DRAFT declaration + valid post-Freeze no-match confirmation → `PASS_NOT_APPLICABLE_NEW_BOOK`; Runtime may continue without a synthetic baseline.
- invalid/missing applicability evidence → BLOCK.
