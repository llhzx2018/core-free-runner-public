# Phase Depth Preservation Contract · V5.4

Purpose: prevent a practical book from protecting one end of the workflow while silently compressing another. This contract is derived from the current Book Promise and Reader Transformation; it never reads historical Canonical content before FIRST_FREEZE.

For PRACTICAL_PROJECT books, `generation_responsibility_contract.json` must include a `phase_depth` matrix with every phase explicitly marked `REQUIRED / OPTIONAL / N_A`:

`PROBLEM_DISCOVERY → OPPORTUNITY_SELECTION → ALTERNATIVE_PRESSURE → PREBUILD_VALIDATION → DEVELOPMENT_ENTRY_DECISION → SCOPE → BUILD → ACCEPTANCE → PRODUCTION → DISCOVERABILITY → ACTIVATION → OBSERVABILITY_DECISION`

The matrix is not a chapter outline. Several phases may share a chapter, and one phase may span chapters. Its job is to make omission visible.

When the current Reader Contract promises a demand/problem-to-build journey, V5.4 infers four pre-build responsibilities from first principles:

- `problem_opportunity_selection`
- `alternative_pressure`
- `prebuild_behavioral_validation`
- `development_entry_decision`

For web/site projects, alternative pressure can be investigated through SERP, competitors, substitutes, direct workflows, or other supply evidence. SERP is not a mandatory chapter or template; the responsibility is to test whether existing supply already completes the user's task and to seek disconfirming evidence.

Each inferred pre-build responsibility must map to Reading Core + differentiated Operator Reference + Practical Asset and declare judgment, execution, validation, failure recovery, and completion. A single universal worksheet may not silently cover more than two distinct high responsibilities without a substantive multi-role rationale.

Canonical remains POST_FREEZE evaluator-only regression evidence. It is not a template, target structure, chapter-count budget, word-count budget, or source for PRE_DRAFT responsibility inference.
