# Generation Depth Contract · V5.8

## Goal

Depth means enough causal, judgment, example, failure, feedback and operational substance to complete a Reader Job. It does not mean a long outline, many headings, or a minimum character count.

## Pre-draft Depth Plan

Each core chapter declares:

- Reader Entry State
- Chapter Job
- Must Explain
- Must Judge
- Must Demonstrate
- Near-miss / Boundaries
- Failure Modes
- Worked Example
- Practice Output
- Feedback / Correction
- Operational Output
- Failure Recovery
- Completion Criteria
- Bridge to Next Chapter

Complexity is inferred from the real Reader Job. The generator cannot downgrade a chapter to LOW merely to justify a short treatment.

## Three writing passes

### Pass A — Causal Core

Write the explanation and judgment first. Establish why the problem behaves as it does, what changes the decision, and what boundaries matter.

### Pass B — Human Reading

Turn the causal core into readable long-form material. Add concrete situations, examples, counterexamples, transitions and rhythm. Remove repetitive AI scaffolding. A chapter should not feel like expanded slide notes.

### Pass C — Transfer + Operation

Add changed-case judgment, practice, feedback, operational outputs, validation and failure recovery where relevant.

Do not aggressively compress before all three passes are complete.

## Local chapter check

Immediately after each core chapter:

1. Can a target reader explain why, not only what?
2. Can they distinguish a plausible near-miss?
3. Is there enough concrete material to see the rule operate?
4. Does the chapter create or change an artifact/decision/state used later?
5. If the chapter covers a high-complexity job, is the treatment obviously more than a summary?
6. Is the chapter form appropriate, or is it repeating a fixed template?

## Full-book shell-risk check

Before Freeze, use `references/full_book_substance_contract.md`.

Risk signals include:

- many high-complexity chapters with very short bodies;
- heading/bullet density much higher than explanatory prose;
- examples that are only one-line illustrations;
- steps without diagnostic/failure paths;
- repeated chapter skeletons;
- content delegated to templates/references;
- chapters that can be removed or reordered without changing reader state.

Character/word counts are only shell-risk signals. They cannot grant PASS. They can force semantic review.

## Continuous reading

After local checks, sample adjacent three-chapter windows under `references/continuous_reading_contract.md`. Local chapter PASS does not imply continuous-reading PASS.

## Mass Compression Stop

Stop incremental patching and return to the Depth Plan when any of these occur:

- >= 4 core chapters show thin-shell risk;
- >= 4 chapters fail local Reader Job completion;
- repeated template/uniformity appears across a large section;
- the manuscript becomes shorter primarily by deleting causal explanation/examples rather than redundancy;
- the book is drifting from FULL_BOOK toward HANDBOOK / COURSE_NOTES without OWNER intent.

## Repair principle

Repair responsibilities, not length. Add the missing reason, judgment, example, failure, feedback, or operation. Do not pad prose merely to cross a threshold.
