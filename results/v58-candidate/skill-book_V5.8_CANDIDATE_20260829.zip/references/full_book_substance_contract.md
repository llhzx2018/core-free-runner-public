# Full Book Substance Contract · V5.8

## Purpose

Prevent a structurally complete package from being mislabeled a complete book when the manuscript is actually an outline expansion, course note, checklist collection, or thin handbook.

This contract applies before FIRST_FREEZE when `PRODUCT_CLASS = FULL_BOOK`.

## Authority principle

`chapter_count != chapter_substance`  
`package_integrity != book_quality`  
`template_count != reader_transformation`

A FULL_BOOK chapter must complete a real Reader Job. Presence of headings or keywords is not evidence of completion.

## Required pre-draft declaration

`evidence/full_book_substance_contract.json` must declare:

- product_class
- reader
- book_promise
- core_chapters
- support_chapters
- core_reader_jobs
- high_complexity_chapters
- expected_continuity_links
- substance_dimensions per core chapter
- shell_risk_policy

For each core chapter, substance dimensions may include:

- situation / stakes
- causal explanation
- mental model
- decision rule
- boundary
- near-miss
- worked example
- failure mode
- recovery
- practice
- feedback
- operational output
- completion criteria
- bridge to next chapter

Not every chapter needs every dimension. The contract must explain why omitted dimensions are not needed for that chapter's Reader Job.

## Semantic audit

`evidence/full_book_substance_audit.json` must classify each core chapter:

- `SUBSTANTIVE`
- `BORDERLINE`
- `THIN_SHELL`
- `OUTLINE_EXPANSION`
- `CHECKLIST_DOMINANT`
- `REFERENCE_DEPENDENT`

The audit must cite actual reader-facing evidence, not just headings.

A chapter cannot be `SUBSTANTIVE` merely because it contains words such as Example, Practice, Failure, Checklist, Output, or Completion.

## Thin-shell risk signals

The following are risk signals, not standalone quality scores:

- unusually short chapter body for a high-complexity Reader Job;
- many headings with little prose between them;
- bullet/table dominance where causal explanation is needed;
- one small example used to stand in for an entire judgment domain;
- practice without feedback;
- steps without failure recovery;
- repeated fixed chapter template;
- chapter output not used later;
- chapter can be removed without changing Reader State.

For Chinese FULL_BOOK manuscripts, if many core chapters are below roughly 1800 CJK characters, the generator must classify `THIN_SHELL_RISK = HIGH` and perform semantic re-audit. Equivalent language-sensitive thresholds may be used for other languages. This threshold can trigger review but cannot by itself grant PASS.

## Hard block

`FULL_BOOK_SUBSTANCE = BLOCK` when any of the following holds:

1. >= 40% of core chapters are `THIN_SHELL`, `OUTLINE_EXPANSION`, or `CHECKLIST_DOMINANT`.
2. A promised critical capability has no chapter that explains, demonstrates, trains, and operationalizes it at the required complexity.
3. High-complexity chapters are systematically shorter/simpler because details were pushed into references/templates.
4. The manuscript reads as a summary of what a full book should contain rather than the book itself.
5. Reader-facing assets are mostly complete but the manuscript cannot independently teach the promised transformation.

## Repair rule

When blocked, return to Depth Plan and rewrite affected chapters. Do not:

- add filler words;
- duplicate summaries;
- expand every bullet into generic prose;
- add more templates to compensate;
- lower declared complexity;
- change PRODUCT_CLASS to HANDBOOK after seeing the failure unless the OWNER explicitly changes the product request.

Repair must add missing causal, judgment, example, failure, feedback, or operational substance.

## A1 V5.7 regression fixture principle

A known failure shape that V5.8 must reject is:

- 18 chapters present;
- topics and direction broadly correct;
- package/audit/templates complete;
- manuscript around 25k CJK-scale characters with many core chapters around 0.8k–1.5k characters;
- engineering-oriented English reader-facing names for a Chinese book.

This shape is evaluator regression evidence only. It must not be used as generation content or as a template for future A1 manuscripts.
