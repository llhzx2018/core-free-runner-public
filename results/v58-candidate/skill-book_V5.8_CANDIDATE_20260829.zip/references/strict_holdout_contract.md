# V5.3 Holdout Contract

V5.3 separates **Freeze safety** from **holdout strength**. An unavailable external opaque evaluator must not prevent FIRST_FREEZE forever.

## Lane A — Local Frozen Holdout (mandatory for SEALED standalone)

1. Complete all PRE_DRAFT / PRE_FREEZE generation gates.
2. Create FIRST_FREEZE and close Freeze Integrity.
3. Run `scripts/postfreeze_holdout_audit.py` against the frozen reader tree.
4. The deterministic sampling commitment is derived from the frozen `reader_tree_sha256`; sample details may be visible because reader bytes are already frozen.
5. Any failed sample leaves Runtime Acceptance BLOCK. Repair requires changing reader bytes, which invalidates Freeze Integrity; the repaired candidate must create a **new FIRST_FREEZE identity**, yielding a new tree-derived sampling commitment.

Valid decision: `PASS_LOCAL_POSTFREEZE_HOLDOUT`. Evidence strength: `LOCAL_FROZEN_NON_OPAQUE`. This is machine evidence, not strict unseen proof and not Real Reader evidence.

## Lane B — External Opaque Holdout (optional stronger evidence)

When an independent evaluator exists, it may additionally produce `strict_unseen_holdout_receipt.json` containing only aggregate fields:

- `decision`
- `sample_count`
- `failed_count`
- `failure_classes`
- `evaluator_id`
- `run_id`
- `seed_commitment`
- `generator_exposure = NONE | OPAQUE_AGGREGATE_ONLY`

Forbidden: `seed / seeds / path / paths / window / windows / sample_details / details`.

A valid external receipt strengthens evidence to `EXTERNAL_OPAQUE_PLUS_LOCAL_FROZEN`; its absence does **not** convert the local lane into strict unseen proof.
