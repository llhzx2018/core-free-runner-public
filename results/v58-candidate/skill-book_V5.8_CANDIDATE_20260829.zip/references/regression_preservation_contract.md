# Regression Preservation Contract · V4.6

1. 枚举全部旧版来源，优先完整Canonical。
2. 记录章节、模板、附录、Reference、Workbook与学习支架资产。
3. STANDALONE模式Draft前只允许读取旧版身份、目录职责、资产清单与结构指标；旧正文表达在Draft冻结后才进入回归审阅。
4. 每章比较Reading Core + Operator Reference + Template/Worksheet。
5. 旧资产状态仅允许PRESERVED/IMPROVED/PARTIAL/LOST/SUPERSEDED/UNKNOWN。PARTIAL/LOST/UNKNOWN默认阻断替换。
6. Reading Core或Bundle缩减超过25%是风险硬信号；不得用全书总字数抵消。
7. Reference检查参数/规则/边界/示例/错误/恢复/判断/验证；Template检查字段/示例/判断/回滚/完成记录。
8. 四章以上同质Reference/Template触发Uniformity Review。

9. V4.5：`PRESERVED/IMPROVED`必须已有完成Evidence；`post-generation review required`与PRESERVED同存为BLOCK。
10. V4.5：高价值Template/Worksheet/Acceptance Record逐资产做功能等价；明显缩水不能由正文总长度抵消。
11. V4.5：改名/合并必须明确old→new映射与preserved/superseded/lost/unknown functions。

12. V4.6：正式Runtime基准使用SEALED_STANDALONE_FORWARD，旧Canonical在Candidate冻结前完全不可见。
13. V4.6：冻结后独立Evaluator运行Post-Draft Baseline Differential；职责/结构明显退化时本轮Standalone保持BLOCK，不在同一Candidate上回填旧表达制造PASS。
14. V4.6：长度只作为风险信号；实际裁决优先看职责维度、结构单元、失败恢复、验收、变更控制和完成条件。
