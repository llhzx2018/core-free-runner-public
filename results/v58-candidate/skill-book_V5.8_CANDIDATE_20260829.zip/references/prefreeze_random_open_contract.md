# Generation Random Open + Shadow Contract · V5.3

整章通过 Adequacy，不代表随机打开真实局部仍有价值。V5.3 保留生成期两道可见局部价值 Gate，但不再把它们冒充 post-freeze holdout。

## Required PRE_FREEZE Evidence

FULL_BOOK / SEALED_STANDALONE_FORWARD 在 FIRST_FREEZE 前必须生成并真实执行：

- `evidence/prefreeze_random_open.json` — Generation Random Open
- `evidence/shadow_local_value.json` — second sampling space / stricter local-value floor

修复后的 PASS 必须经过 Canonical Evidence Promotion，才可成为 FIRST_FREEZE 前 Authority。

## Rules

1. 抽样对象必须来自真实 reader paths：章节、Templates/Worksheets、Operator References（如存在）。
2. 只抽标题、指针、空字段、通用壳、过薄段落或无法形成判断/动作/产出的局部为 FAIL。
3. PRE_FREEZE FAIL 可以系统性修稿并重跑，但不能只给已经抽中的位置补字。
4. Generation Random Open 与 Shadow Local-Value 任一未关闭：不得 FIRST_FREEZE。
5. **External opaque holdout 不再是 FIRST_FREEZE 前置条件。** FIRST_FREEZE 之后，冻结 reader tree 必须运行 `postfreeze_holdout_audit.py`。
6. Frozen Local Holdout FAIL 后，不允许在同一 Freeze identity 上修稿；任何 reader byte 改动都会使 Freeze Integrity BLOCK，必须新 Freeze 后再测。
7. 字符 floor 只用于薄壳反证，不构成价值 PASS；PASS 还必须出现足够的判断、执行、验证或错误恢复信号。
8. 外部 opaque receipt 若可用，是 post-freeze 更强证据；不可用时不得伪造 strict unseen PASS。
