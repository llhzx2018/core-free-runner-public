# Evidence Budget Contract · V5.8

## Purpose

Prevent governance/evidence production from consuming the writing process or creating false confidence through file count.

## Rule

`Evidence exists to prove the book. The book does not exist to satisfy Evidence.`

## Canonical evidence

Prefer one canonical input per responsibility plus machine-derived outputs. Do not create multiple prose mirrors of the same state only to increase traceability appearance.

A FULL_BOOK run should maintain the V5.8 mandatory evidence set defined in `SKILL.md`. Legacy V5.7 evidence remains valid when required by an actual verifier or promotion gate, but is not mandatory merely because an older package contained it.

## Prohibited evidence bloat

- duplicate status files that repeat Manifest fields;
- prose PASS reports without new evidence;
- per-chapter JSON files when a single chapter matrix is sufficient;
- copied verifier outputs renamed as new audits;
- creating a template only so an audit can count it;
- delaying manuscript work to fill non-gating metadata.

## Gate rule

Evidence reduction must never weaken:

- Runtime identity boundary;
- Baseline isolation;
- Full-book substance;
- Continuous reading;
- Training feedback;
- Operational closure;
- Practical asset depth;
- Freeze integrity;
- Reader transfer;
- Reader-facing packaging;
- Real Reader authority boundary.

If a verifier requires an input not present in the compact set, create that input because it is functionally required, not because 'more evidence is better'.
