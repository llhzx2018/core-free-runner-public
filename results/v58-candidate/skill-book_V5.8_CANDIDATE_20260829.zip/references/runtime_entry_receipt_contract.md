# Runtime Entry Receipt Contract · V5.8

`FULL_BOOK` / `SEALED_STANDALONE_FORWARD` 的第一份机器资产必须是：

`evidence/runtime_entry_receipt.json`

固定合同标识：

`SB58-RUNTIME-CONTRACT-BF41D2E7`

最低字段：

```json
{
  "runtime_contract_id": "SB58-RUNTIME-CONTRACT-BF41D2E7",
  "skill_name": "skill-book",
  "declared_skill_version": "5.8",
  "entry_stage": "PRE_DRAFT",
  "operation": "BOOK.OP.FULL_MANUSCRIPT",
  "work_mode": "FULL_BOOK",
  "evidence_mode": "SEALED_STANDALONE_FORWARD",
  "mandatory_evidence": [
    "evidence/reader_transformation_contract.json",
    "evidence/baseline_applicability_pre_draft.json",
    "evidence/full_book_substance_contract.json",
    "evidence/full_book_substance_audit.json",
    "evidence/continuous_reading_audit.json",
    "evidence/training_feedback_pre_freeze.json",
    "evidence/operational_closure_pre_freeze.json",
    "evidence/reader_facing_packaging_audit.json",
    "evidence/freeze_record.json",
    "evidence/freeze_integrity_audit.json",
    "evidence/reader_transfer_contract.json",
    "evidence/runtime_authority_status.json",
    "evidence/runtime_acceptance_audit.json"
  ]
}
```

## Rules

1. Receipt 必须在正文 Draft 前生成；事后补写不能证明 Entry 生效。
2. `runtime_contract_id` 不得从用户 Benchmark Prompt 获取；正式 Benchmark Prompt 不应包含该值。
3. Personal Skill UI 若不暴露独立 Runtime metadata，记录 `RUNTIME_SELF_INTROSPECTION = NOT_EXPOSED` 并继续；不得把版本写成 UNKNOWN。
4. Receipt 缺失或 ID / version 错误：`RUNTIME_ENTRY_RECEIPT = BLOCK`。
5. Receipt 不是密码学证明；External Verifier 仍需复核适用的 canonical inputs。
6. V5.8 引入 Evidence Budget：旧 V5.7 的 Adequacy / Practical Asset Depth / Holdout / Canonical Evidence inputs 在相应 verifier 或 promotion gate 需要时继续生成，但不得仅为了复制旧包文件数量而重复制造 prose evidence。
7. `FULL_BOOK_SUBSTANCE`、`CONTINUOUS_READING`、`READER_FACING_PACKAGING` 是 FIRST_FREEZE 前新硬门；任何一项 BLOCK 都不能被旧版 Random Open / package integrity / chapter coverage PASS 抵消。
8. Baseline Applicability 仍在 PRE_DRAFT 声明，FIRST_FREEZE 前不得读取历史同书证明 N/A；FIRST_FREEZE 后才允许 evaluator-only 历史检索。
9. V5.6 Practical Asset Depth 与 V5.7 Reader Transfer authority boundary 保留：Workbook 不能救薄 Template；Blind Proxy PASS 不能提升 `REAL_READER_EVIDENCE`。
10. 正式机器 verifier 无法执行时必须记录 `machine_execution_status = NOT_RUN`，不得写弱版替代并宣称 PASS。
