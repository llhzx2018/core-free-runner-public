# Practical Asset Responsibility Depth Contract · V5.6 WIP

Status: `DESIGN_GATE / WIP / NOT CANDIDATE / NOT CURRENT`

V5.6 fixes a specific false-green class:

`RESPONSIBILITY_DIMENSION_PRESENCE != RESPONSIBILITY_DEPTH`

The existing Adequacy Gate remains authoritative for asset presence, complexity, responsibility-surface breadth, shell risk, structure, and training strength. This contract adds a deeper question: **when a responsibility dimension is REQUIRED, does the reader-facing asset contain enough operator structure to use that responsibility independently?**

This contract does not reward length and does not restore historical Canonical structure.

## 1. Authority Boundary

Before FIRST_FREEZE, depth requirements may be derived only from:

`Book Promise + Reader Transformation Contract + Lifecycle / Phase Responsibilities + Operational Closure + Asset Role`

Historical Canonical remains `FIRST_FREEZE+ evaluator-only; never generation template`.

A1-specific chapter names, website fields, SEO vocabulary, deployment vocabulary, historical field counts, and historical word counts MUST NOT become generic generation requirements.

## 2. Evidence Files

For practical FULL_BOOK work, generate before Draft:

`evidence/practical_asset_depth_contract.json`

After real assets exist and before FIRST_FREEZE, run:

`python scripts/practical_asset_depth_audit.py --new <ROOT> --json evidence/practical_asset_depth_audit.json`

Missing contract or a BLOCK audit forbids FIRST_FREEZE for a practical book whose Reader Transformation requires reader-facing operator assets.

## 3. Generic Asset Roles

Supported role families:

- `evidence_capture`
- `decision_record`
- `plan_or_contract`
- `execution_brief_or_log`
- `acceptance_record`
- `baseline_snapshot`
- `iteration_log`
- `next_decision`

One asset may carry adjacent roles. A universal blank table may not self-declare every role merely to satisfy coverage.

For HIGH assets, the verifier independently checks role-implied dimensions and may block a profile that underdeclares them.

## 4. Depth Means Sub-responsibility Closure

A dimension is not deep merely because its label appears once.

### Input / Evidence

Applicable depth may include:

- evidence item / observation;
- provenance / source;
- date, version, session, or sampling context;
- confidence / quality / counter-evidence / UNKNOWN;
- raw fact vs interpretation boundary;
- downstream decision or action linkage.

`Observation: ____` alone is not an evidence system for a HIGH evidence-capture asset.

### Decision Rule

Applicable depth may include:

- options / candidate states;
- criteria / thresholds;
- evidence used by the rule;
- outcome;
- rationale / tradeoff;
- uncertainty / exception handling;
- revisit / reversal trigger.

`Decision: ____` without criteria and revisit logic is not a decision system.

### Evidence Log / Trace

Applicable depth may include:

- stable evidence/event/record ID;
- source / actor provenance;
- time / version;
- action or observation;
- result;
- interpretation;
- link to a decision, change, acceptance, or retry.

A `Date | Note` table is a thin trace for a HIGH execution log.

### Failure Recovery

Applicable depth may include:

- failure/anomaly trigger;
- diagnosis / likely cause;
- recovery action;
- retry condition;
- post-retry evidence;
- escalation / PAUSE / STOP condition.

`Retry if needed` does not close a recovery loop.

### Change Control

Applicable depth may include:

- baseline/current version;
- proposed change;
- reason / supporting evidence;
- owner / authority where relevant;
- impact / affected assumptions;
- revalidation;
- superseded / rollback / freeze state;
- accept / reject / defer disposition.

A single `Version: ____` field is not change control.

### Example / Guidance

Applicable depth may include:

- worked or partially filled example;
- reference judgment;
- why the judgment is reasonable;
- common wrong interpretation / anti-example;
- adaptation guidance for a different case.

A single sample value is not operator guidance.

## 5. Role-sensitive Mandatory Anchors

The verifier must combine declared dimensions with generic role expectations.

- `evidence_capture`: evidence item + provenance + uncertainty/quality + downstream linkage; trace identity/provenance/observation/linkage.
- `decision_record`: options + criteria + outcome + rationale + revisit trigger.
- `plan_or_contract`: baseline/change/reason/revalidation when change control is applicable.
- `execution_brief_or_log`: ordered execution + deep evidence trace + diagnosis/recovery/retry/escalation loop.
- `acceptance_record`: expected + actual + method + result state + defect/rework.
- `baseline_snapshot`: provenance/time context + baseline/supersession semantics.
- `iteration_log`: stable trace + result + interpretation + linkage + next judgment.
- `next_decision`: criteria + outcome + rationale + revisit trigger.

The exact number of headings, fields, or characters does not prove closure. Mandatory anchors are semantic responsibilities, not formatting quotas.

## 6. Blocking Families

Current WIP block families:

- `PRACTICAL_ASSET_DEPTH_CONTRACT_MISSING`
- `PRACTICAL_ASSET_DEPTH_CONTRACT_PARSE_ERROR`
- `PRACTICAL_ASSET_ROLE_UNDERDECLARED`
- `PRACTICAL_ASSET_DEPTH_UNDERDECLARED`
- `PRACTICAL_ASSET_REQUIRED_SUBRESPONSIBILITY_MISSING`
- `PRACTICAL_ASSET_EVIDENCE_LOG_SHALLOW`
- `PRACTICAL_ASSET_CHANGE_CONTROL_SHALLOW`
- `PRACTICAL_ASSET_EXAMPLE_GUIDANCE_SHALLOW`
- `PRACTICAL_ASSET_RECOVERY_LOOP_INCOMPLETE`

Additional topology-specific blocks such as trace-chain breakage may be added only when adversarial tests demonstrate a real false-green class.

## 7. Anti-bloat Rule

Depth is proven by an operator loop, not bulk.

A concise asset can PASS when its required role responsibilities are complete. A long asset must BLOCK when it contains labels, prose, or sample values without the rule/evidence/recovery/change/closure structure required by its role.

Character count and structure count remain shell-risk detectors only and cannot independently produce PASS.

## 8. Non-A1 Domain Guard

Before V5.6 Candidate authorization, depth validation MUST include a non-software adversarial domain.

Current required domain: independently organize a 20-person offline reading-club event.

The targeted machine suite must distinguish strong vs thin:

- participant evidence capture;
- venue/format decision;
- plan/change control;
- run brief/evidence trace;
- incident recovery;
- example/reference guidance.

The suite must not rely on website, SEO, deployment, AI-build, or software vocabulary.

## 9. Current WIP Evidence

TDD RED baseline was established before the verifier existed. After the first implementation:

- non-A1 targeted depth tests: `12/12 PASS`
- inherited Adequacy tests: `6/6 PASS`

These are machine design-gate results only. They do not authorize V5.6 Candidate status and do not constitute Real Reader Evidence.
