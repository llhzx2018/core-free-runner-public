import json,subprocess
from pathlib import Path
R=Path(__file__).parents[1];S=R/'scripts'/'runtime_authority_fidelity_audit.py';RID='SB58-RUNTIME-CONTRACT-BF41D2E7'
CORE=(
 'evidence/runtime_entry_receipt.json','evidence/reader_transformation_contract.json','evidence/baseline_applicability_pre_draft.json',
 'evidence/full_book_substance_contract.json','evidence/full_book_substance_audit.json','evidence/continuous_reading_audit.json',
 'evidence/training_feedback_pre_freeze.json','evidence/operational_closure_pre_freeze.json','evidence/reader_facing_packaging_audit.json',
 'evidence/freeze_record.json','evidence/freeze_integrity_audit.json','evidence/reader_transfer_contract.json','evidence/runtime_acceptance_audit.json',
 'evidence/practical_asset_depth_contract.json','evidence/practical_asset_depth_audit.json','evidence/reader_transfer_proxy.json','evidence/reader_transfer_audit.json')
def w(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
def fixture(root,execution='NOT_RUN',claim='BLOCK_PENDING_EXTERNAL_VERIFIER',final='BLOCK',sealed=False):
 for rel in CORE:w(root/rel,{})
 w(root/'evidence'/'runtime_authority_status.json',{'runtime_contract_id':RID,'declared_skill_version':'5.8','authority_mode':'EXTERNAL_VERIFIER_PENDING' if execution=='NOT_RUN' else 'BUNDLED_VERIFIER','machine_execution_status':execution,'runtime_acceptance_claim':claim,'canonical_inputs':list(CORE)})
 w(root/'manifest.json',{'machine_execution_status':execution,'final_decision':final,'TEST_MODE':'SEALED_STANDALONE_FORWARD_TEST' if sealed else 'STANDALONE'})
def run(root):
 out=root/'fidelity.json';cp=subprocess.run(['python',str(S),'--new',str(root),'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())
def test_not_run_pending_external_is_truthful(tmp_path):
 fixture(tmp_path);cp,r=run(tmp_path);assert cp.returncode==0,r;assert r['decision']=='PASS'
def test_not_run_cannot_claim_pass(tmp_path):
 fixture(tmp_path,claim='PASS_RUNTIME_ACCEPTANCE',final='PASS_RUNTIME_ACCEPTANCE');cp,r=run(tmp_path);assert cp.returncode!=0;assert 'NOT_RUN_CANNOT_CLAIM_RUNTIME_PASS' in r['blocks'];assert 'RUNTIME_AUTHORITY_FALSE_GREEN' in r['blocks']
def test_reader_first_inputs_are_canonical(tmp_path):
 fixture(tmp_path);(tmp_path/'evidence'/'full_book_substance_audit.json').unlink();cp,r=run(tmp_path);assert cp.returncode!=0;assert 'CANONICAL_RUNTIME_INPUTS_MISSING' in r['blocks']
def test_packaging_input_is_canonical(tmp_path):
 fixture(tmp_path);(tmp_path/'evidence'/'reader_facing_packaging_audit.json').unlink();cp,r=run(tmp_path);assert cp.returncode!=0;assert 'CANONICAL_RUNTIME_INPUTS_MISSING' in r['blocks']
def test_depth_and_transfer_authority_retained(tmp_path):
 fixture(tmp_path);(tmp_path/'evidence'/'practical_asset_depth_audit.json').unlink();cp,r=run(tmp_path);assert cp.returncode!=0;assert 'CANONICAL_RUNTIME_INPUTS_MISSING' in r['blocks']
def test_weak_alternate_audit_cannot_authorize(tmp_path):
 fixture(tmp_path);w(tmp_path/'AUDITS'/'RUNTIME_ACCEPTANCE.json',{'decision':'PASS_RUNTIME_ACCEPTANCE'});cp,r=run(tmp_path);assert cp.returncode!=0;assert 'WEAK_ALTERNATE_RUNTIME_AUDIT_CANNOT_AUTHORIZE' in r['blocks']
def test_executed_bundled_lane_can_declare_pass(tmp_path):
 fixture(tmp_path,execution='EXECUTED',claim='PASS_RUNTIME_ACCEPTANCE',final='PASS_RUNTIME_ACCEPTANCE');cp,r=run(tmp_path);assert cp.returncode==0,r;assert r['decision']=='PASS'
def test_deferred_sealed_requires_freeze_record(tmp_path):
 fixture(tmp_path,sealed=True);(tmp_path/'evidence'/'freeze_record.json').unlink();cp,r=run(tmp_path);assert cp.returncode!=0;assert 'CANONICAL_RUNTIME_INPUTS_MISSING' in r['blocks'];assert 'DEFERRED_SEALED_REQUIRES_FIRST_FREEZE_RECORD' in r['blocks']
