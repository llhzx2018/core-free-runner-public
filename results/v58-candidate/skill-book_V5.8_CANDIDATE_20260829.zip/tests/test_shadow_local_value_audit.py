import subprocess,tempfile,unittest,json
from pathlib import Path
R=Path(__file__).parents[1];S=R/'scripts'/'shadow_local_value_audit.py'
def w(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
RICH='# C\n## 判断执行验证\n'+('输入 判断 规则 动作 执行 验证 验收 失败 恢复 重试 完成。'*45)
class T(unittest.TestCase):
 def test_rich_reader_paths_pass(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);w(root/'chapters'/'01.md',RICH);w(root/'templates'/'01.md','## 目标\n'+RICH+'\n- 输入\n- 判断\n- 验证');out=root/'o.json';cp=subprocess.run(['python',str(S),'--new',str(root),'--json',str(out)],capture_output=True,text=True);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
 def test_thin_paths_block(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);w(root/'chapters'/'01.md','# C\n## x\n很短。');out=root/'o.json';cp=subprocess.run(['python',str(S),'--new',str(root),'--json',str(out)],capture_output=True,text=True);j=json.loads(out.read_text());self.assertNotEqual(cp.returncode,0);self.assertIn('SHADOW_LOCAL_VALUE_FAIL',j['blocks'])
if __name__=='__main__':unittest.main()


def test_terminal_asset_window_gets_bidirectional_bounded_context(tmp_path):
 w(tmp_path/'chapters'/'01.md',RICH)
 w(tmp_path/'templates'/'01.md','# Tool\n\n## Rules\n\n'+('输入 判断 规则 动作 执行 验证 验收 失败 恢复 重试 完成。'*35)+'\n\n## Verify\n\n- 验证\n- 重试\n\n## Last\n\n短结尾。')
 out=tmp_path/'o.json';cp=subprocess.run(['python',str(S),'--new',str(tmp_path),'--json',str(out)],capture_output=True,text=True);assert cp.returncode==0,cp.stdout+cp.stderr
