import json,subprocess,sys,tempfile
from pathlib import Path
R=Path(__file__).parents[1];CREATE=R/'scripts'/'create_freeze_record.py';AUDIT=R/'scripts'/'postfreeze_holdout_audit.py'
def rich(i):
 return f'# Ch {i}\n'+''.join(f'\n## S {j}\n'+('判断规则 输入输出 执行步骤 验证验收 失败恢复 重试完成。'*30) for j in range(1,5))
def fixture(root):
 (root/'chapters').mkdir(parents=True);(root/'evidence').mkdir()
 (root/'evidence'/'canonical_evidence_state.json').write_text('{}')
 for i in range(1,5):(root/'chapters'/f'{i:02d}.md').write_text(rich(i))
 cp=subprocess.run([sys.executable,str(CREATE),'--new',str(root),'--book-id','X','--book-title','Fixture'],capture_output=True,text=True);assert cp.returncode==0,cp.stdout+cp.stderr
def run(root):
 out=root/'evidence'/'postfreeze_local_holdout.json';cp=subprocess.run([sys.executable,str(AUDIT),'--new',str(root),'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())
def test_frozen_holdout_passes(tmp_path):
 fixture(tmp_path);cp,r=run(tmp_path);assert cp.returncode==0;assert r['decision']=='PASS_LOCAL_POSTFREEZE_HOLDOUT';assert r['sample_count']==12
def test_reader_mutation_blocks(tmp_path):
 fixture(tmp_path);(tmp_path/'chapters'/'01.md').write_text(rich(1)+'mutation');cp,r=run(tmp_path);assert cp.returncode!=0;assert 'FREEZE_INTEGRITY_NOT_CLOSED' in r['blocks']

def test_v55_operational_reference_vocabulary_counts_as_local_value():
    import importlib.util,sys
    sys.path.insert(0,str(R/'scripts'))
    spec=importlib.util.spec_from_file_location('v55post',AUDIT);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    text='''## Evidence\nStatus: verified. Submit sitemap. Request inspection. Test live page. Evidence count and definition recorded. Troubleshoot failure.'''*4
    ok,chars,groups,reasons=m.local_value(text,text)
    assert ok,(chars,groups,reasons)
    assert len(groups)>=2
