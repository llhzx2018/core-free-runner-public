import json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1];CREATE=R/'scripts'/'create_freeze_record.py';AUDIT=R/'scripts'/'freeze_integrity_audit.py'
def w(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def run(root):
 out=root/'out.json';cp=subprocess.run(['python',str(AUDIT),'--new',str(root),'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())
class T(unittest.TestCase):
 def fixture(self):
  td=tempfile.TemporaryDirectory();r=Path(td.name);w(r/'BOOK.md','# Book\nreader');w(r/'chapters'/'01.md','# 01\nbody');w(r/'templates'/'01.md','# Tool\ninput decision validation recovery');w(r/'evidence'/'canonical_evidence_state.json',json.dumps({'gates':['x']}));w(r/'evidence'/'baseline_applicability_contract.json',json.dumps({'book_id':'D1','book_title':'Demo'}));return td,r
 def freeze(self,r):
  cp=subprocess.run(['python',str(CREATE),'--new',str(r)],capture_output=True,text=True);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
 def test_valid_freeze_passes(self):
  td,r=self.fixture();self.freeze(r);cp,x=run(r);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertEqual(x['decision'],'PASS_FREEZE_INTEGRITY');td.cleanup()
 def test_dummy_freeze_record_blocks(self):
  td,r=self.fixture();w(r/'evidence'/'freeze_record.json',json.dumps({'freeze':'ok'}));cp,x=run(r);self.assertNotEqual(cp.returncode,0);self.assertIn('FREEZE_RECORD_VERSION_INVALID',x['blocks']);td.cleanup()
 def test_modified_reader_file_blocks(self):
  td,r=self.fixture();self.freeze(r);w(r/'chapters'/'01.md','# 01\nmutated');cp,x=run(r);self.assertNotEqual(cp.returncode,0);self.assertIn('FROZEN_READER_ASSET_HASH_DRIFT',x['blocks']);td.cleanup()
 def test_added_reader_file_blocks(self):
  td,r=self.fixture();self.freeze(r);w(r/'appendices'/'A.md','# added');cp,x=run(r);self.assertNotEqual(cp.returncode,0);self.assertIn('READER_ASSET_ADDED_AFTER_FREEZE',x['blocks']);td.cleanup()
 def test_deleted_reader_file_blocks(self):
  td,r=self.fixture();self.freeze(r);(r/'templates'/'01.md').unlink();cp,x=run(r);self.assertNotEqual(cp.returncode,0);self.assertIn('FROZEN_READER_ASSET_MISSING',x['blocks']);td.cleanup()
 def test_canonical_state_drift_blocks(self):
  td,r=self.fixture();self.freeze(r);w(r/'evidence'/'canonical_evidence_state.json',json.dumps({'gates':['changed']}));cp,x=run(r);self.assertNotEqual(cp.returncode,0);self.assertIn('FREEZE_CANONICAL_EVIDENCE_STATE_HASH_DRIFT',x['blocks']);td.cleanup()
if __name__=='__main__':unittest.main()
