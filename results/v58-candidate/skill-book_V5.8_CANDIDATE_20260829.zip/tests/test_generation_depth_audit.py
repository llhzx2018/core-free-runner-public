import unittest,tempfile,subprocess,sys,json
from pathlib import Path
R=Path(__file__).parents[1]
REQ=['Reader Entry','Chapter Job','Must Explain','Must Judge','Must Demonstrate','Worked Example','Practice','Feedback','Failure Recovery','Completion Criteria','Operator Reference Scope','Template/Worksheet Scope','Promise Responsibility IDs','Operator Depth Bundle','Random Open Value Promise']
class T(unittest.TestCase):
 def fixture(self,good=True,nested=False,governance=False):
  td=tempfile.TemporaryDirectory();root=Path(td.name)
  cdir=root/'book'/'chapters' if nested else root/'manuscript';cdir.mkdir(parents=True)
  if governance:
   sections=[]
   for i in range(1,5):sections.append(f"## {i:02d} Chapter {i}\n"+'\n'.join(f'### {x}\n具体值' for x in (REQ if good else REQ[:-2])))
   p=root/'governance'/'DEPTH_PLAN.md';p.parent.mkdir();p.write_text('\n\n'.join(sections),encoding='utf-8')
  else:
   (root/'depth_plan').mkdir()
   for i in range(1,5):
    body='\n'.join(f'## {x}\n具体值' for x in (REQ if good else REQ[:-2]));(root/'depth_plan'/f'{i:02d}_plan.md').write_text(body,encoding='utf-8')
  for i in range(1,5):(cdir/f'{i:02d}_c.md').write_text('# 第 %d 章\n正文'%i,encoding='utf-8')
  return td,root
 def audit(self,root):
  out=root/'gd.json';p=subprocess.run([sys.executable,str(R/'scripts/generation_depth_audit.py'),'--new',str(root),'--expected-chapters','4','--json',str(out)],capture_output=True,text=True);return p,json.loads(out.read_text())
 def test_pass(self):
  td,root=self.fixture(True);p,r=self.audit(root);self.assertEqual(p.returncode,0);self.assertEqual(r['chapters'],4);td.cleanup()
 def test_block_weak(self):
  td,root=self.fixture(False);p,r=self.audit(root);self.assertNotEqual(p.returncode,0);self.assertIn('DEPTH_PLAN_REQUIRED_FIELDS',r['blocks']);td.cleanup()
 def test_discovers_book_chapters(self):
  td,root=self.fixture(True,nested=True);p,r=self.audit(root);self.assertEqual(r['chapters'],4);self.assertEqual(p.returncode,0);self.assertTrue(all(x.startswith('book/chapters/') for x in r['chapter_paths']));td.cleanup()
 def test_discovers_governance_depth_plan(self):
  td,root=self.fixture(True,nested=True,governance=True);p,r=self.audit(root);self.assertEqual(p.returncode,0,p.stdout+p.stderr);self.assertEqual(r['depth_plan_path'],'governance/DEPTH_PLAN.md');self.assertEqual(r['depth_plans'],4);td.cleanup()
 def test_governance_plan_without_chapter_contract_blocks_not_zero_chapters(self):
  td,root=self.fixture(False,nested=True,governance=True);p,r=self.audit(root);self.assertNotEqual(p.returncode,0);self.assertEqual(r['chapters'],4);self.assertIn('DEPTH_PLAN_REQUIRED_FIELDS',r['blocks']);td.cleanup()
if __name__=='__main__':unittest.main()
