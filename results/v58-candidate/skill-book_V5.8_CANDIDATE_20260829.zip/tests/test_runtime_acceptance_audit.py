import json,subprocess
from pathlib import Path
R=Path(__file__).parents[1];S=R/'scripts'/'runtime_acceptance_audit.py';RID='SB58-RUNTIME-CONTRACT-BF41D2E7'
MANDATORY=['evidence/reader_transformation_contract.json','evidence/baseline_applicability_pre_draft.json','evidence/full_book_substance_contract.json','evidence/full_book_substance_audit.json','evidence/continuous_reading_audit.json','evidence/training_feedback_pre_freeze.json','evidence/operational_closure_pre_freeze.json','evidence/reader_facing_packaging_audit.json','evidence/freeze_record.json','evidence/freeze_integrity_audit.json','evidence/reader_transfer_contract.json','evidence/runtime_authority_status.json','evidence/runtime_acceptance_audit.json']
def w(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
def base(root,final='BLOCK'):
 w(root/'MANIFEST.json',{'TEST_MODE':'SEALED_STANDALONE_FORWARD_TEST','BOOK_TITLE':'Fixture Book','LANGUAGE':'zh-CN','FINAL_DECISION':final,'REAL_READER_EVIDENCE':'NOT_RUN','machine_execution_status':'NOT_RUN'})
 w(root/'evidence'/'runtime_entry_receipt.json',{'runtime_contract_id':RID,'skill_name':'skill-book','declared_skill_version':'5.8','entry_stage':'PRE_DRAFT','runtime_contract_id_source':'SKILL_INTERNAL','benchmark_prompt_contract_id_exposed':False,'benchmark_canary_applicability':'REQUIRED','mandatory_evidence':MANDATORY})
def run(root):
 out=root/'result.json';cp=subprocess.run(['python',str(S),'--new',str(root),'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())
def test_v58_identity_and_wiring_are_active():
 s=S.read_text()
 for x in [RID,"EXPECTED_SKILL_VERSION='5.8'",'full_book_substance_audit.py','continuous_reading_audit.py','reader_facing_packaging_audit.py']:
  assert x in s
def test_missing_reader_first_gates_block_runtime(tmp_path):
 base(tmp_path);cp,r=run(tmp_path);assert cp.returncode!=0
 for x in ['FULL_BOOK_SUBSTANCE_CONTRACT_EVIDENCE_MISSING','FULL_BOOK_SUBSTANCE_AUDIT_EVIDENCE_MISSING','CONTINUOUS_READING_AUDIT_EVIDENCE_MISSING','READER_FACING_PACKAGING_AUDIT_EVIDENCE_MISSING']:
  assert x in r['blocks']
def test_optimistic_manifest_cannot_hide_reader_first_blocks(tmp_path):
 base(tmp_path,final='PASS_RUNTIME_ACCEPTANCE');cp,r=run(tmp_path);assert cp.returncode!=0;assert 'FINAL_DECISION_FALSE_GREEN' in r['blocks']
def test_report_version_is_v58(tmp_path):
 base(tmp_path);cp,r=run(tmp_path);assert r['version']=='V5.8_RUNTIME_ACCEPTANCE_AUDIT';assert r['runtime_contract_id']==RID
def test_real_reader_not_run_is_not_promoted(tmp_path):
 base(tmp_path);cp,r=run(tmp_path);assert r['real_reader_truth']['status']=='NOT_RUN'
