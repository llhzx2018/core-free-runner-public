import subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1]; SCRIPT=R/'scripts'/'postdraft_baseline_audit.py'
def w(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf-8')
def rich(label,n=80):
    return f'''# {label}
## 目标
目标任务用户场景。
## 输入证据
输入 来源 证据。
## 决策
判断 决策 规则 阈值。
## 状态边界
状态 边界 UNKNOWN。
## 执行
步骤 流程 执行。
## 验收
验证 验收 预期 实际。
## 记录
记录 日志 日期。
## 错误恢复
错误 失败 恢复 重试。
## 变更
版本 变更 冻结 OWNER。
## 完成
完成 进入下一步。
## 示例
示例 案例。
'''+('输入 输出 判断 验证 错误 恢复 规则。'*n)
class T(unittest.TestCase):
    def make(self,thin=False):
        td=tempfile.TemporaryDirectory(); base=Path(td.name); old=base/'old'; new=base/'new'
        for i in range(1,5):
            w(old/'manuscript'/f'{i:02d}_c.md',rich(f'old {i}',60)); w(new/'chapters'/f'{i:02d}_c.md',rich(f'new {i}',60 if not thin else 15))
            w(old/'templates'/f'{i:02d}_validation_contract.md',rich('tool',50)); w(new/'templates'/f'{i:02d}_validation_contract.md',rich('tool',50 if not thin else 5))
        return td,old,new
    def test_equivalent_no_trigger(self):
        td,old,new=self.make(False); cp=subprocess.run(['python',str(SCRIPT),'--old',str(old),'--new',str(new)],capture_output=True,text=True); self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr); td.cleanup()
    def test_depth_and_asset_regression_blocks(self):
        td,old,new=self.make(True); cp=subprocess.run(['python',str(SCRIPT),'--old',str(old),'--new',str(new)],capture_output=True,text=True); self.assertNotEqual(cp.returncode,0); self.assertIn('LEARNING_BUNDLE_DEPTH_DIFFERENTIAL',cp.stdout); self.assertIn('PRACTICAL_ASSET_BASELINE_DIFFERENTIAL',cp.stdout); td.cleanup()
if __name__=='__main__': unittest.main()

def test_v55_low_confidence_topology_cannot_machine_block(tmp_path):
    old=tmp_path/'old';new=tmp_path/'new'
    # One strong exact capability is preserved; one tiny companion file has no one-to-one successor.
    w(old/'templates'/'01_validation_contract.md',rich('tool',50));w(new/'templates'/'01_validation_contract.md',rich('tool',50))
    w(old/'templates'/'02_companion.csv','input,state\na,b\n')
    w(old/'manuscript'/'01_c.md',rich('chapter',50));w(new/'chapters'/'01_c.md',rich('chapter',50))
    cp=subprocess.run(['python',str(SCRIPT),'--old',str(old),'--new',str(new)],capture_output=True,text=True)
    assert cp.returncode==0,cp.stdout+cp.stderr
    assert 'PRACTICAL_ASSET_BASELINE_DIFFERENTIAL' not in cp.stdout

def test_v55_high_confidence_exact_asset_regression_still_blocks(tmp_path):
    old=tmp_path/'old';new=tmp_path/'new'
    w(old/'templates'/'01_validation_contract.md',rich('tool',60));w(new/'templates'/'01_validation_contract.md',rich('tool',3))
    w(old/'manuscript'/'01_c.md',rich('chapter',50));w(new/'chapters'/'01_c.md',rich('chapter',50))
    cp=subprocess.run(['python',str(SCRIPT),'--old',str(old),'--new',str(new)],capture_output=True,text=True)
    assert cp.returncode!=0
    assert 'PRACTICAL_ASSET_BASELINE_DIFFERENTIAL' in cp.stdout
