from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

SCRIPT=Path(__file__).parents[1]/'scripts'/'prefreeze_random_open_audit.py'

def rich_section(n):
    return (f"## 判断与执行 {n}\n\n输入来自真实证据。先按规则判断条件与边界，再执行具体步骤并记录输出。"
            "完成后验证结果是否达到验收条件；如果失败，记录错误原因、恢复动作和重试条件。"
            "示例用于说明为什么这个判断成立，以及什么时候应该停止或进入下一步。\n\n"
            "在新的场景里还要重新检查输入证据是否仍有效，不能照抄旧结论；若实际输出偏离预期，就回到规则和失败恢复步骤重新判断，并记录下一次验证所需的证据。\n")

def good_fixture(root:Path):
    (root/'chapters').mkdir();(root/'templates').mkdir()
    for i in range(1,7):(root/f'chapters/{i:02d}_chapter.md').write_text('# Chapter\n\n'+''.join(rich_section(j) for j in range(1,5)))
    for i in range(1,9):
        body='# Tool\n\n## Task\n\n'+('输入证据、判断规则、执行步骤、输出、验证、失败恢复、重试、完成条件。'*12)+'\n\n## Example\n\n参考判断与示例说明错误和修正。';(root/f'templates/{i:02d}_tool.md').write_text(body)

def bad_fixture(root:Path):
    (root/'chapters').mkdir();(root/'templates').mkdir()
    for i in range(1,7):(root/f'chapters/{i:02d}_chapter.md').write_text('# Chapter\n\n## Note\n\n很短。')
    for i in range(1,5):(root/f'templates/{i:02d}_tool.md').write_text('# Tool\n\n待填写。')

def run(root,phase):
    out=root/f'{phase}.json';cp=subprocess.run([sys.executable,str(SCRIPT),'--new',str(root),'--phase',phase,'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())

def test_generation_passes_when_local_value_is_real(tmp_path):
    good_fixture(tmp_path);cp,r=run(tmp_path,'GENERATION');assert cp.returncode==0;assert r['decision']=='PASS';assert r['failed']==0

def test_holdout_seed_interface_is_removed(tmp_path):
    good_fixture(tmp_path);out=tmp_path/'HOLDOUT.json';cp=subprocess.run([sys.executable,str(SCRIPT),'--new',str(tmp_path),'--phase','HOLDOUT','--json',str(out)],capture_output=True,text=True);assert cp.returncode!=0;assert not out.exists()

def test_blocks_thin_random_open_shells(tmp_path):
    bad_fixture(tmp_path);cp,r=run(tmp_path,'GENERATION');assert cp.returncode==1;assert r['failed']>0;assert 'PREFREEZE_RANDOM_OPEN_FAIL' in r['blocks']


def test_terminal_asset_paragraph_uses_bounded_neighbor_context(tmp_path):
 (tmp_path/'templates').mkdir();(tmp_path/'chapters').mkdir()
 for i in range(1,4):(tmp_path/f'chapters/{i:02d}_chapter.md').write_text('# C\n'+rich_section(1)*4)
 body='# Tool\n\n## Rules\n\n'+('输入 判断 规则 执行 验证 失败 恢复 重试 完成。'*20)+'\n\n## Last\n\n短结尾。'
 for i in range(8):(tmp_path/f'templates/{i:02d}.md').write_text(body)
 cp,r=run(tmp_path,'GENERATION');assert cp.returncode==0,r
