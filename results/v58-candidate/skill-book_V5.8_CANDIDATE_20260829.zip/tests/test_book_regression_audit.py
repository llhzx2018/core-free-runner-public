import unittest,tempfile,subprocess,sys
from pathlib import Path
R=Path(__file__).parents[1]
class T(unittest.TestCase):
 def make(self,chars=1200,thin=False):
  td=tempfile.TemporaryDirectory();root=Path(td.name);(root/'manuscript').mkdir();(root/'operator_reference').mkdir();(root/'templates').mkdir()
  for i in range(1,5):
   body=('判断 输入 输出 验证 错误 恢复 案例 规则 条件 完成。'*100)[:(300 if thin else chars)];(root/'manuscript'/f'{i:02d}_c.md').write_text(f'# 第 {i} 章\n'+body)
   (root/'operator_reference'/f'{i:02d}_operator_reference.md').write_text('# Ref\n参数 判断 错误 恢复 验证。\n本章专属 '+(('参数 规则 边界 案例 错误 恢复 判断 验证 输出 完成 '+str(i)+'。')*18))
   (root/'templates'/f'{i:02d}_template.md').write_text('# T\n输入 字段 判断 回滚 完成。\n本章字段 '+(('输入 字段 示例 判断 回滚 完成 验证 输出 '+str(i)+'。')*20))
  return td,root
 def test_pass(self):
  a,old=self.make();b,new=self.make();p=subprocess.run([sys.executable,str(R/'scripts/book_regression_audit.py'),'--old',str(old),'--new',str(new),'--expected-old-chapters','4','--mode','STANDALONE'],capture_output=True,text=True);self.assertEqual(p.returncode,0);a.cleanup();b.cleanup()
 def test_compression_block(self):
  a,old=self.make();b,new=self.make(thin=True);p=subprocess.run([sys.executable,str(R/'scripts/book_regression_audit.py'),'--old',str(old),'--new',str(new),'--expected-old-chapters','4','--mode','STANDALONE'],capture_output=True,text=True);self.assertNotEqual(p.returncode,0);self.assertIn('PER_CHAPTER_COMPRESSION',p.stdout);a.cleanup();b.cleanup()

 def test_depth_plan_not_counted_as_chapter(self):
  td,root=self.make();(root/'depth_plan').mkdir();(root/'depth_plan'/'01_depth_plan.md').write_text('# Chapter 01 Depth Plan\nReader Entry')
  a,b=self.make();p=subprocess.run([sys.executable,str(R/'scripts/book_regression_audit.py'),'--old',str(root),'--new',str(b),'--expected-old-chapters','4','--mode','STANDALONE'],capture_output=True,text=True);self.assertNotIn('CHAPTER_COUNT',p.stdout);td.cleanup();a.cleanup()


 def test_manuscript_uniformity_block(self):
  a,old=self.make();b,new=self.make()
  for p in (new/'manuscript').glob('*.md'):
   p.write_text(p.read_text()+"\n## 本章先解决一个具体问题\n判断 输入 输出 验证。"+"X"*400+"\n## 四个常见误判\n错误 恢复 判断。"+"Y"*300+"\n## 决策树\n规则 条件 输出。"+"Z"*300)
  p=subprocess.run([sys.executable,str(R/'scripts/book_regression_audit.py'),'--old',str(old),'--new',str(new),'--expected-old-chapters','4','--mode','STANDALONE'],capture_output=True,text=True);self.assertNotEqual(p.returncode,0);self.assertIn('READING_CORE_STRUCTURAL_UNIFORMITY',p.stdout);a.cleanup();b.cleanup()

 def test_sealed_mode_allows_chapter_count_difference_for_postdraft_audit(self):
  a,old=self.make();b,new=self.make();(new/'manuscript'/'04_c.md').unlink()
  p=subprocess.run([sys.executable,str(R/'scripts/book_regression_audit.py'),'--old',str(old),'--new',str(new),'--expected-old-chapters','4','--mode','SEALED_STANDALONE_FORWARD'],capture_output=True,text=True)
  self.assertNotIn('CHAPTER_COUNT"',p.stdout);self.assertIn('CHAPTER_COUNT_DIFFERENCE_REQUIRES_POST_DRAFT_RESPONSIBILITY_AUDIT',p.stdout);a.cleanup();b.cleanup()

 def test_numbered_manifest_and_assets_are_not_chapters(self):
  a,old=self.make();b,new=self.make()
  (new/'01_MANIFEST.md').write_text('# Manifest\nstatus')
  (new/'assets').mkdir();(new/'assets'/'03_PROBLEM_CARD.md').write_text('# Problem Card\n'+('输入 输出 判断 验证 错误 恢复 规则 条件 完成。'*50))
  p=subprocess.run([sys.executable,str(R/'scripts/book_regression_audit.py'),'--old',str(old),'--new',str(new),'--expected-old-chapters','4','--mode','STANDALONE'],capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stdout+p.stderr);self.assertIn('\"chapter_count\": 4',p.stdout);a.cleanup();b.cleanup()

if __name__=='__main__':unittest.main()
