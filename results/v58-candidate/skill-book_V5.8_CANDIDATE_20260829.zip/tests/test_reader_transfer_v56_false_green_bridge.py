#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from copy import deepcopy
from pathlib import Path

R=Path(__file__).parents[1]
DEPTH=R/'scripts'/'practical_asset_depth_audit.py'
TRANSFER=R/'scripts'/'reader_transfer_audit.py'

def w(p:Path,s:str): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf-8')

ASSET='''# Community Equipment Lending Run Record
Goal: safely hand a checked neighborhood tool from operator A to operator B. Scope: condition, borrower evidence, lend/hold decision, handoff.
Inputs: current item evidence and borrower record. Owner: operator A. Precondition: item identity confirmed.
Steps: 1. inspect condition 2. record evidence 3. choose LEND or HOLD 4. hand off next action. Checkpoint: current condition recorded. Exception path: if evidence conflicts, HOLD.
Evidence log: Record ID: ____ Date: ____ Source / actor: ____ Action / observation: ____ Result: ____ Interpretation: ____ Linked decision/change: ____
Failure trigger: condition conflict. Diagnosis / likely cause: stale or missing inspection. Recovery action: inspect again. Retry condition: retry only when fresh evidence exists. Post-retry evidence: ____ Escalate or pause when: fault remains unknown.
Expected: traceable lend/hold state. Actual: ____ Verification method: compare current condition evidence to lending rule. PASS / FAIL / PARTIAL: ____ Defect / rework: ____ Closure: close only after acceptance evidence is recorded.
Completion: close only when the trace is complete, blockers are explicit, and the next operator receives state, evidence, and next action.
'''

CONTRACT={
 'schema':'skill-book-reader-transfer-contract/v1','domain':'community equipment-lending day',
 'authority':{'proxy_layer':'BLIND_READER_PROXY_ONLY','real_reader_derivation':'FORBIDDEN','real_reader_evidence':'NOT_RUN'},
 'tasks':[
  {'id':'read','axis':'READ','required_responsibilities':['sequence','boundary','next_decision']},
  {'id':'learn','axis':'LEARN','required_responsibilities':['rule','rationale','changed_case'],'near_miss':{'correct_option':'B','options':['A','B','C']}},
  {'id':'train','axis':'TRAIN','required_responsibilities':['evidence_link','decision_rule','completion'],'requires_retry_repair':True},
  {'id':'do','axis':'DO','required_responsibilities':['state','evidence','next_action','acceptance'],'requires_operator_handoff':True}
 ]}

GOOD_PROXY={
 'schema':'skill-book-reader-transfer-proxy/v1','domain':'community equipment-lending day',
 'source':{'kind':'BLIND_READER_PROXY','reader_id':'bridge-proxy','fresh':True,'blind_to':['generation_contract','verifier','canonical'],'real_reader':False},
 'results':[
  {'task_id':'read','axis':'READ','first_attempt':{'answer':'Inspect, record, decide, hand off; unknown condition means HOLD.','responsibilities':{'sequence':'PASS','boundary':'PASS','next_decision':'PASS'}}},
  {'task_id':'learn','axis':'LEARN','first_attempt':{'answer':'A familiar borrower does not override a new condition fault.','responsibilities':{'rule':'PASS','rationale':'PASS','changed_case':'PASS'}},'near_miss_choice':'B'},
  {'task_id':'train','axis':'TRAIN','first_attempt':{'answer':'Lend because familiar.','responsibilities':{'evidence_link':'FAIL','decision_rule':'FAIL','completion':'PASS'}},'feedback':{'target_responsibilities':['evidence_link','decision_rule'],'message':'Use current condition evidence and the explicit lend/hold rule.'},'retry':{'answer':'HOLD until fresh condition evidence passes the lending rule.','responsibilities':{'evidence_link':'PASS','decision_rule':'PASS','completion':'PASS'},'changed_responsibilities':['evidence_link','decision_rule']}},
  {'task_id':'do','axis':'DO','first_attempt':{'answer':'Create the handoff record.','responsibilities':{'state':'PASS','evidence':'PASS','next_action':'PASS','acceptance':'PASS'}},'output':{'artifact':'handoff-record','steps':['record current state','attach evidence','assign next action'],'acceptance_results':{'trace':'PASS','state':'PASS'}},'handoff':{'operator1':{'state_id':'tool-7-HOLD','state':'HOLD','evidence':'inspection-7','next_action':'reinspect','owner':'operator-b'},'operator2':{'received_state_id':'tool-7-HOLD','received_evidence':'inspection-7','next_action':'reinspect','result':'fault confirmed','acceptance':'PASS'}}}
 ]}

class T(unittest.TestCase):
 def fixture(self,proxy):
  td=tempfile.TemporaryDirectory(); root=Path(td.name)
  rel='templates/community_equipment_lending_run_record.md'; w(root/rel,ASSET)
  depth={'schema':'skill-book.practical-asset-depth.v1','assets':[{'path':rel,'roles':['execution_brief_or_log'],'complexity':'HIGH','required_dimensions':['context_task','input_evidence','execution_steps','evidence_log','failure_recovery','validation_acceptance','completion'],'n_a':{},'promise_links':['safe_equipment_handoff']}]}
  w(root/'evidence'/'practical_asset_depth_contract.json',json.dumps(depth,ensure_ascii=False))
  w(root/'evidence'/'reader_transfer_contract.json',json.dumps(CONTRACT,ensure_ascii=False))
  w(root/'evidence'/'reader_transfer_proxy.json',json.dumps(proxy,ensure_ascii=False))
  return td,root
 def run_json(self,script,root):
  cp=subprocess.run([sys.executable,str(script),'--new',str(root)],text=True,capture_output=True)
  return cp,json.loads(cp.stdout)
 def assert_depth_green_transfer_block(self,proxy,block):
  td,root=self.fixture(proxy)
  dcp,d=self.run_json(DEPTH,root); self.assertEqual(dcp.returncode,0,d); self.assertEqual(d['decision'],'PASS')
  tcp,t=self.run_json(TRANSFER,root); self.assertNotEqual(tcp.returncode,0,t); self.assertIn(block,t['blocks'],t)
  self.assertEqual(t['real_reader_evidence'],'NOT_RUN'); td.cleanup()
 def test_v56_depth_green_can_still_hide_near_miss_confusion(self):
  p=deepcopy(GOOD_PROXY); p['results'][1]['near_miss_choice']='A'
  self.assert_depth_green_transfer_block(p,'NEAR_MISS_CONFUSION')
 def test_v56_depth_green_can_still_hide_nonrepairing_retry(self):
  p=deepcopy(GOOD_PROXY); tr=p['results'][2]; tr['retry']['answer']=tr['first_attempt']['answer']; tr['retry']['responsibilities']['decision_rule']='FAIL'; tr['retry']['changed_responsibilities']=['evidence_link']
  self.assert_depth_green_transfer_block(p,'RETRY_DID_NOT_REPAIR_RESPONSIBILITY')
 def test_v56_depth_green_can_still_hide_broken_operator_handoff(self):
  p=deepcopy(GOOD_PROXY); p['results'][3]['handoff']['operator2']['received_state_id']='wrong'; p['results'][3]['handoff']['operator2']['received_evidence']=''
  self.assert_depth_green_transfer_block(p,'OPERATOR_HANDOFF_NOT_SELF_SUFFICIENT')

if __name__=='__main__': unittest.main()
