#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SCRIPTS=ROOT/'scripts'

class V58ReaderFirst(unittest.TestCase):
    def run_script(self,name,*args):
        return subprocess.run([sys.executable,str(SCRIPTS/name),*map(str,args)],text=True,capture_output=True)

    def make_book(self,base,length=300,count=10):
        d=base/'chapters';d.mkdir(parents=True)
        for i in range(1,count+1):
            (d/f'{i:02d}_chapter.md').write_text('# 标题\n\n'+'这是完整解释。'*length,encoding='utf-8')

    def audit_json(self,path,count=10):
        data={'product_class':'FULL_BOOK','core_chapters':list(range(1,count+1)),'chapters':[]}
        for i in range(1,count+1):
            data['chapters'].append({'chapter':i,'classification':'SUBSTANTIVE','evidence':['这里有足够长的具体因果解释与判断证据，能说明章节职责。','这里还有具体案例、失败恢复、训练反馈和下一步衔接证据。']})
        path.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')

    def test_thin_full_book_is_blocked_even_if_self_labeled_substantive(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);self.make_book(root,length=30);audit=root/'audit.json';self.audit_json(audit)
            r=self.run_script('full_book_substance_audit.py','--new',root,'--audit',audit)
            self.assertNotEqual(r.returncode,0,r.stdout+r.stderr)
            self.assertIn('UNRESOLVED_MACHINE_SHELL_RISK',r.stdout)

    def test_substantive_shell_can_pass_machine_risk_layer(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);self.make_book(root,length=330);audit=root/'audit.json';self.audit_json(audit)
            r=self.run_script('full_book_substance_audit.py','--new',root,'--audit',audit)
            self.assertEqual(r.returncode,0,r.stdout+r.stderr)

    def test_engineering_only_chinese_packaging_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'BOOK').mkdir();(root/'BOOK'/'A1_FULL_MANUSCRIPT.md').write_text('正文',encoding='utf-8')
            r=self.run_script('reader_facing_packaging_audit.py','--new',root,'--book-title','一个人做出海网站','--language','zh-CN')
            self.assertNotEqual(r.returncode,0,r.stdout+r.stderr)
            self.assertIn('OBVIOUS_MANUSCRIPT_ENTRY_MISSING',r.stdout)

    def test_localized_reader_entry_passes_packaging_layer(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'一个人做出海网站_完整正文.md').write_text('正文',encoding='utf-8');(root/'一个人做出海网站_阅读版.html').write_text('<p>正文</p>',encoding='utf-8');(root/'_verification').mkdir()
            r=self.run_script('reader_facing_packaging_audit.py','--new',root,'--book-title','一个人做出海网站','--language','zh-CN')
            self.assertEqual(r.returncode,0,r.stdout+r.stderr)

    def test_continuous_reading_requires_two_real_windows(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'c.json';p.write_text(json.dumps({'windows':[{'chapters':[1,2,3],'entry_reader_state':'a','carry_over':'x'*40,'capability_progression':'x'*40,'rhythm_variation':'x'*40,'output_input_handoff':'x'*40,'end_reader_state':'b','remove_one_chapter_impact':'x'*40,'decision':'PASS'}]}),encoding='utf-8')
            r=self.run_script('continuous_reading_audit.py','--audit',p)
            self.assertNotEqual(r.returncode,0,r.stdout+r.stderr);self.assertIn('CONTIGUOUS_WINDOW_COVERAGE',r.stdout)

    def test_skill_entry_is_rebased_not_append_only(self):
        s=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('SB58-RUNTIME-CONTRACT-BF41D2E7',s)
        self.assertIn('BOOK FIRST',s)
        self.assertIn('FULL_BOOK_SUBSTANCE',s)
        self.assertIn('READER_FACING_PACKAGING',s)
        self.assertLess(len(s.encode('utf-8')),35000)

if __name__=='__main__':unittest.main()
