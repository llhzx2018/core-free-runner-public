import json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1];S=R/'scripts'/'training_feedback_audit.py'
def w(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
FULL='''# T\n## 任务\n预期输出：完成记录。\n参考判断：满足证据与阈值才继续。\n为什么错：只写结论没有证据。\n纠错：补来源与条件。\n重试：换一组输入再次判断。\n完成条件：能独立复核并得出一致结论。\n'''
class T(unittest.TestCase):
 def audit(self,good=True):
  td=tempfile.TemporaryDirectory();r=Path(td.name);w(r/'chapters'/'01.md',FULL if good else '# T\n## 任务\n执行步骤和验证。')
  w(r/'evidence'/'adequacy_contract.json',json.dumps({'chapters':[{'path':'chapters/01.md','complexity':'HIGH'}],'assets':[]}))
  loop={k:'具体而可执行的反馈说明' for k in ('expected_output','reference_judgment','error_class','correction','retry','completion_condition')};w(r/'evidence'/'training_feedback_contract.json',json.dumps({'chapters':[{'chapter_path':'chapters/01.md','applicability':'REQUIRED','feedback_asset_paths':[],'feedback_loop':loop}]},ensure_ascii=False))
  out=r/'x.json';cp=subprocess.run(['python',str(S),'--new',str(r),'--stage','PRE_FREEZE','--json',str(out)],capture_output=True,text=True);return td,cp,json.loads(out.read_text())
 def test_complete_loop_passes(self):
  td,cp,j=self.audit(True);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);td.cleanup()
 def test_reader_facing_feedback_gap_blocks(self):
  td,cp,j=self.audit(False);self.assertNotEqual(cp.returncode,0);self.assertIn('TRAINING_FEEDBACK_COVERAGE_GAP',j['blocks']);td.cleanup()
if __name__=='__main__':unittest.main()


def test_common_error_synonym_is_accepted(tmp_path):
 from pathlib import Path
 root=tmp_path
 w(root/'chapters'/'01.md','# T\n## 任务\n预期输出：完成记录。\n参考判断：满足证据与阈值才继续。\n常见错误：只写结论没有证据。\n纠错：补来源与条件。\n重试：换一组输入再次判断。\n完成条件：能独立复核并得出一致结论。\n')
 w(root/'evidence'/'adequacy_contract.json',json.dumps({'chapters':[{'path':'chapters/01.md','complexity':'HIGH'}],'assets':[]}))
 loop={k:'具体而可执行的反馈说明' for k in ('expected_output','reference_judgment','error_class','correction','retry','completion_condition')}
 w(root/'evidence'/'training_feedback_contract.json',json.dumps({'chapters':[{'chapter_path':'chapters/01.md','applicability':'REQUIRED','feedback_asset_paths':[],'feedback_loop':loop}]},ensure_ascii=False))
 out=root/'syn.json';cp=subprocess.run(['python',str(S),'--new',str(root),'--stage','PRE_FREEZE','--json',str(out)],capture_output=True,text=True)
 assert cp.returncode==0,cp.stdout+cp.stderr
