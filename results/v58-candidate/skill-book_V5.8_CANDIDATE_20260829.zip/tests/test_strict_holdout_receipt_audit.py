import json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1];S=R/'scripts'/'strict_holdout_receipt_audit.py'
def run(d):
 p=Path(d)/'r.json';out=Path(d)/'o.json';cp=subprocess.run(['python',str(S),'--receipt',str(p),'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())
class T(unittest.TestCase):
 def test_opaque_receipt_passes(self):
  with tempfile.TemporaryDirectory() as d:
   Path(d,'r.json').write_text(json.dumps({'decision':'PASS','sample_count':12,'failed_count':0,'generator_exposure':'OPAQUE_AGGREGATE_ONLY','seed_commitment':'sha256:abcdef0123456789','evaluator_id':'external-v1','run_id':'h-1','failure_classes':[]}),encoding='utf-8');cp,j=run(d);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
 def test_seed_or_path_leak_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   Path(d,'r.json').write_text(json.dumps({'decision':'PASS','sample_count':12,'failed_count':0,'generator_exposure':'NONE','seed_commitment':'sha256:abcdef0123456789','evaluator_id':'external-v1','run_id':'h-1','seeds':[1,2]}),encoding='utf-8');cp,j=run(d);self.assertNotEqual(cp.returncode,0);self.assertIn('HOLDOUT_SAMPLE_OR_SEED_LEAK',j['failures'])
if __name__=='__main__':unittest.main()
