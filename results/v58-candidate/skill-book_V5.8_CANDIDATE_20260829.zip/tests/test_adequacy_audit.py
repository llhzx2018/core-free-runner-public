import json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1]; SCRIPT=R/'scripts'/'adequacy_audit.py'
def w(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf-8')
def rich_chapter(i):
    core=("目标任务用户场景 输入来源证据 判断决定规则阈值 边界状态UNKNOWN 执行步骤流程 验证验收检查 记录日志日期 错误失败恢复纠错回滚重试 版本变更冻结 完成进入下一步 示例案例。"*35)
    return f"# Chapter {i}\n\n## Mechanism\n{core}\n## Worked Example\n示例案例。\n## Failure and Recovery\n错误失败恢复纠错重试。\n## Practice\n预期输出与验证。"
def rich_template(i):
    base=f"""# Tool {i}

## 目标与场景
目标任务用户场景。
## 输入与证据
输入 来源 证据 前置。
## 判断规则
判断 决策 阈值 条件 CONTINUE REVISE PAUSE STOP。
## 状态与边界
状态 边界 UNKNOWN INVALID Non-goal。
## 执行步骤
1. 执行步骤。
2. 操作流程。
## 验证与验收
预期 实际 验证 验收 PASS FAIL。
## 证据记录
| 日期 | 来源 | 记录 |
|---|---|---|
| | | |
## 错误与恢复
错误 失败 恢复 纠错 回滚 重试。
## 版本与变更
版本 冻结 OWNER 变更复核。
## 完成条件
- [ ] 完成后允许进入下一步。
## 示例
示例案例与参考判断。
"""
    return base+('字段 输入 输出 判断 验证 恢复。'*40)
class T(unittest.TestCase):
    def make(self,thin=False,underdeclare=False):
        td=tempfile.TemporaryDirectory(); root=Path(td.name); chap=[]; assets=[]
        for i in range(1,5):
            cp=root/'chapters'/f'{i:02d}_c.md'; w(cp,rich_chapter(i))
            tp=root/'templates'/f'{i:02d}_validation_contract.md'; w(tp,(f'# Different {i}\n目标 输入 判断 状态 验证 完成。\n'+'x'*250) if thin else rich_template(i))
            chap.append({'path':cp.relative_to(root).as_posix(),'complexity':'LOW' if underdeclare else 'HIGH','must_explain':['a','b','c','d'],'must_judge':['a','b','c'],'boundaries':['a','b'],'failure_modes':['a','b'],'worked_examples':['a'],'practice_outputs':['a'],'template_assets':[tp.relative_to(root).as_posix()]})
            assets.append({'path':tp.relative_to(root).as_posix(),'complexity':'HIGH','required_dimensions':['context_task','input_evidence','decision_rule','state_boundary','execution_steps','validation_acceptance','failure_recovery','change_control','completion'],'training_instrument':False})
        w(root/'evidence'/'adequacy_contract.json',json.dumps({'schema':'skill-book.adequacy.v1','chapters':chap,'assets':assets},ensure_ascii=False))
        return td,root
    def audit(self,root):
        out=root/'out.json'; cp=subprocess.run(['python',str(SCRIPT),'--new',str(root),'--json',str(out)],capture_output=True,text=True); return cp,json.loads(out.read_text())
    def test_good_passes(self):
        td,root=self.make(); cp,r=self.audit(root); self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr); self.assertEqual(r['decision'],'PASS'); td.cleanup()
    def test_thin_but_diverse_assets_block(self):
        td,root=self.make(thin=True); cp,r=self.audit(root); self.assertNotEqual(cp.returncode,0); self.assertIn('PRACTICAL_ASSET_ADEQUACY',r['blocks']); td.cleanup()
    def test_complexity_cannot_be_underdeclared(self):
        td,root=self.make(underdeclare=True); cp,r=self.audit(root); self.assertNotEqual(cp.returncode,0); self.assertIn('COMPLEXITY_CALIBRATED_CHAPTER_DEPTH',r['blocks']); td.cleanup()
    def test_missing_contract_blocks_but_still_analyzes(self):
        td,root=self.make(); (root/'evidence'/'adequacy_contract.json').unlink(); cp,r=self.audit(root); self.assertNotEqual(cp.returncode,0); self.assertIn('ADEQUACY_CONTRACT_MISSING',r['blocks']); self.assertEqual(r['templates'],4); td.cleanup()
    def test_training_instrument_strength_blocks_weak_feedback(self):
        td,root=self.make(); prof=json.loads((root/'evidence'/'adequacy_contract.json').read_text())
        prof['assets'][0]['training_instrument']=True
        # remove the few accidental feedback words while keeping the operator structure rich
        tp=root/prof['assets'][0]['path']; text=tp.read_text().replace('纠错','修复').replace('重试','再次执行').replace('参考判断','使用说明')
        tp.write_text(text)
        (root/'evidence'/'adequacy_contract.json').write_text(json.dumps(prof,ensure_ascii=False))
        cp,r=self.audit(root); self.assertNotEqual(cp.returncode,0); self.assertIn('TRAINING_INSTRUMENT_STRENGTH',r['blocks']); td.cleanup()

    def test_high_asset_cannot_underdeclare_responsibility_dimensions(self):
        td,root=self.make(); prof=json.loads((root/'evidence'/'adequacy_contract.json').read_text())
        prof['assets'][0]['required_dimensions']=['context_task','input_evidence','decision_rule']
        (root/'evidence'/'adequacy_contract.json').write_text(json.dumps(prof,ensure_ascii=False))
        cp,r=self.audit(root); self.assertNotEqual(cp.returncode,0); self.assertIn('PRACTICAL_ASSET_ADEQUACY',r['blocks']);
        self.assertTrue(any('PROFILE_REQUIRED_DIMENSIONS_UNDERDECLARED' in reason for row in r['practical_asset_adequacy']['details'] for reason in row['reasons'])); td.cleanup()

if __name__=='__main__': unittest.main()
