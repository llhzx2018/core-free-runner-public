import json, subprocess, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).parents[1]
SCRIPT=ROOT/'scripts'/'reader_outcome_audit.py'

def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
class T(unittest.TestCase):
 def audit(self,old,new,ledger=None,execution=True,real_reader=True):
  out=new/'report.json';cmd=['python',str(SCRIPT),'--new',str(new),'--old',str(old),'--json',str(out)]
  if ledger:cmd+=['--preservation-ledger',str(ledger)]
  if execution:
   ep=new/'execution.json';write(ep,json.dumps({'status':'PASS','scope':'sandbox'}));cmd+=['--execution-evidence',str(ep)]
  if real_reader:
   rp=new/'real_reader.json';write(rp,json.dumps({'source_type':'REAL_READER_FIXTURE','READ_CONTINUE':'PASS','LEARN_TRANSFER':'PASS','TRAIN_FEEDBACK':'PASS','evidence_boundary':'unit-test fixture'}));cmd+=['--real-reader-evidence',str(rp)]
  cp=subprocess.run(cmd,text=True,capture_output=True);return cp,json.loads(out.read_text())
 def fixture(self,base,good=True):
  old=base/'old';new=base/'new'
  for i in range(1,5):
   write(old/'manuscript'/f'{i:02d}_c.md',f'# c{i}\n\n## Old {i}\n\n'+('具体解释 输入 输出 判断 验证。'*30))
   write(new/'manuscript'/f'{i:02d}_c.md',f'# c{i}\n\n## New {i}\n\n'+(('不同的具体解释 输入 输出 判断 验证。'*30) if good else '本轮不复制旧正文表达。审阅时特别检查。'*30))
   oldtemp=('字段 步骤 判断 示例 验证 完成。'*120)
   newtemp=(('字段 步骤 判断 示例 验证。\n## 参考判断\n为什么错，纠错后重试。'*70) if good else '通用字段。'*20)
   write(old/'templates'/f'{i:02d}_x.md',oldtemp);write(new/'templates'/f'{i:02d}_x.md',newtemp)
   write(new/'operator_reference'/f'{i:02d}_operator_reference.md','## 反馈\n参考判断与纠错。')
  write(new/'workbook'/'w.md','|1|PASS|\n|2|PASS|\n')
  return old,new
 def test_good_fixture(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True);cp,r=self.audit(old,new);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertEqual(r['decision'],'PASS_READER_OUTCOME_CLOSURE')
 def test_scaffold_and_asset_regression_block(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),False)
   ledger=new/'ledger.json';write(ledger,json.dumps({'old_assets':[{'old':'x','status':'PRESERVED','evidence':'post-generation review required'}]}))
   cp,r=self.audit(old,new,ledger);self.assertNotEqual(cp.returncode,0);self.assertIn('READER_FACING_SCAFFOLD_LEAK',r['blocks']);self.assertIn('PRACTICAL_ASSET_FIDELITY_REGRESSION',r['blocks']);self.assertIn('PRESERVATION_STATE_FALSE_PASS',r['blocks'])

 def test_unspecific_preservation_mapping_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True)
   ledger=new/'ledger.json';write(ledger,json.dumps({'old_assets':[{'old':'appendices/A.md','mapping':'appendices/ (review later)','status':'PRESERVED','evidence':'manual review complete'}]}))
   cp,r=self.audit(old,new,ledger);self.assertNotEqual(cp.returncode,0);self.assertIn('PRESERVATION_MAPPING_NOT_SPECIFIC',r['blocks'])

 def test_do_pass_without_real_reader_still_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True);cp,r=self.audit(old,new,real_reader=False)
   self.assertNotEqual(cp.returncode,0);self.assertIn('REAL_READER_READ_NOT_CLOSED',r['blocks']);self.assertIn('REAL_READER_LEARN_NOT_CLOSED',r['blocks']);self.assertIn('REAL_READER_TRAIN_NOT_CLOSED',r['blocks']);self.assertEqual(r['reader_outcome']['DO_VERIFIED_OUTPUT'],'PASS')
 def test_real_reader_fail_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True)
   rp=new/'real_reader.json';write(rp,json.dumps({'source_type':'REAL_READER_FIXTURE','READ_CONTINUE':'PASS','LEARN_TRANSFER':'FAIL','TRAIN_FEEDBACK':'PASS'}))
   out=new/'report.json';ep=new/'execution.json';write(ep,json.dumps({'status':'PASS'}))
   cmd=['python',str(SCRIPT),'--new',str(new),'--old',str(old),'--execution-evidence',str(ep),'--real-reader-evidence',str(rp),'--json',str(out)]
   cp=subprocess.run(cmd,text=True,capture_output=True);r=json.loads(out.read_text())
   self.assertNotEqual(cp.returncode,0);self.assertIn('REAL_READER_LEARN_NOT_CLOSED',r['blocks'])

 def test_external_adequacy_report_blocks_closure(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True)
   ar=new/'adequacy.json';write(ar,json.dumps({'decision':'BLOCK','blocks':['PRACTICAL_ASSET_ADEQUACY']}))
   br=new/'baseline.json';write(br,json.dumps({'decision':'PASS_REVIEW_NO_MACHINE_TRIGGER','blocks':[]}))
   ep=new/'execution.json';write(ep,json.dumps({'status':'PASS'}))
   rp=new/'real_reader.json';write(rp,json.dumps({'source_type':'REAL_READER_FIXTURE','READ_CONTINUE':'PASS','LEARN_TRANSFER':'PASS','TRAIN_FEEDBACK':'PASS'}))
   out=new/'report.json';cmd=['python',str(SCRIPT),'--new',str(new),'--old',str(old),'--execution-evidence',str(ep),'--real-reader-evidence',str(rp),'--adequacy-report',str(ar),'--postdraft-baseline-report',str(br),'--json',str(out)]
   cp=subprocess.run(cmd,text=True,capture_output=True);r=json.loads(out.read_text());self.assertNotEqual(cp.returncode,0);self.assertIn('ADEQUACY_NOT_CLOSED',r['blocks'])

 def test_new_book_na_baseline_is_closed_but_real_reader_remains_separate(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True)
   ar=new/'adequacy.json';write(ar,json.dumps({'decision':'PASS','blocks':[]}))
   br=new/'baseline.json';write(br,json.dumps({'decision':'PASS_NOT_APPLICABLE_NEW_BOOK','blocks':[],'reason':'VALID_NEW_BOOK_NO_SAME_BOOK_CANONICAL'}))
   rr=new/'runtime.json';write(rr,json.dumps({'decision':'PASS_RUNTIME_ACCEPTANCE','blocks':[]}))
   ep=new/'execution.json';write(ep,json.dumps({'status':'PASS'}))
   rp=new/'real_reader.json';write(rp,json.dumps({'source_type':'REAL_READER_FIXTURE','READ_CONTINUE':'PASS','LEARN_TRANSFER':'PASS','TRAIN_FEEDBACK':'PASS'}))
   out=new/'report.json';cmd=['python',str(SCRIPT),'--new',str(new),'--execution-evidence',str(ep),'--real-reader-evidence',str(rp),'--adequacy-report',str(ar),'--postdraft-baseline-report',str(br),'--runtime-acceptance-report',str(rr),'--json',str(out)]
   cp=subprocess.run(cmd,text=True,capture_output=True);r=json.loads(out.read_text());self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertEqual(r['postdraft_baseline_gate']['decision'],'PASS_NOT_APPLICABLE_NEW_BOOK');self.assertEqual(r['decision'],'PASS_READER_OUTCOME_CLOSURE')
 def test_root_workbook_is_discovered(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True);(new/'workbook'/'w.md').unlink();(new/'workbook').rmdir();write(new/'WORKBOOK.md','第一轮行动记录，状态保持 NOT_RUN 直到读者实际执行。')
   cp,r=self.audit(old,new);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertTrue(r['reader_workbook_observation']['present']);self.assertIn('WORKBOOK.md',r['reader_workbook_observation']['paths'])

 def test_mapping_aware_renamed_asset_can_preserve_fidelity(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True);src=new/'templates'/'01_x.md';dst=new/'templates'/'renamed_operator.md';src.rename(dst)
   ledger=new/'ledger.json';write(ledger,json.dumps({'old_assets':[{'old':'templates/01_x.md','mapping':'templates/renamed_operator.md','status':'PRESERVED','evidence':'manual functional review complete'}]}))
   cp,r=self.audit(old,new,ledger);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);row=[x for x in r['practical_asset_fidelity']['mapping_aware_rows'] if x['old_asset']=='templates/01_x.md'][0];self.assertEqual(row['new_asset'],'templates/renamed_operator.md');self.assertEqual(row['resolution'],'mapping')


 def test_freeze_integrity_report_blocks_reader_closure_when_not_pass(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True)
   fr=new/'freeze.json';write(fr,json.dumps({'decision':'BLOCK','blocks':['READER_ASSET_HASH_DRIFT']}))
   out=new/'report.json';ep=new/'execution.json';write(ep,json.dumps({'status':'PASS'}));rp=new/'real_reader.json';write(rp,json.dumps({'source_type':'REAL_READER_FIXTURE','READ_CONTINUE':'PASS','LEARN_TRANSFER':'PASS','TRAIN_FEEDBACK':'PASS'}))
   cmd=['python',str(SCRIPT),'--new',str(new),'--old',str(old),'--execution-evidence',str(ep),'--real-reader-evidence',str(rp),'--freeze-integrity-report',str(fr),'--json',str(out)]
   cp=subprocess.run(cmd,text=True,capture_output=True);r=json.loads(out.read_text());self.assertNotEqual(cp.returncode,0);self.assertIn('FREEZE_INTEGRITY_NOT_CLOSED',r['blocks'])

 def test_freeze_integrity_pass_report_does_not_add_freeze_block(self):
  with tempfile.TemporaryDirectory() as d:
   old,new=self.fixture(Path(d),True)
   fr=new/'freeze.json';write(fr,json.dumps({'decision':'PASS_FREEZE_INTEGRITY','blocks':[]}))
   out=new/'report.json';ep=new/'execution.json';write(ep,json.dumps({'status':'PASS'}));rp=new/'real_reader.json';write(rp,json.dumps({'source_type':'REAL_READER_FIXTURE','READ_CONTINUE':'PASS','LEARN_TRANSFER':'PASS','TRAIN_FEEDBACK':'PASS'}))
   cmd=['python',str(SCRIPT),'--new',str(new),'--old',str(old),'--execution-evidence',str(ep),'--real-reader-evidence',str(rp),'--freeze-integrity-report',str(fr),'--json',str(out)]
   cp=subprocess.run(cmd,text=True,capture_output=True);r=json.loads(out.read_text());self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertNotIn('FREEZE_INTEGRITY_NOT_CLOSED',r['blocks']);self.assertTrue(r['freeze_integrity']['pass'])

if __name__=='__main__':unittest.main()
