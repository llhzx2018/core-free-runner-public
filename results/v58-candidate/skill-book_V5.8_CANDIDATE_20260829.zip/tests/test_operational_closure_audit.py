import json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1];S=R/'scripts'/'operational_closure_audit.py'
def w(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def rich():return '# x\n## 判断与执行\n'+('输入 判断 决策 规则 执行 步骤 验证 验收 错误 恢复 重试 完成。'*30)
class T(unittest.TestCase):
 def fixture(self,b,missing=None):
  root=b/'new';w(root/'chapters'/'01.md',rich());w(root/'templates'/'ops.md',rich())
  rtc={'BOOK_TYPE':'PRACTICAL_SKILL','MUST_BE_ABLE_TO_DO':[{'id':'do','statement':'获得 traffic conversion 并记录 revenue'}]};w(root/'evidence'/'reader_transformation_contract.json',json.dumps(rtc))
  names=['economics_viability','acquisition_funnel','execution_implementation','measurement_attribution','experiment_change_control','diagnosis_incident_recovery','quality_acceptance','scale_resource_constraints','operating_cadence','end_to_end_repeatable_workflow']
  rows=[]
  for n in names:
   app='REQUIRED' if n!='scale_resource_constraints' else 'OPTIONAL'
   if n==missing:continue
   rows.append({'responsibility':n,'applicability':app,'rationale':'specific task boundary explanation','chapter_paths':['chapters/01.md'],'asset_paths':['templates/ops.md'],'judgment':'判断何时继续、调整或停止当前路径','execution':'执行一个有记录、可复核的最小操作循环','validation':'用可验证结果与失败恢复条件确认完成'})
  w(root/'evidence'/'operational_closure_contract.json',json.dumps({'book_type':'PRACTICAL_SKILL','responsibilities':rows},ensure_ascii=False));return root
 def audit(self,root,stage='PRE_DRAFT'):
  out=root/'o.json';cp=subprocess.run(['python',str(S),'--new',str(root),'--stage',stage,'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())
 def test_complete_contract_passes(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(Path(d));cp,j=self.audit(r,'PRE_FREEZE');self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertEqual(j['decision'],'PASS')
 def test_missing_inferred_economics_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(Path(d),'economics_viability');cp,j=self.audit(r);self.assertNotEqual(cp.returncode,0);self.assertIn('OPERATIONAL_CLOSURE_GAP',j['blocks'])

 def test_generic_chinese_transformation_does_not_infer_acquisition(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(Path(d));rtc={'BOOK_TYPE':'PRACTICAL_SKILL','MUST_BE_ABLE_TO_DO':[{'id':'do','statement':'把原始笔记转化为可复用知识并记录结果'}]};w(r/'evidence'/'reader_transformation_contract.json',json.dumps(rtc,ensure_ascii=False));con=json.loads((r/'evidence'/'operational_closure_contract.json').read_text());
   for row in con['responsibilities']:
    if row['responsibility']=='acquisition_funnel':row['applicability']='OPTIONAL'
   w(r/'evidence'/'operational_closure_contract.json',json.dumps(con,ensure_ascii=False));cp,j=self.audit(r);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
 def test_chinese_conversion_rate_still_infers_acquisition(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.fixture(Path(d));rtc={'BOOK_TYPE':'PRACTICAL_SKILL','MUST_BE_ABLE_TO_DO':[{'id':'do','statement':'提升落地页转化率并记录结果'}]};w(r/'evidence'/'reader_transformation_contract.json',json.dumps(rtc,ensure_ascii=False));con=json.loads((r/'evidence'/'operational_closure_contract.json').read_text());
   for row in con['responsibilities']:
    if row['responsibility']=='acquisition_funnel':row['applicability']='OPTIONAL'
   w(r/'evidence'/'operational_closure_contract.json',json.dumps(con,ensure_ascii=False));cp,j=self.audit(r);self.assertNotEqual(cp.returncode,0);self.assertIn('OPERATIONAL_CLOSURE_GAP',j['blocks'])

if __name__=='__main__':unittest.main()
