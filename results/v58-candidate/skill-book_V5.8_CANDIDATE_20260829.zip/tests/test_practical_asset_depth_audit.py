import json, subprocess, tempfile, unittest
from pathlib import Path
R=Path(__file__).parents[1]; SCRIPT=R/'scripts'/'practical_asset_depth_audit.py'
def w(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf-8')

class T(unittest.TestCase):
    """Non-A1 domain: independently organize a 20-person offline reading-club event."""
    def make(self,name,text,roles,dims):
        td=tempfile.TemporaryDirectory(); root=Path(td.name); a=root/'templates'/name; w(a,text)
        c={'schema':'skill-book.practical-asset-depth.v1','assets':[{'path':a.relative_to(root).as_posix(),'roles':roles,'complexity':'HIGH','required_dimensions':dims,'n_a':{},'promise_links':['offline_reading_club_delivery']}]}
        w(root/'evidence'/'practical_asset_depth_contract.json',json.dumps(c,ensure_ascii=False)); return td,root
    def audit(self,root):
        out=root/'out.json'; cp=subprocess.run(['python',str(SCRIPT),'--new',str(root),'--json',str(out)],capture_output=True,text=True)
        return cp,json.loads(out.read_text()) if out.exists() else {}
    def good(self,name,text,roles,dims):
        td,r=self.make(name,text,roles,dims); cp,x=self.audit(r); self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr); self.assertEqual(x.get('decision'),'PASS'); td.cleanup()
    def bad(self,name,text,roles,dims,block):
        td,r=self.make(name,text,roles,dims); cp,x=self.audit(r); self.assertNotEqual(cp.returncode,0); self.assertIn(block,x.get('blocks',[]),x); td.cleanup()

    def test_good_evidence_capture(self):
        self.good('participant_evidence_ledger.md','''# Participant Evidence Ledger\nEvidence ID: ____ Observation: ____\nSource / participant: ____ Interview date: ____ Session context: ____\nConfidence: HIGH/MEDIUM/LOW Counter-evidence: ____ UNKNOWN: ____\nRaw statement: ____ Interpretation: ____\nDecision informed: ____ Follow-up evidence: ____\nCompletion: evidence is traceable and linked to a decision.\n''',['evidence_capture'],['input_evidence','state_boundary','evidence_log','completion'])
    def test_thin_provenance_blocks(self):
        self.bad('participant_evidence_ledger.md','# Ledger\nObservation: ____\nConfidence: ____\nDecision: ____\nDone: ____\n',['evidence_capture'],['input_evidence','evidence_log','completion'],'PRACTICAL_ASSET_REQUIRED_SUBRESPONSIBILITY_MISSING')

    def test_good_decision_and_change_control(self):
        self.good('venue_decision_record.md','''# Venue Decision Record\nOptions: A / B / C\nCriteria / threshold: capacity, access, noise, cost. Evidence source: ____\nSelected option: ____ Rationale / tradeoff: ____ Uncertainty: ____\nRevisit trigger: reconsider if forecast changes materially or evidence invalidates a criterion.\nBaseline version: ____ Proposed change: ____ Change reason / evidence: ____ Impact: ____ Revalidation: ____ Accept/Reject/Defer: ____\nWorked example: 18 expected attendees, 20 seats, access verified. Reference judgment: CONTINUE because capacity and access pass. Why: margin remains. Common mistake: using RSVP count as certainty. Adaptation: widen uncertainty when history is absent.\nCompletion: READY only when evidence is attached and no critical UNKNOWN remains.\n''',['decision_record'],['input_evidence','decision_rule','state_boundary','change_control','example_guidance','completion'])
    def test_version_field_and_sample_only_blocks(self):
        self.bad('venue_decision_record.md','''# Venue Decision\nOptions: A/B\nCriteria: cost and capacity\nDecision: A\nVersion: ____\nExample: 20 people\nCompletion: approved\n''',['decision_record'],['decision_rule','change_control','example_guidance','completion'],'PRACTICAL_ASSET_CHANGE_CONTROL_SHALLOW')
    def test_decision_without_revisit_trigger_blocks(self):
        self.bad('venue_decision_record.md','''# Venue Decision\nOptions: A / B / C\nCriteria / threshold: access and capacity. Evidence source: participant survey.\nSelected option: A. Rationale: strongest access. Uncertainty: attendance may change.\nCompletion: READY when evidence is attached.\n''',['decision_record'],['input_evidence','decision_rule','completion'],'PRACTICAL_ASSET_REQUIRED_SUBRESPONSIBILITY_MISSING')

    def test_good_change_control_standalone(self):
        self.good('event_plan_contract.md','''# Event Plan Contract\nGoal: run a 20-person reading club. Scope: venue, facilitation, materials.\nBaseline version: ____ Frozen scope: ____ Proposed change: ____ Change reason / evidence: ____\nOwner / authority: ____ Impact: ____ Revalidation: ____ Accept / Reject / Defer: ____ Superseded version / rollback target: ____\nExpected: approved plan. Actual: ____ Verification method: compare change against participant evidence. PASS / FAIL / PARTIAL: ____ Defect / rework: ____\nCompletion: close only after revalidation and new baseline record.\n''',['plan_or_contract'],['context_task','change_control','validation_acceptance','completion'])

    def test_good_execution_trace_and_recovery(self):
        self.good('event_run_brief.md','''# Event Run Brief\nInputs: run-of-show version, participant list source. Owner: ____\nSteps: 1 room check 2 materials check 3 admit participants 4 discussion 5 feedback. Checkpoint: ____ Exception path: ____\nEvidence log columns: Event ID | Time | Source/actor | Action/observation | Result | Interpretation | Linked decision/change.\nFailure trigger: ____ Diagnosis/cause: ____ Recovery action: ____ Retry condition: ____ Post-retry evidence: ____ Escalate or pause when: ____\nExpected: ____ Actual: ____ Verification method: ____ PASS/FAIL/PARTIAL: ____ Defect/rework: ____\nCompletion: close only when trace is complete and blockers are handed off.\n''',['execution_brief_or_log'],['input_evidence','execution_steps','evidence_log','failure_recovery','validation_acceptance','completion'])
    def test_date_note_log_blocks(self):
        self.bad('event_run_brief.md','''# Event Run Brief\nSteps: room, participants, discussion, feedback.\nDate | Note\nRetry if needed.\nValidation: PASS/FAIL. Completion: done.\n''',['execution_brief_or_log'],['execution_steps','evidence_log','failure_recovery','validation_acceptance','completion'],'PRACTICAL_ASSET_EVIDENCE_LOG_SHALLOW')

    def test_recovery_without_diagnosis_or_limit_blocks(self):
        self.bad('recovery_trace.md','''# Recovery Trace\nProblem: ____ Recovery action: ____ Retry: ____ Result: ____ Completion: ____\n''',['execution_brief_or_log'],['failure_recovery','evidence_log','completion'],'PRACTICAL_ASSET_RECOVERY_LOOP_INCOMPLETE')
    def test_good_recovery_loop_standalone(self):
        self.good('recovery_trace.md','''# Recovery Trace\nEvent ID: ____ Source/actor: ____ Time | ____ Action/observation: incident. Result: ____ Linked decision: ____\nFailure trigger: ____ Diagnosis / likely cause: ____ Recovery action: ____ Retry condition: ____ Post-retry evidence: ____ Escalate or pause when: ____\nSteps: 1 diagnose 2 recover 3 retry 4 verify. Completion: close only after post-retry evidence is recorded.\n''',['execution_brief_or_log'],['execution_steps','evidence_log','failure_recovery','completion'])

    def test_single_example_value_blocks(self):
        self.bad('attendance_decision_guide.md','''# Attendance Guide\nCriteria: RSVP and capacity. Decision: choose venue. Example: 20 people. Completion: record decision.\n''',['decision_record'],['decision_rule','example_guidance','completion'],'PRACTICAL_ASSET_EXAMPLE_GUIDANCE_SHALLOW')
    def test_good_example_guidance_standalone(self):
        self.good('attendance_decision_guide.md','''# Attendance Decision Guide\nOptions: small room / large room. Criteria / threshold: forecast and capacity. Evidence source: RSVP history. Selected option: ____ Rationale: ____ Revisit trigger: reconsider if forecast moves by 20%.\nWorked example: 24 RSVPs with an 80% historical show rate gives about 19 expected attendees. Reference judgment: CONTINUE with 20 seats only when overflow handling exists. Why: forecast uncertainty can exceed average attendance. Common mistake: treating RSVP count or 80% as certainty. Adaptation: with no history, widen uncertainty and gather another evidence source.\nCompletion: record decision and evidence.\n''',['decision_record'],['decision_rule','example_guidance','completion'])

if __name__=='__main__': unittest.main()
