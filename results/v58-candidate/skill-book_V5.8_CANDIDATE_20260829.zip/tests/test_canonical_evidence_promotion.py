import json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1];P=R/'scripts'/'promote_canonical_evidence.py';A=R/'scripts'/'canonical_evidence_promotion_audit.py'
def w(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
class T(unittest.TestCase):
 def test_promote_then_audit_passes_and_stale_hash_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);cand=root/'candidate.json';canon=root/'evidence'/'gate.json';state=root/'evidence'/'canonical_evidence_state.json';req=root/'evidence'/'canonical_evidence_requirements.json';w(cand,json.dumps({'decision':'PASS'}));w(req,json.dumps({'required_gates':['G']}))
   cp=subprocess.run(['python',str(P),'--candidate',str(cand),'--canonical',str(canon.relative_to(root)),'--state',str(state),'--gate','G','--run-id','run-2'],cwd=root,capture_output=True,text=True);self.assertEqual(cp.returncode,0,cp.stderr)
   out=root/'a.json';cp=subprocess.run(['python',str(A),'--new',str(root),'--json',str(out)],capture_output=True,text=True);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
   canon.write_text(json.dumps({'decision':'PASS','canonical_evidence':{'gate':'G','run_id':'run-1','promoted_at':'old'}}),encoding='utf-8')
   cp=subprocess.run(['python',str(A),'--new',str(root),'--json',str(out)],capture_output=True,text=True);j=json.loads(out.read_text());self.assertNotEqual(cp.returncode,0);self.assertIn('CANONICAL_EVIDENCE_PROMOTION_GAP',j['blocks'])
 def test_nonpass_candidate_cannot_promote(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);cand=root/'c.json';w(cand,json.dumps({'decision':'BLOCK'}));cp=subprocess.run(['python',str(P),'--candidate',str(cand),'--canonical','evidence/g.json','--state',str(root/'evidence'/'s.json'),'--gate','G','--run-id','r'],cwd=root,capture_output=True,text=True);self.assertNotEqual(cp.returncode,0)
if __name__=='__main__':unittest.main()
