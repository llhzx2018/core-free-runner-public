import hashlib,json,subprocess,tempfile,unittest
from pathlib import Path
R=Path(__file__).parents[1];SCRIPT=R/'scripts'/'baseline_applicability_audit.py';CREATE=R/'scripts'/'create_freeze_record.py'
def w(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj),encoding='utf-8')
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class T(unittest.TestCase):
 def fixture(self,app='NOT_APPLICABLE_NEW_BOOK'):
  td=tempfile.TemporaryDirectory();root=Path(td.name);c=root/'evidence'/'baseline_applicability_contract.json'
  w(r:=root/'BOOK.md','# Reader\n');w(root/'evidence'/'canonical_evidence_state.json',{});w(c,{'version':'V5.4_BASELINE_APPLICABILITY_CONTRACT','book_id':'C1','book_title':'New Book','declaration_stage':'PRE_DRAFT','applicability':app,'basis':'new identity' if app.startswith('NOT_') else 'existing identity','same_book_identity_required':True,'different_book_substitution_forbidden':True,'postfreeze_confirmation_required':app.startswith('NOT_')})
  return td,root,c
 def promote_pre(self,root):
  raw=root/'pre_raw.json';cp,x=self.audit(root,'PRE_DRAFT',out=raw);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);x['canonical_evidence']={'gate':'BASELINE_APPLICABILITY_PRE_DRAFT','run_id':'r1','promoted_at':'2026-01-01T00:00:00Z','candidate_sha256':'fixture'};w(root/'evidence'/'baseline_applicability_pre_draft.json',x)
 def freeze(self,root):
  cp=subprocess.run(['python',str(CREATE),'--new',str(root)],capture_output=True,text=True);self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr)
 def audit(self,root,stage,old=None,out=None):
  out=out or root/'out.json';cmd=['python',str(SCRIPT),'--new',str(root),'--stage',stage,'--json',str(out)]
  if old:cmd+=['--old',str(old)]
  cp=subprocess.run(cmd,capture_output=True,text=True);return cp,json.loads(out.read_text())
 def test_new_book_pre_draft_pass(self):
  td,r,c=self.fixture();cp,x=self.audit(r,'PRE_DRAFT');self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertEqual(x['decision'],'PASS');td.cleanup()
 def test_existing_requires_old_after_freeze(self):
  td,r,c=self.fixture('REQUIRED_EXISTING_CANONICAL');self.promote_pre(r);self.freeze(r);cp,x=self.audit(r,'POST_FREEZE');self.assertNotEqual(cp.returncode,0);self.assertIn('POST_DRAFT_BASELINE_DIFFERENTIAL_NOT_RUN',x['blocks']);td.cleanup()
 def test_new_book_valid_postfreeze_pass(self):
  td,r,c=self.fixture();self.promote_pre(r);self.freeze(r);f=r/'evidence'/'freeze_record.json';w(r/'evidence'/'baseline_applicability_postfreeze.json',{'decision':'PASS_NOT_APPLICABLE_NEW_BOOK','applicability':'NOT_APPLICABLE_NEW_BOOK','book_id':'C1','book_title':'New Book','searched_after_freeze':True,'matching_same_book_canonical_found':False,'different_book_substitution_used':False,'frozen_candidate_modified_after_search':False,'pre_draft_contract_sha256':sh(c),'freeze_record_sha256':sh(f)})
  cp,x=self.audit(r,'POST_FREEZE');self.assertEqual(cp.returncode,0,cp.stdout+cp.stderr);self.assertEqual(x['decision'],'PASS_NOT_APPLICABLE_NEW_BOOK');td.cleanup()
 def test_new_book_old_argument_contradiction_blocks(self):
  td,r,c=self.fixture();self.promote_pre(r);self.freeze(r);f=r/'evidence'/'freeze_record.json';old=r/'old';old.mkdir();w(r/'evidence'/'baseline_applicability_postfreeze.json',{'decision':'PASS_NOT_APPLICABLE_NEW_BOOK','applicability':'NOT_APPLICABLE_NEW_BOOK','book_id':'C1','book_title':'New Book','searched_after_freeze':True,'matching_same_book_canonical_found':False,'different_book_substitution_used':False,'frozen_candidate_modified_after_search':False,'pre_draft_contract_sha256':sh(c),'freeze_record_sha256':sh(f)})
  cp,x=self.audit(r,'POST_FREEZE',old);self.assertNotEqual(cp.returncode,0);self.assertIn('NEW_BOOK_NA_CONTRADICTED_BY_CANONICAL_ARGUMENT',x['blocks']);td.cleanup()
 def test_matching_canonical_invalidates_na(self):
  td,r,c=self.fixture();self.promote_pre(r);self.freeze(r);f=r/'evidence'/'freeze_record.json';w(r/'evidence'/'baseline_applicability_postfreeze.json',{'decision':'PASS_NOT_APPLICABLE_NEW_BOOK','applicability':'NOT_APPLICABLE_NEW_BOOK','book_id':'C1','book_title':'New Book','searched_after_freeze':True,'matching_same_book_canonical_found':True,'different_book_substitution_used':False,'frozen_candidate_modified_after_search':False,'pre_draft_contract_sha256':sh(c),'freeze_record_sha256':sh(f)})
  cp,x=self.audit(r,'POST_FREEZE');self.assertNotEqual(cp.returncode,0);self.assertIn('MATCHING_SAME_BOOK_CANONICAL_FOUND_OR_UNKNOWN',x['blocks']);td.cleanup()
 def test_late_declaration_blocks(self):
  td,r,c=self.fixture();d=json.loads(c.read_text());d['declaration_stage']='POST_FREEZE';w(c,d);cp,x=self.audit(r,'PRE_DRAFT');self.assertNotEqual(cp.returncode,0);self.assertIn('BASELINE_APPLICABILITY_NOT_DECLARED_PRE_DRAFT',x['blocks']);td.cleanup()
if __name__=='__main__':unittest.main()
