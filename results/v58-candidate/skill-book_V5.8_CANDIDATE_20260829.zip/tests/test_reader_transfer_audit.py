#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from copy import deepcopy
from pathlib import Path

HERE=Path(__file__).resolve().parent
SCRIPT=HERE.parent/'scripts'/'reader_transfer_audit.py'

DOMAIN='neighborhood equipment-lending day'

CONTRACT={
  'schema':'skill-book-reader-transfer-contract/v1',
  'domain':DOMAIN,
  'authority':{
    'proxy_layer':'BLIND_READER_PROXY_ONLY',
    'real_reader_derivation':'FORBIDDEN',
    'real_reader_evidence':'NOT_RUN'
  },
  'tasks':[
    {'id':'read-sequence','axis':'READ','required_responsibilities':['sequence','boundary','next_decision']},
    {'id':'learn-near-miss','axis':'LEARN','required_responsibilities':['rule','rationale','changed_case'],
     'near_miss':{'correct_option':'B','options':['A','B','C']}},
    {'id':'train-repair','axis':'TRAIN','required_responsibilities':['evidence_link','decision_rule','completion'],
     'requires_retry_repair':True},
    {'id':'do-handoff','axis':'DO','required_responsibilities':['state','evidence','next_action','acceptance'],
     'requires_operator_handoff':True}
  ]
}

PROXY={
  'schema':'skill-book-reader-transfer-proxy/v1',
  'source':{
    'kind':'BLIND_READER_PROXY',
    'reader_id':'proxy-neighborhood-01',
    'fresh':True,
    'blind_to':['generation_contract','verifier','canonical'],
    'real_reader':False
  },
  'domain':DOMAIN,
  'results':[
    {'task_id':'read-sequence','axis':'READ','first_attempt':{
      'answer':'First confirm item condition, then borrower evidence, then decide lend or hold; unknown condition blocks handoff.',
      'responsibilities':{'sequence':'PASS','boundary':'PASS','next_decision':'PASS'}}},
    {'task_id':'learn-near-miss','axis':'LEARN','first_attempt':{
      'answer':'If a drill has an unverified battery fault, do not treat a familiar borrower as sufficient evidence; hold and inspect.',
      'responsibilities':{'rule':'PASS','rationale':'PASS','changed_case':'PASS'}},
      'near_miss_choice':'B'},
    {'task_id':'train-repair','axis':'TRAIN','first_attempt':{
      'answer':'Lend because the borrower used it before.',
      'responsibilities':{'evidence_link':'FAIL','decision_rule':'FAIL','completion':'PASS'}},
      'feedback':{'target_responsibilities':['evidence_link','decision_rule'],
                  'message':'Tie the decision to current condition evidence and state the lend/hold rule.'},
      'retry':{'answer':'Hold until the current battery condition is recorded; lend only after condition evidence meets the inspection rule.',
               'responsibilities':{'evidence_link':'PASS','decision_rule':'PASS','completion':'PASS'},
               'changed_responsibilities':['evidence_link','decision_rule']}},
    {'task_id':'do-handoff','axis':'DO','first_attempt':{
      'answer':'Prepare the checked item, record borrower evidence, and hand off the next action.',
      'responsibilities':{'state':'PASS','evidence':'PASS','next_action':'PASS','acceptance':'PASS'}},
      'output':{'artifact':'lending-handoff-record','steps':['verify current condition','attach borrower evidence','record lend/hold decision'],
                'acceptance_results':{'condition_recorded':'PASS','decision_traceable':'PASS'}},
      'handoff':{
        'operator1':{'state_id':'item-17-HOLD','state':'HOLD_PENDING_INSPECTION','evidence':'condition-photo-17 + borrower-card-04','next_action':'inspect battery','owner':'operator-b'},
        'operator2':{'received_state_id':'item-17-HOLD','received_evidence':'condition-photo-17 + borrower-card-04','next_action':'inspect battery','result':'battery fault confirmed; keep HOLD','acceptance':'PASS'}
      }}
  ]
}

class T(unittest.TestCase):
    def run_audit(self, contract=CONTRACT, proxy=PROXY):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'evidence').mkdir()
            (root/'evidence'/'reader_transfer_contract.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
            (root/'evidence'/'reader_transfer_proxy.json').write_text(json.dumps(proxy,ensure_ascii=False,indent=2),encoding='utf-8')
            cp=subprocess.run([sys.executable,str(SCRIPT),'--new',str(root)],text=True,capture_output=True)
            try: report=json.loads(cp.stdout)
            except Exception: report={'raw_stdout':cp.stdout,'stderr':cp.stderr}
            return cp.returncode,report

    def assert_block(self, proxy, code, contract=CONTRACT):
        rc,r=self.run_audit(contract,proxy)
        self.assertNotEqual(rc,0,r)
        self.assertIn(code,r.get('blocks',[]),r)

    def test_good_blind_reader_proxy_passes_but_real_reader_stays_not_run(self):
        rc,r=self.run_audit()
        self.assertEqual(rc,0,r)
        self.assertEqual(r['decision'],'PASS')
        self.assertEqual(r['proxy_result'],'BLIND_READER_PROXY_PASS')
        self.assertEqual(r['real_reader_evidence'],'NOT_RUN')

    def test_proxy_must_be_fresh(self):
        p=deepcopy(PROXY); p['source']['fresh']=False
        self.assert_block(p,'PROXY_NOT_FRESH')

    def test_proxy_must_be_blind_to_generation_verifier_and_canonical(self):
        p=deepcopy(PROXY); p['source']['blind_to']=['canonical']
        self.assert_block(p,'PROXY_NOT_BLIND')

    def test_proxy_cannot_claim_real_reader_authority(self):
        p=deepcopy(PROXY); p['source']['real_reader']=True
        self.assert_block(p,'PROXY_REAL_READER_AUTHORITY_COLLISION')

    def test_all_four_axes_are_required(self):
        p=deepcopy(PROXY); p['results']=[x for x in p['results'] if x['axis']!='DO']
        self.assert_block(p,'TRANSFER_TASK_COVERAGE_GAP')

    def test_read_requires_sequence_boundary_and_next_decision(self):
        p=deepcopy(PROXY); p['results'][0]['first_attempt']['responsibilities']['boundary']='FAIL'
        self.assert_block(p,'READ_RETRIEVAL_GAP')

    def test_near_miss_confusion_blocks_learn(self):
        p=deepcopy(PROXY); p['results'][1]['near_miss_choice']='A'
        self.assert_block(p,'NEAR_MISS_CONFUSION')

    def test_learn_changed_case_responsibility_is_required(self):
        p=deepcopy(PROXY); p['results'][1]['first_attempt']['responsibilities']['changed_case']='FAIL'
        self.assert_block(p,'LEARN_TRANSFER_GAP')

    def test_train_requires_feedback_targeting_failed_responsibility(self):
        p=deepcopy(PROXY); p['results'][2]['feedback']['target_responsibilities']=['completion']
        self.assert_block(p,'TRAIN_FEEDBACK_LOOP_MISSING')

    def test_retry_must_repair_failed_responsibilities_and_change_answer(self):
        p=deepcopy(PROXY)
        tr=p['results'][2]
        tr['retry']['responsibilities']['decision_rule']='FAIL'
        tr['retry']['changed_responsibilities']=['evidence_link']
        tr['retry']['answer']=tr['first_attempt']['answer']
        self.assert_block(p,'RETRY_DID_NOT_REPAIR_RESPONSIBILITY')

    def test_do_output_must_be_actionable_and_accepted(self):
        p=deepcopy(PROXY); p['results'][3]['output']['steps']=['think about lending']
        p['results'][3]['output']['acceptance_results']['decision_traceable']='FAIL'
        self.assert_block(p,'DO_OUTPUT_NOT_ACTIONABLE')

    def test_operator_handoff_requires_linked_state_evidence_next_action_and_acceptance(self):
        p=deepcopy(PROXY); p['results'][3]['handoff']['operator2']['received_state_id']='wrong-state'
        p['results'][3]['handoff']['operator2']['received_evidence']=''
        self.assert_block(p,'OPERATOR_HANDOFF_NOT_SELF_SUFFICIENT')

    def test_contract_cannot_authorize_real_reader_from_proxy(self):
        c=deepcopy(CONTRACT); c['authority']['real_reader_derivation']='ALLOWED'
        rc,r=self.run_audit(c,PROXY)
        self.assertNotEqual(rc,0,r)
        self.assertIn('REAL_READER_AUTHORITY_BOUNDARY_INVALID',r.get('blocks',[]),r)

if __name__=='__main__': unittest.main()
