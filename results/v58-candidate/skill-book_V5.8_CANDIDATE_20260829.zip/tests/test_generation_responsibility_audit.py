from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

SCRIPT=Path(__file__).parents[1]/'scripts'/'generation_responsibility_audit.py'

def rich(label:str)->str:
    core=(f"{label}。任务输入与证据必须记录；按规则判断条件和边界，随后执行步骤并产生输出。"
          "必须验证与验收实际结果，失败时记录原因、恢复、重试，并写明完成条件和下一步决策。")
    return '# '+label+'\n\n## 使用\n'+('\n\n'.join([core]*5))+'\n'

def fixture(root:Path, break_class=False, break_mapping=False):
    (root/'evidence').mkdir(parents=True);(root/'chapters').mkdir();(root/'templates').mkdir()
    rtc={'BOOK_TYPE':'PRACTICAL_PROJECT','TARGET_READER':'reader','CURRENT_STATE':'start','DESIRED_STATE':'finish','MUST_UNDERSTAND':['u1'],'MUST_BE_ABLE_TO_JUDGE':[{'id':'judge_1','statement':'judge a candidate'}],'MUST_BE_ABLE_TO_DO':[{'id':'do_1','statement':'execute and verify the project'}],'MUST_AVOID':['fake green'],'COMPLETION_EVIDENCE':['verified output']}
    (root/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
    phases=[]
    for p in ('DISCOVER','DECIDE','PLAN','EXECUTE','VERIFY','RELEASE_OR_USE','OBSERVE','ITERATE'):
        phases.append({'phase':p,'applicability':'OPTIONAL' if p=='RELEASE_OR_USE' else 'REQUIRED','rationale':'release form depends on the project and reader context'})
    classes=['evidence_capture','decision_record','plan_or_contract','execution_brief_or_log','acceptance_record','baseline_snapshot','iteration_log','next_decision'];class_rows=[]
    for i,c in enumerate(classes,1):
        if break_class and c=='next_decision':continue
        path=f'templates/{i:02d}_{c}.md';class_rows.append({'class':c,'applicability':'REQUIRED','asset_paths':[path]});(root/path).write_text(rich(c))
    for i in (1,2):(root/f'chapters/{i:02d}_chapter.md').write_text(rich(f'chapter {i}'))
    mappings=[{'capability_id':'judge_1','statement':'judge a candidate','chapter_paths':['chapters/01_chapter.md'],'asset_paths':['templates/02_decision_record.md']},{'capability_id':'do_1','statement':'execute and verify the project','chapter_paths':['chapters/02_chapter.md'],'asset_paths':[] if break_mapping else ['templates/05_acceptance_record.md']}]
    phase_depth=[{'phase':p,'applicability':'OPTIONAL','rationale':'This phase is explicitly reviewed against the current reader transformation and task promise.'} for p in ('PROBLEM_DISCOVERY','OPPORTUNITY_SELECTION','ALTERNATIVE_PRESSURE','PREBUILD_VALIDATION','DEVELOPMENT_ENTRY_DECISION','SCOPE','BUILD','ACCEPTANCE','PRODUCTION','DISCOVERABILITY','ACTIVATION','OBSERVABILITY_DECISION')]
    contract={'book_type':'PRACTICAL_PROJECT','lifecycle':phases,'phase_depth':phase_depth,'capability_mappings':mappings,'operator_responsibility_classes':class_rows}
    (root/'evidence'/'generation_responsibility_contract.json').write_text(json.dumps(contract,ensure_ascii=False))

def run(root:Path,stage='PRE_FREEZE'):
    out=root/f'{stage}.json';cp=subprocess.run([sys.executable,str(SCRIPT),'--new',str(root),'--stage',stage,'--json',str(out)],capture_output=True,text=True);return cp,json.loads(out.read_text())

def test_passes_complete_project_responsibility(tmp_path):
    fixture(tmp_path);cp1,r1=run(tmp_path,'PRE_DRAFT');cp2,r2=run(tmp_path,'PRE_FREEZE');assert cp1.returncode==0 and r1['decision']=='PASS';assert cp2.returncode==0 and r2['decision']=='PASS'

def test_blocks_missing_lifecycle_operator_class(tmp_path):
    fixture(tmp_path,break_class=True);cp,r=run(tmp_path);assert cp.returncode==1;assert 'OPERATOR_RESPONSIBILITY_CLASS_GAP' in r['blocks']

def test_blocks_unmapped_do_asset(tmp_path):
    fixture(tmp_path,break_mapping=True);cp,r=run(tmp_path);assert cp.returncode==1;assert 'CRITICAL_CAPABILITY_TRACEABILITY_GAP' in r['blocks']


def add_prebuild_bundle(root, con, shared=False):
    specs={
      'problem_opportunity_selection':['evidence_quality','alternative_candidates','selection_rule','rejection_rule'],
      'alternative_pressure':['existing_supply','task_fit','switching_cost','disconfirming_evidence'],
      'prebuild_behavioral_validation':['critical_unknown','lightest_test','observable_behavior','decision_rule'],
      'development_entry_decision':['entry_evidence','continue_rule','revise_pause_stop','next_risk'],
    }
    text=rich('prebuild')*6
    (root/'references'/'operator').mkdir(parents=True,exist_ok=True)
    rows=[]
    for i,(n,dims) in enumerate(specs.items(),1):
        ch=f'chapters/pre_{i}.md'; ref=f'references/operator/pre_{i}.md'; asset='templates/shared_prebuild.md' if shared else f'templates/pre_{i}.md'
        (root/ch).write_text(text);(root/ref).write_text(text);(root/asset).write_text(text)
        rows.append({'responsibility':n,'applicability':'REQUIRED','dimensions':dims,'chapter_paths':[ch],'operator_reference_paths':[ref],'asset_paths':[asset],'judgment':'判断证据是否足以继续，并明确最强反证和停止条件','execution':'执行最轻量的比较或行为验证并记录真实输入与输出','validation':'用事先定义的行为或供给证据检查判断是否成立','failure_recovery':'失败时定位最早断点，修改一个主要变量后重新验证','completion':'只有达到进入条件才推进，否则明确 REVISE PAUSE STOP 和下一动作'})
    con['prebuild_responsibilities']=rows
    for row in con['phase_depth']:
        if row['phase'] in {'PROBLEM_DISCOVERY','OPPORTUNITY_SELECTION','ALTERNATIVE_PRESSURE','PREBUILD_VALIDATION','DEVELOPMENT_ENTRY_DECISION','SCOPE','BUILD','ACCEPTANCE','PRODUCTION','DISCOVERABILITY','ACTIVATION','OBSERVABILITY_DECISION'}:
            row['applicability']='REQUIRED'
    return con


def test_web_launch_promise_missing_bundle_blocks(tmp_path):
    fixture(tmp_path)
    rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text())
    rtc['BOOK_TITLE']='从真实需求到第一版上线的网站实战'
    rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'完成一个网站上线并获得第一批真实用户'}]
    (tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
    cp,r=run(tmp_path,'PRE_DRAFT');assert cp.returncode==1;assert 'BOOK_PROMISE_RESPONSIBILITY_GAP' in r['blocks']

def test_web_launch_promise_three_layer_bundle_passes(tmp_path):
    fixture(tmp_path)
    rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text())
    rtc['BOOK_TITLE']='从真实需求到第一版上线的网站实战'
    rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'完成一个网站上线并获得第一批真实用户'}]
    (tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
    con=json.loads((tmp_path/'evidence'/'generation_responsibility_contract.json').read_text())
    # Inferred: delivery, access/routing, rollback, user acquisition, discoverability.
    specs={
      'real_world_delivery':['candidate_identity','preview_vs_production','production_readback','rollback'],
      'access_identity_routing':['identity','routing','secure_access','negative_path'],
      'rollback_recovery':['rollback_target','rollback_method','stateful_caveat','retest'],
      'user_acquisition_activation':['reach','start','value_action','feedback'],
      'discoverability_distribution':['channel_access','index_or_distribution_control','diagnostic_surface','time_window'],
    }
    text=rich('promise')*6
    (tmp_path/'chapters'/'01_chapter.md').write_text(text)
    (tmp_path/'references'/'operator').mkdir(parents=True,exist_ok=True)
    (tmp_path/'references'/'operator'/'promise.md').write_text(text)
    (tmp_path/'templates'/'promise.md').write_text(text)
    con['promise_responsibilities']=[{'responsibility':n,'applicability':'REQUIRED','dimensions':dims,'chapter_paths':['chapters/01_chapter.md'],'operator_reference_paths':['references/operator/promise.md'],'asset_paths':['templates/promise.md'],'judgment':'判断何时满足该承诺、哪些证据不足以及何时必须停止继续推进','execution':'执行完整的真实环境操作并记录关键事实','validation':'用可复核结果验证承诺而不是相信完成声明','failure_recovery':'失败时定位原因、回退并按同样条件重新验证','completion':'所有关键状态均有可复核证据、失败恢复已验证且下一步进入条件明确'} for n,dims in specs.items()]
    con=add_prebuild_bundle(tmp_path,con)
    (tmp_path/'evidence'/'generation_responsibility_contract.json').write_text(json.dumps(con,ensure_ascii=False))
    cp,r=run(tmp_path,'PRE_FREEZE');assert cp.returncode==0,r


def test_v54_demand_to_build_requires_prebuild_chain(tmp_path):
    fixture(tmp_path)
    rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text())
    rtc['BOOK_TITLE']='从真实需求到第一个可上线网站'
    rtc['MUST_BE_ABLE_TO_JUDGE']=[{'id':'judge_1','statement':'判断真实需求与伪需求，选择值得做的机会'}]
    rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'验证需求后开发并上线网站'}]
    (tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
    cp,r=run(tmp_path,'PRE_DRAFT')
    assert cp.returncode==1
    assert 'PREBUILD_RESPONSIBILITY_GAP' in r['blocks']
    assert 'PHASE_DEPTH_PRESERVATION_GAP' in r['blocks']

def test_v54_complete_prebuild_chain_passes_pre_draft(tmp_path):
    fixture(tmp_path)
    rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text())
    rtc['BOOK_TITLE']='从真实需求验证到开发一个网站'
    rtc['MUST_BE_ABLE_TO_JUDGE']=[{'id':'judge_1','statement':'判断真实需求、替代方案与进入开发的条件'}]
    rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'完成行为验证后开发网站'}]
    (tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
    con=json.loads((tmp_path/'evidence'/'generation_responsibility_contract.json').read_text())
    con=add_prebuild_bundle(tmp_path,con)
    (tmp_path/'evidence'/'generation_responsibility_contract.json').write_text(json.dumps(con,ensure_ascii=False))
    cp,r=run(tmp_path,'PRE_DRAFT')
    assert cp.returncode==0,r
    assert set(r['prebuild_responsibilities']['inferred_required'])=={'problem_opportunity_selection','alternative_pressure','prebuild_behavioral_validation','development_entry_decision'}

def test_v54_prebuild_one_universal_asset_cannot_cover_all_without_rationale(tmp_path):
    fixture(tmp_path)
    rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text())
    rtc['BOOK_TITLE']='从真实需求验证到开发一个网站'
    rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'验证真实需求后开发网站'}]
    (tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
    con=json.loads((tmp_path/'evidence'/'generation_responsibility_contract.json').read_text())
    con=add_prebuild_bundle(tmp_path,con,shared=True)
    (tmp_path/'evidence'/'generation_responsibility_contract.json').write_text(json.dumps(con,ensure_ascii=False))
    cp,r=run(tmp_path,'PRE_DRAFT')
    assert cp.returncode==1
    assert 'PREBUILD_RESPONSIBILITY_GAP' in r['blocks']
    assert any(x.get('reason')=='PREBUILD_ASSET_OVER_COLLAPSED_WITHOUT_RATIONALE' for x in r['prebuild_responsibilities']['failures'])


def test_v55_structured_one_signal_margin_prevents_narrow_lexical_false_negative(tmp_path):
 fixture(tmp_path)
 rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text());rtc['BOOK_TYPE']='PRACTICAL_SKILL';rtc['BOOK_TITLE']='观察数据并做决策';rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'观察数据并做决策'}];(tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
 con=json.loads((tmp_path/'evidence'/'generation_responsibility_contract.json').read_text());con['book_type']='PRACTICAL_SKILL'
 text=('## H\n判断 条件 输入 输出 执行 验证。\n'*7)+('内容'*400);(tmp_path/'references'/'operator').mkdir(parents=True,exist_ok=True);(tmp_path/'references'/'operator'/'p.md').write_text(text);(tmp_path/'templates'/'p.md').write_text(text);(tmp_path/'chapters'/'01_chapter.md').write_text(rich('promise')*8)
 con['promise_responsibilities']=[{'responsibility':'observability_decision','applicability':'REQUIRED','dimensions':['baseline','signal_interpretation','change_control','next_decision'],'chapter_paths':['chapters/01_chapter.md'],'operator_reference_paths':['references/operator/p.md'],'asset_paths':['templates/p.md'],'judgment':'判断何时满足当前承诺、哪些证据仍然不足，以及何时必须停止继续推进','execution':'执行真实操作并记录输入、步骤、输出与可以独立复核的关键事实','validation':'使用可以重复检查的实际结果验证承诺，而不是相信完成声明或主观感觉','failure_recovery':'失败时定位最早的原因，执行恢复或纠错动作，并按相同条件重新验证','completion':'所有关键状态都有可复核证据，失败恢复已验证，并且下一步进入条件明确'}];(tmp_path/'evidence'/'generation_responsibility_contract.json').write_text(json.dumps(con,ensure_ascii=False))
 cp,r=run(tmp_path,'PRE_FREEZE');assert cp.returncode==0,r
 assert any(c.get('semantic_margin')=='STRUCTURED_ONE_SIGNAL_MARGIN' for d in r['book_promise_responsibilities']['details'] for c in d.get('checks',[]))

def test_v55_structured_margin_does_not_rescue_truly_low_signal_asset(tmp_path):
 fixture(tmp_path)
 rtc=json.loads((tmp_path/'evidence'/'reader_transformation_contract.json').read_text());rtc['BOOK_TYPE']='PRACTICAL_SKILL';rtc['BOOK_TITLE']='观察数据并做决策';rtc['MUST_BE_ABLE_TO_DO']=[{'id':'do_1','statement':'观察数据并做决策'}];(tmp_path/'evidence'/'reader_transformation_contract.json').write_text(json.dumps(rtc,ensure_ascii=False))
 con=json.loads((tmp_path/'evidence'/'generation_responsibility_contract.json').read_text());con['book_type']='PRACTICAL_SKILL'
 text=('## H\n描述信息。\n'*7)+('内容'*400);(tmp_path/'references'/'operator').mkdir(parents=True,exist_ok=True);(tmp_path/'references'/'operator'/'p.md').write_text(text);(tmp_path/'templates'/'p.md').write_text(text);(tmp_path/'chapters'/'01_chapter.md').write_text(rich('promise')*8)
 con['promise_responsibilities']=[{'responsibility':'observability_decision','applicability':'REQUIRED','dimensions':['baseline','signal_interpretation','change_control','next_decision'],'chapter_paths':['chapters/01_chapter.md'],'operator_reference_paths':['references/operator/p.md'],'asset_paths':['templates/p.md'],'judgment':'判断何时满足当前承诺、哪些证据仍然不足，以及何时必须停止继续推进','execution':'执行真实操作并记录输入、步骤、输出与可以独立复核的关键事实','validation':'使用可以重复检查的实际结果验证承诺，而不是相信完成声明或主观感觉','failure_recovery':'失败时定位最早的原因，执行恢复或纠错动作，并按相同条件重新验证','completion':'所有关键状态都有可复核证据，失败恢复已验证，并且下一步进入条件明确'}];(tmp_path/'evidence'/'generation_responsibility_contract.json').write_text(json.dumps(con,ensure_ascii=False))
 cp,r=run(tmp_path,'PRE_FREEZE');assert cp.returncode!=0;assert 'BOOK_PROMISE_RESPONSIBILITY_GAP' in r['blocks']
