import unittest
from pathlib import Path
R=Path(__file__).parents[1]

class T(unittest.TestCase):
 def test_version(self):
  self.assertEqual((R/'VERSION').read_text().strip(),'5.8')

 def test_agent_metadata_version(self):
  s=(R/'agents/openai.yaml').read_text()
  self.assertIn('version: 5.8',s)
  self.assertIn('status: candidate_not_current',s)
  self.assertIn('full-book substance',s.lower())
  self.assertIn('blind-reader transfer',s.lower())

 def test_candidate_and_reader_first_priority(self):
  s=(R/'SKILL.md').read_text()
  for x in ['skill-book V5.8 Candidate','CANDIDATE / NOT CURRENT','SB58-RUNTIME-CONTRACT-BF41D2E7','BOOK FIRST','CONTINUOUS READING','FULL_BOOK_SUBSTANCE','READER_FACING_PACKAGING']:
   self.assertIn(x,s)

 def test_supported_full_book_and_sealed_mode(self):
  s=(R/'SKILL.md').read_text()
  for x in ['FULL_BOOK','SEALED_STANDALONE_FORWARD','FIRST_FREEZE']:
   self.assertIn(x,s)

 def test_depth_authority(self):
  s=(R/'SKILL.md').read_text()
  for x in ['Chapter Substance Plan','Pass A — Causal Core','Pass B — Human Reading','Pass C — Transfer + Operation','PREFREEZE_RANDOM_OPEN']:
   self.assertIn(x,s)
  r=(R/'references/generation_depth_contract.md').read_text()
  for x in ['Pre-draft Depth Plan','Mass Compression Stop','Full-book shell-risk check','Continuous reading']:
   self.assertIn(x,r)

 def test_reader_outcome_doctrine(self):
  s=(R/'SKILL.md').read_text()
  for x in ['读得下去','学得会','练得到','做得出','READ','LEARN','TRAIN','DO']:
   self.assertIn(x,s)
  r=(R/'references/reader_test_contract.md').read_text()
  for x in ['READ','LEARN','TRAIN','DO','Feedback / Reference Judgment']:
   self.assertIn(x,r)

 def test_inherited_authorities_exist(self):
  paths=[
   'scripts/adequacy_audit.py','scripts/practical_asset_depth_audit.py','scripts/postdraft_baseline_audit.py',
   'scripts/generation_responsibility_audit.py','scripts/prefreeze_random_open_audit.py','scripts/runtime_acceptance_audit.py',
   'references/runtime_authority_fidelity_contract.md','scripts/runtime_authority_fidelity_audit.py',
   'references/book_promise_responsibility_contract.md','scripts/postfreeze_holdout_audit.py',
   'references/freeze_integrity_contract.md','scripts/freeze_integrity_audit.py','scripts/create_freeze_record.py',
   'references/operational_closure_contract.md','references/training_feedback_contract.md',
   'references/canonical_evidence_promotion_contract.md','references/shadow_local_value_contract.md',
   'references/strict_holdout_contract.md','scripts/operational_closure_audit.py','scripts/training_feedback_audit.py',
   'scripts/promote_canonical_evidence.py','scripts/canonical_evidence_promotion_audit.py',
   'scripts/strict_holdout_receipt_audit.py','scripts/shadow_local_value_audit.py',
   'references/baseline_applicability_contract.md','scripts/baseline_applicability_audit.py',
   'references/phase_depth_preservation_contract.md','references/practical_asset_depth_contract.md',
   'references/reader_transfer_contract.md','scripts/reader_transfer_audit.py',
   'tests/test_reader_transfer_audit.py','tests/test_reader_transfer_v56_false_green_bridge.py'
  ]
  for p in paths:self.assertTrue((R/p).exists(),p)

 def test_v58_new_authorities_exist(self):
  for p in [
   'references/full_book_substance_contract.md','references/continuous_reading_contract.md',
   'references/reader_facing_packaging_contract.md','references/evidence_budget_contract.md',
   'scripts/full_book_substance_audit.py','scripts/continuous_reading_audit.py',
   'scripts/reader_facing_packaging_audit.py','tests/test_v58_reader_first_rebalance.py'
  ]:
   self.assertTrue((R/p).exists(),p)

 def test_baseline_and_transfer_boundaries(self):
  s=(R/'SKILL.md').read_text()
  for x in ['Baseline Applicability','evaluator-only','BLIND_READER_PROXY_PASS != REAL_READER_PASS','FRESH_ISOLATED_BLIND_PROXY','REAL_READER_EVIDENCE = NOT_RUN']:
   self.assertIn(x,s)
  r=(R/'references/runtime_entry_receipt_contract.md').read_text()
  self.assertIn('SB58-RUNTIME-CONTRACT-BF41D2E7',r)
  self.assertIn('"5.8"',r)

 def test_holdout_seed_not_embedded_in_generator_contract(self):
  s=(R/'scripts/prefreeze_random_open_audit.py').read_text()
  self.assertNotIn("'HOLDOUT'",s)
  self.assertNotIn('49700',s)

 def test_executable_version_metadata_consistent(self):
  for p in (R/'scripts').glob('*.py'):
   s=p.read_text()
   self.assertNotRegex(s,r"['\"]version['\"]\s*:\s*['\"]V4\.",p.name)
   self.assertNotIn('SB49-RUNTIME-CONTRACT',s,p.name)
   self.assertNotIn('SB50-RUNTIME-CONTRACT',s,p.name)
   self.assertNotIn('SB51-RUNTIME-CONTRACT',s,p.name)
   self.assertNotIn("EXPECTED_SKILL_VERSION='5.3'",s,p.name)

 def test_entry_is_materially_smaller_than_v57_style_budget(self):
  self.assertLess(len((R/'SKILL.md').read_bytes()),35000)

if __name__=='__main__':unittest.main()
