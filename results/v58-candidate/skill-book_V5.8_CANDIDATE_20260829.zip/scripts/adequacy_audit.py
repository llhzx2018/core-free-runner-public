#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

TEXT_EXT={'.md','.markdown','.txt','.csv','.tsv'}
DIMENSIONS={
 'context_task': ('目标','任务','问题','用户','角色','场景','对象','goal','task','purpose','context','moment'),
 'input_evidence': ('输入','来源','证据','原始','链接','样本','前置','input','source','evidence','precondition'),
 'decision_rule': ('判断','决定','决策','规则','阈值','条件','continue','revise','pause','stop','decision','criteria'),
 'state_boundary': ('边界','状态','unknown','invalid','empty','non-goal','later','不做','例外','scope','state'),
 'execution_steps': ('步骤','流程','执行','操作','动作','step','action','procedure'),
 'validation_acceptance': ('验证','验收','预期','实际','检查','测试','pass','fail','quality','expected','actual','test'),
 'evidence_log': ('记录','日志','日期','回源','trace','log','record','date','source id'),
 'failure_recovery': ('错误','失败','恢复','纠错','回滚','重试','retry','rollback','recovery','why wrong','为什么错'),
 'change_control': ('版本','变更','冻结','复核','owner','authority','change','version','freeze','superseded'),
 'completion': ('完成','进入下一步','退出','允许进入','completion','done','gate','close'),
 'example_guidance': ('示例','案例','例如','参考判断','worked example','example','sample'),
}
FEEDBACK_GROUPS={
 'expected_output': ('expected output','quality bar','预期输出','质量标准','合格标准','完成产物'),
 'reference_judgment': ('参考判断','参考答案','worked answer','答案解析','判断参考'),
 'common_error': ('常见错误','为什么错','错误诊断','common error','why wrong'),
 'correction': ('纠错','修正','改正','correction','improved output'),
 'retry': ('重试','重新检查','re-check','retry','再做一次'),
}
HIGH_HINTS=('problem','opportunity','validation','contract','brief','acceptance','deployment','launch','baseline','decision','sop','log','plan','问题','机会','验证','合同','验收','部署','上线','决策','日志','计划')

def t(p:Path): return p.read_text(encoding='utf-8',errors='replace')
def compact(s:str): return re.sub(r'\s+','',s)
def cid(p:Path):
 m=re.match(r'^0*(\d{1,3})[_ .-]',p.name)
 if m:return int(m.group(1))
 m=re.search(r'第\s*0*(\d{1,3})\s*章',p.stem)
 return int(m.group(1)) if m else None

def chapters(root:Path):
 out=[]
 for d in (root/'manuscript', root/'chapters', root/'book'/'chapters'):
  if d.exists():out += [p for p in d.glob('*.md') if cid(p)]
 return sorted(set(out),key=lambda p:(cid(p) or 999,p.name))
def refs(root:Path):
 out=[]
 for d in (root/'operator_reference',root/'references'/'operator',root/'references'/'operator_reference'):
  if d.exists():out += list(d.glob('*.md'))
 return sorted(set(out))
def templates(root:Path):
 out=[]
 d=root/'templates'
 if d.exists(): out += [p for p in d.iterdir() if p.is_file() and p.suffix.lower() in TEXT_EXT]
 # Runtime packaging may mirror practical assets under /assets. Discover them too,
 # but exclude planning/meta documents and filled worked examples from blank-tool adequacy.
 ad=root/'assets'
 if ad.exists():
  for p in ad.iterdir():
   n=p.name.lower()
   if not p.is_file() or p.suffix.lower() not in TEXT_EXT: continue
   if any(x in n for x in ('reader_transformation','depth_plan','worked_example','example_filled')): continue
   out.append(p)
 return sorted(set(out))

def dim_hits(s:str):
 low=s.lower(); return {k:[w for w in words if w.lower() in low] for k,words in DIMENSIONS.items() if any(w.lower() in low for w in words)}
def feedback_hits(s:str):
 low=s.lower(); return {k:[w for w in words if w.lower() in low] for k,words in FEEDBACK_GROUPS.items() if any(w.lower() in low for w in words)}
def structure(s:str):
 lines=s.splitlines()
 headings=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in lines)
 table_rows=sum(x.strip().startswith('|') and x.strip().endswith('|') for x in lines)
 checks=sum(('- [ ]' in x or '- [x]' in x.lower()) for x in lines)
 prompts=sum(bool(re.search(r'(?:：|:)\s*(?:`?_{2,}`?|\s*)$',x.strip())) for x in lines if len(x.strip())<140)
 lists=sum(bool(re.match(r'^\s*(?:[-*]|\d+[.)])\s+',x)) for x in lines)
 units=headings+min(table_rows,16)+min(checks,12)+min(prompts,12)+min(lists,12)
 return {'headings':headings,'table_rows':table_rows,'checkboxes':checks,'prompt_fields':prompts,'list_items':lists,'units':units}
def complexity_from_name(p:Path):
 n=p.stem.lower()
 return 'HIGH' if any(x in n for x in HIGH_HINTS) else 'MEDIUM'
def thresholds(level:str):
 return {'HIGH':(8,700,10),'MEDIUM':(6,420,6),'LOW':(4,220,3)}[level]
def rel(root,p): return p.relative_to(root).as_posix()

def load_profile(root:Path, explicit:str|None):
 candidates=[]
 if explicit:candidates.append(Path(explicit))
 candidates += [root/'evidence'/'adequacy_contract.json',root/'frontmatter'/'adequacy_contract.json',root/'adequacy_contract.json']
 for p in candidates:
  if p.exists():
   try:return p,json.loads(t(p))
   except Exception:return p,{'parse_error':True}
 return None,None

def profile_maps(profile):
 ch={}; assets={}
 if not isinstance(profile,dict):return ch,assets
 for row in profile.get('chapters',[]):
  if isinstance(row,dict) and row.get('path'):ch[str(row['path'])]=row
 for row in profile.get('assets',[]):
  if isinstance(row,dict) and row.get('path'):assets[str(row['path'])]=row
 return ch,assets

def recalculated_chapter_level(row:dict):
 counts=sum(len(row.get(k,[]) or []) for k in ('must_explain','must_judge','boundaries','failure_modes','practice_outputs'))
 counts += 2*len(row.get('template_assets',[]) or []) + len(row.get('worked_examples',[]) or [])
 if counts>=14:return 'HIGH',counts
 if counts>=8:return 'MEDIUM',counts
 return 'LOW',counts

def chapter_profile_check(root:Path,chs,profile):
 pchs,_=profile_maps(profile); rows=[]; bad=[]
 by_rel={rel(root,p):p for p in chs}
 for path,p in by_rel.items():
  row=pchs.get(path)
  if not row:
   item={'path':path,'reason':'MISSING_CHAPTER_ADEQUACY_PROFILE'};rows.append(item);bad.append(item);continue
  level,points=recalculated_chapter_level(row)
  declared=str(row.get('complexity','')).upper() or 'UNDECLARED'
  text=t(p); dh=dim_hits(text); st=structure(text); chars=len(compact(text))
  req={'HIGH':{'must_explain':4,'must_judge':3,'boundaries':2,'failure_modes':2,'worked_examples':1,'practice_outputs':1},'MEDIUM':{'must_explain':3,'must_judge':2,'boundaries':1,'failure_modes':1,'worked_examples':1,'practice_outputs':1},'LOW':{'must_explain':2,'must_judge':1,'boundaries':0,'failure_modes':0,'worked_examples':0,'practice_outputs':0}}[level]
  missing={k:reqn-len(row.get(k,[]) or []) for k,reqn in req.items() if len(row.get(k,[]) or [])<reqn}
  # Character floors are shell-risk floors only; they never prove adequacy.
  floor={'HIGH':2600,'MEDIUM':1700,'LOW':900}[level]
  reasons=[]
  rank={'LOW':1,'MEDIUM':2,'HIGH':3,'UNDECLARED':0}
  if declared!='UNDECLARED' and rank.get(declared,0)<rank[level]: reasons.append(f'COMPLEXITY_UNDER_DECLARED:{declared}->{level}')
  if missing: reasons.append('RESPONSIBILITY_COUNTS_INSUFFICIENT')
  if chars<floor: reasons.append(f'READING_CORE_SHELL_RISK:{chars}<{floor}')
  if level=='HIGH' and len(dh)<7: reasons.append(f'ACTUAL_RESPONSIBILITY_SIGNAL_LOW:{len(dh)}<7')
  item={'path':path,'declared_complexity':declared,'recalculated_complexity':level,'responsibility_points':points,'chars':chars,'shell_floor':floor,'dimension_count':len(dh),'missing_profile_counts':missing,'reasons':reasons}
  rows.append(item)
  if reasons:bad.append(item)
 return rows,bad

def asset_check(root:Path,tmpls,profile):
 _,pa=profile_maps(profile); rows=[];bad=[];training_bad=[]
 for p in tmpls:
  path=rel(root,p); pr=pa.get(path,{}) if pa else {}
  level=str(pr.get('complexity') or complexity_from_name(p)).upper()
  if level not in {'HIGH','MEDIUM','LOW'}:level=complexity_from_name(p)
  s=t(p); dh=dim_hits(s); st=structure(s); chars=len(compact(s)); min_dims,min_chars,min_units=thresholds(level)
  declared_req=list(pr.get('required_dimensions',[]) or [])
  required=declared_req or list(DIMENSIONS)
  applicable=[d for d in required if d in DIMENSIONS]
  missing=[d for d in applicable if d not in dh]
  reasons=[]
  if not pr: reasons.append('MISSING_ASSET_ADEQUACY_PROFILE')
  if len(dh)<min_dims:reasons.append(f'FUNCTION_DIMENSIONS_LOW:{len(dh)}<{min_dims}')
  if chars<min_chars:reasons.append(f'ASSET_SHELL_RISK:{chars}<{min_chars}')
  if st['units']<min_units:reasons.append(f'STRUCTURE_UNITS_LOW:{st["units"]}<{min_units}')
  # If a profile says a dimension is required, absence is always a failure even if aggregate count passes.
  if declared_req and missing:reasons.append('DECLARED_REQUIRED_DIMENSIONS_MISSING:'+','.join(missing))
  # V5.4: presence is not adequacy. HIGH operator tools must declare a sufficiently rich
  # responsibility surface; otherwise a tiny subset can false-green against aggregate keyword hits.
  if level=='HIGH' and len(set(applicable))<7: reasons.append(f'PROFILE_REQUIRED_DIMENSIONS_UNDERDECLARED:{len(set(applicable))}<7')
  role_high=any(x in p.stem.lower() for x in ('opportunity','validation','decision','contract','acceptance','launch','deployment','baseline','plan','brief','机会','验证','决策','合同','验收','部署','上线','计划'))
  if level=='HIGH' and role_high:
   core={'decision_rule','validation_acceptance','failure_recovery','completion'}
   miss_core=sorted(core-set(applicable))
   if miss_core: reasons.append('HIGH_ROLE_CORE_DIMENSIONS_UNDECLARED:'+','.join(miss_core))
  training=bool(pr.get('training_instrument',False)) or any(x in p.name.lower() for x in ('workbook','practice','exercise','training','训练','练习'))
  fh=feedback_hits(s)
  treasons=[]
  if training and len(fh)<5:treasons.append(f'TRAINING_FEEDBACK_STRENGTH_LOW:{len(fh)}<5')
  if training and 'completion' not in dh: treasons.append('TRAINING_COMPLETION_CONDITION_MISSING')
  item={'path':path,'complexity':level,'chars':chars,'dimensions':sorted(dh),'dimension_count':len(dh),'structure':st,'training_instrument':training,'feedback_groups':sorted(fh),'reasons':reasons,'training_reasons':treasons}
  rows.append(item)
  if reasons:bad.append(item)
  if treasons:training_bad.append(item)
 return rows,bad,training_bad

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--profile');ap.add_argument('--json');a=ap.parse_args();root=Path(a.new)
 chs=chapters(root);tmpls=templates(root);pp,profile=load_profile(root,a.profile);blocks=[]
 if profile is None:blocks.append('ADEQUACY_CONTRACT_MISSING')
 elif isinstance(profile,dict) and profile.get('parse_error'):blocks.append('ADEQUACY_CONTRACT_PARSE_ERROR')
 crows,cbad=chapter_profile_check(root,chs,profile or {})
 arows,abad,tbad=asset_check(root,tmpls,profile or {})
 if cbad:blocks.append('COMPLEXITY_CALIBRATED_CHAPTER_DEPTH')
 if abad:blocks.append('PRACTICAL_ASSET_ADEQUACY')
 if tbad:blocks.append('TRAINING_INSTRUMENT_STRENGTH')
 report={'version':'V5.4_ADEQUACY_AUDIT','new':str(root),'profile':str(pp) if pp else None,'chapters':len(chs),'templates':len(tmpls),'chapter_adequacy':{'failed':len(cbad),'details':crows},'practical_asset_adequacy':{'failed':len(abad),'details':arows},'training_instrument_strength':{'failed':len(tbad),'details':tbad},'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
