#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

AXES=('READ','LEARN','TRAIN','DO')
BLIND_REQUIRED={'generation_contract','verifier','canonical'}

def load_json(path:Path):
    try:
        v=json.loads(path.read_text(encoding='utf-8'))
        return v if isinstance(v,dict) else None
    except Exception:
        return None

def nonempty(v):
    return isinstance(v,str) and bool(v.strip())

def all_pass(resp, required):
    return isinstance(resp,dict) and all(str(resp.get(k,'')).upper()=='PASS' for k in required)

def add(blocks, code):
    if code not in blocks: blocks.append(code)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--new',required=True)
    ap.add_argument('--contract')
    ap.add_argument('--proxy')
    ap.add_argument('--json')
    a=ap.parse_args()
    root=Path(a.new)
    cp=Path(a.contract) if a.contract else root/'evidence'/'reader_transfer_contract.json'
    pp=Path(a.proxy) if a.proxy else root/'evidence'/'reader_transfer_proxy.json'
    contract=load_json(cp); proxy=load_json(pp)
    blocks=[]; details=[]

    if not contract:
        add(blocks,'READER_TRANSFER_CONTRACT_MISSING_OR_INVALID'); contract={}
    if not proxy:
        add(blocks,'READER_TRANSFER_PROXY_MISSING_OR_INVALID'); proxy={}

    authority=contract.get('authority',{}) if isinstance(contract.get('authority'),dict) else {}
    if authority.get('proxy_layer')!='BLIND_READER_PROXY_ONLY' or authority.get('real_reader_derivation')!='FORBIDDEN' or authority.get('real_reader_evidence')!='NOT_RUN':
        add(blocks,'REAL_READER_AUTHORITY_BOUNDARY_INVALID')

    source=proxy.get('source',{}) if isinstance(proxy.get('source'),dict) else {}
    if source.get('kind')!='BLIND_READER_PROXY': add(blocks,'PROXY_SOURCE_INVALID')
    if source.get('fresh') is not True: add(blocks,'PROXY_NOT_FRESH')
    blind={str(x) for x in source.get('blind_to',[]) if str(x)}
    if not BLIND_REQUIRED.issubset(blind): add(blocks,'PROXY_NOT_BLIND')
    if source.get('real_reader') is not False: add(blocks,'PROXY_REAL_READER_AUTHORITY_COLLISION')
    if nonempty(str(contract.get('domain',''))) and proxy.get('domain')!=contract.get('domain'):
        add(blocks,'PROXY_DOMAIN_MISMATCH')

    tasks=[x for x in contract.get('tasks',[]) if isinstance(x,dict)]
    results=[x for x in proxy.get('results',[]) if isinstance(x,dict)]
    ridx={str(x.get('task_id','')):x for x in results if x.get('task_id')}
    declared_axes={str(x.get('axis','')).upper() for x in tasks}
    result_axes={str(x.get('axis','')).upper() for x in results}
    if not set(AXES).issubset(declared_axes) or not set(AXES).issubset(result_axes):
        add(blocks,'TRANSFER_TASK_COVERAGE_GAP')

    for task in tasks:
        tid=str(task.get('id','')); axis=str(task.get('axis','')).upper(); required=[str(x) for x in task.get('required_responsibilities',[]) if str(x)]
        res=ridx.get(tid)
        item={'task_id':tid,'axis':axis,'required_responsibilities':required,'failures':[]}
        if not res or str(res.get('axis','')).upper()!=axis:
            item['failures'].append('TASK_RESULT_MISSING_OR_AXIS_MISMATCH'); add(blocks,'TRANSFER_TASK_COVERAGE_GAP'); details.append(item); continue
        first=res.get('first_attempt',{}) if isinstance(res.get('first_attempt'),dict) else {}
        first_resp=first.get('responsibilities',{}) if isinstance(first.get('responsibilities'),dict) else {}

        if axis=='READ':
            if not nonempty(first.get('answer')) or not all_pass(first_resp,required):
                item['failures'].append('READ_REQUIRED_RESPONSIBILITY_NOT_TRANSFERRED'); add(blocks,'READ_RETRIEVAL_GAP')

        elif axis=='LEARN':
            if not nonempty(first.get('answer')) or not all_pass(first_resp,required):
                item['failures'].append('LEARN_CHANGED_CASE_TRANSFER_INCOMPLETE'); add(blocks,'LEARN_TRANSFER_GAP')
            nm=task.get('near_miss') if isinstance(task.get('near_miss'),dict) else None
            if nm:
                choice=str(res.get('near_miss_choice','')); correct=str(nm.get('correct_option','')); options=[str(x) for x in nm.get('options',[])]
                if not correct or correct not in options or choice!=correct:
                    item['failures'].append('NEAR_MISS_SELECTED_OR_RUBRIC_INVALID'); add(blocks,'NEAR_MISS_CONFUSION')

        elif axis=='TRAIN':
            if task.get('requires_retry_repair') is True:
                failed={k for k in required if str(first_resp.get(k,'')).upper()!='PASS'}
                fb=res.get('feedback',{}) if isinstance(res.get('feedback'),dict) else {}
                targets={str(x) for x in fb.get('target_responsibilities',[]) if str(x)}
                if not failed or not failed.issubset(targets) or not nonempty(fb.get('message')):
                    item['failures'].append('FEEDBACK_DOES_NOT_TARGET_FIRST_ATTEMPT_FAILURE'); add(blocks,'TRAIN_FEEDBACK_LOOP_MISSING')
                retry=res.get('retry',{}) if isinstance(res.get('retry'),dict) else {}
                retry_resp=retry.get('responsibilities',{}) if isinstance(retry.get('responsibilities'),dict) else {}
                changed={str(x) for x in retry.get('changed_responsibilities',[]) if str(x)}
                repaired=bool(failed) and all(str(retry_resp.get(k,'')).upper()=='PASS' for k in failed) and failed.issubset(changed)
                answer_changed=nonempty(retry.get('answer')) and str(retry.get('answer')).strip()!=str(first.get('answer','')).strip()
                final_complete=all_pass(retry_resp,required)
                if not repaired or not answer_changed or not final_complete:
                    item['failures'].append('RETRY_FAILED_TO_REPAIR_TARGET_RESPONSIBILITY'); add(blocks,'RETRY_DID_NOT_REPAIR_RESPONSIBILITY')
            elif not all_pass(first_resp,required):
                item['failures'].append('TRAIN_REQUIRED_RESPONSIBILITY_NOT_TRANSFERRED'); add(blocks,'TRAIN_FEEDBACK_LOOP_MISSING')

        elif axis=='DO':
            output=res.get('output',{}) if isinstance(res.get('output'),dict) else {}
            steps=[x for x in output.get('steps',[]) if nonempty(x)]
            acceptance=output.get('acceptance_results',{}) if isinstance(output.get('acceptance_results'),dict) else {}
            output_ok=all_pass(first_resp,required) and nonempty(output.get('artifact')) and len(steps)>=2 and bool(acceptance) and all(str(v).upper()=='PASS' for v in acceptance.values())
            if not output_ok:
                item['failures'].append('DO_OUTPUT_OR_ACCEPTANCE_NOT_ACTIONABLE'); add(blocks,'DO_OUTPUT_NOT_ACTIONABLE')
            if task.get('requires_operator_handoff') is True:
                h=res.get('handoff',{}) if isinstance(res.get('handoff'),dict) else {}; op1=h.get('operator1',{}) if isinstance(h.get('operator1'),dict) else {}; op2=h.get('operator2',{}) if isinstance(h.get('operator2'),dict) else {}
                op1_fields=('state_id','state','evidence','next_action','owner'); op2_fields=('received_state_id','received_evidence','next_action','result','acceptance')
                handoff_ok=all(nonempty(op1.get(k)) for k in op1_fields) and all(nonempty(op2.get(k)) for k in op2_fields)
                handoff_ok=handoff_ok and op1.get('state_id')==op2.get('received_state_id') and op1.get('next_action')==op2.get('next_action') and str(op2.get('acceptance','')).upper()=='PASS'
                if not handoff_ok:
                    item['failures'].append('SECOND_OPERATOR_CANNOT_RECONSTRUCT_AND_CONTINUE'); add(blocks,'OPERATOR_HANDOFF_NOT_SELF_SUFFICIENT')
        else:
            item['failures'].append('UNKNOWN_AXIS'); add(blocks,'TRANSFER_TASK_COVERAGE_GAP')
        details.append(item)

    report={
        'version':'V5.7_READER_TRANSFER_AUDIT_WIP',
        'contract':str(cp),
        'proxy':str(pp),
        'domain':contract.get('domain'),
        'axes_required':list(AXES),
        'details':details,
        'blocks':blocks,
        'proxy_result':'BLIND_READER_PROXY_PASS' if not blocks else 'BLIND_READER_PROXY_BLOCK',
        'real_reader_evidence':'NOT_RUN',
        'decision':'PASS' if not blocks else 'BLOCK'
    }
    text=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
    if a.json: Path(a.json).write_text(text,encoding='utf-8')
    print(text,end='')
    return 0 if not blocks else 1

if __name__=='__main__': raise SystemExit(main())
