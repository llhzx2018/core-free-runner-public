#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new);state_p=root/'evidence'/'canonical_evidence_state.json';req_p=root/'evidence'/'canonical_evidence_requirements.json';fails=[];details=[]
    state=read(state_p);req=read(req_p)
    if not state:fails.append({'reason':'CANONICAL_EVIDENCE_STATE_MISSING_OR_INVALID'});state={}
    if not req:fails.append({'reason':'CANONICAL_EVIDENCE_REQUIREMENTS_MISSING_OR_INVALID'});req={}
    entries=state.get('entries',{}) if isinstance(state,dict) else {}
    for gate in req.get('required_gates',[]) if isinstance(req,dict) else []:
        e=entries.get(gate)
        if not isinstance(e,dict):fails.append({'gate':gate,'reason':'PROMOTION_ENTRY_MISSING'});continue
        cp=Path(str(e.get('canonical_path','')));cp=cp if cp.is_absolute() else root/cp
        item={'gate':gate,'canonical_path':str(cp)}
        if not cp.exists():fails.append({'gate':gate,'reason':'CANONICAL_PATH_MISSING','path':str(cp)});details.append(item);continue
        obj=read(cp);actual=sha(cp);meta=obj.get('canonical_evidence',{}) if isinstance(obj,dict) else {}
        checks={
          'hash_match':actual==str(e.get('canonical_sha256','')),
          'run_id_match':str(meta.get('run_id',''))==str(e.get('run_id','')) and bool(str(e.get('run_id',''))),
          'timestamp_match':str(meta.get('promoted_at',''))==str(e.get('promoted_at','')) and bool(str(e.get('promoted_at',''))),
          'gate_match':str(meta.get('gate',''))==gate,
          'decision_pass':str(obj.get('decision','')).upper() in {'PASS','PASS_RUNTIME_ACCEPTANCE','PASS_REVIEW_NO_MACHINE_TRIGGER'} if isinstance(obj,dict) else False,
        };item.update({'actual_sha256':actual,'checks':checks});details.append(item)
        for k,v in checks.items():
            if not v:fails.append({'gate':gate,'reason':'CANONICAL_PROMOTION_'+k.upper()})
    blocks=['CANONICAL_EVIDENCE_PROMOTION_GAP'] if fails else []
    report={'version':'V5.4_CANONICAL_EVIDENCE_PROMOTION_AUDIT','required_gates':req.get('required_gates',[]) if isinstance(req,dict) else [],'details':details,'failures':fails,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
