#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path

CATEGORIES={
 'expected_output':('预期输出','expected output','目标产物'),
 'reference_judgment':('参考判断','参考答案','reference judgment','worked answer','答案解析'),
 'error_class':('为什么错','错误类型','常见错误','error class','common error','错误诊断'),
 'correction':('纠错','修正','correction','improved output'),
 'retry':('重试','retry','re-check'),
 'completion_condition':('完成条件','completion condition','quality bar')
}

def read_json(p:Path):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None

def locate(root,rel):
    p=root/str(rel);return p if p.is_file() else None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--stage',default='PRE_FREEZE',choices=['PRE_DRAFT','PRE_FREEZE']);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new)
    blocks=[];fails=[];details=[]
    adeq=read_json(root/'evidence'/'adequacy_contract.json');con=read_json(root/'evidence'/'training_feedback_contract.json')
    if not adeq:blocks.append('ADEQUACY_CONTRACT_MISSING_OR_INVALID');adeq={}
    if not con:blocks.append('TRAINING_FEEDBACK_CONTRACT_MISSING_OR_INVALID');con={}
    high=[x for x in adeq.get('chapters',[]) if isinstance(x,dict) and str(x.get('complexity','')).upper()=='HIGH']
    rows=con.get('chapters',[]) if isinstance(con,dict) else []
    idx={str(x.get('chapter_path','')):x for x in rows if isinstance(x,dict) and x.get('chapter_path')}
    for ch in high:
        rel=str(ch.get('path',''));row=idx.get(rel)
        if not row:
            fails.append({'chapter_path':rel,'reason':'HIGH_TRAINING_CHAPTER_UNMAPPED'});continue
        app=str(row.get('applicability','REQUIRED')).upper();item={'chapter_path':rel,'applicability':app,'signals':{}}
        if app!='REQUIRED':fails.append({'chapter_path':rel,'reason':'HIGH_TRAINING_CHAPTER_NOT_REQUIRED','value':app});details.append(item);continue
        loop=row.get('feedback_loop',{}) if isinstance(row.get('feedback_loop'),dict) else {}
        for key in CATEGORIES:
            if len(str(loop.get(key,'')).strip())<8:fails.append({'chapter_path':rel,'reason':f'{key.upper()}_DECLARATION_MISSING_OR_THIN'})
        assets=[str(x) for x in row.get('feedback_asset_paths',[]) if str(x).strip()];paths=[rel]+assets;item['feedback_asset_paths']=assets
        if a.stage=='PRE_FREEZE':
            texts=[]
            for pth in paths:
                p=locate(root,pth)
                if not p:fails.append({'chapter_path':rel,'path':pth,'reason':'FEEDBACK_PATH_MISSING'});continue
                texts.append(p.read_text(encoding='utf-8',errors='replace').lower())
            joined='\n'.join(texts)
            for key,signals in CATEGORIES.items():
                hit=[s for s in signals if s.lower() in joined];item['signals'][key]=hit
                if not hit:fails.append({'chapter_path':rel,'reason':f'READER_FACING_{key.upper()}_SIGNAL_MISSING'})
        details.append(item)
    if high and len(idx)<len(high):pass
    if fails:blocks.append('TRAINING_FEEDBACK_COVERAGE_GAP')
    report={'version':'V5.5_TRAINING_FEEDBACK_AUDIT','stage':a.stage,'high_training_chapters':len(high),'details':details,'failures':fails,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
