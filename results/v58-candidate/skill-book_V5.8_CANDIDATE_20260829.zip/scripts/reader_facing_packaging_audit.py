#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path

ENGINEERING_ONLY={'BOOK','WORKBOOK','TEMPLATES','AUDIT','EVIDENCE','MANIFEST'}

def has_cjk(s): return bool(re.search(r'[\u3400-\u9fff]',s))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--book-title',required=True);ap.add_argument('--language',required=True);ap.add_argument('--json');a=ap.parse_args()
    root=Path(a.new);blocks=[]
    entries=[p.name for p in root.iterdir()] if root.exists() else []
    files=[p for p in root.iterdir() if p.is_file()] if root.exists() else []
    title=a.book_title.strip();lang=a.language.lower()
    manuscript=[];reading=[];quick=[]
    for p in files:
        low=p.name.lower()
        if p.suffix.lower() in {'.md','.html','.pdf','.epub'} and ('正文' in p.name or 'manuscript' in low): manuscript.append(p.name)
        if p.suffix.lower() in {'.html','.pdf','.epub'} and ('阅读' in p.name or 'reading' in low): reading.append(p.name)
        if '快速' in p.name or 'quick' in low: quick.append(p.name)
    if not manuscript: blocks.append('OBVIOUS_MANUSCRIPT_ENTRY_MISSING')
    if lang.startswith('zh'):
        visible=[x for x in entries if not x.startswith('.') and not x.startswith('_')]
        localized=[x for x in visible if has_cjk(x)]
        if not localized: blocks.append('PRIMARY_LANGUAGE_FILENAME_MISMATCH')
        if manuscript and not any(has_cjk(x) for x in manuscript): blocks.append('MANUSCRIPT_FILENAME_NOT_LOCALIZED')
    upper_dirs=[x for x in entries if x.upper() in ENGINEERING_ONLY]
    if upper_dirs and not manuscript:
        blocks.append('ENGINEERING_STRUCTURE_IS_ONLY_READER_ROUTE')
    # Blind/evaluator simple physical separation check.
    blind=list(root.rglob('*BLIND*'))+list(root.rglob('*blind*'))
    evaluator=list(root.rglob('*EVALUATOR*'))+list(root.rglob('*evaluator*'))
    collisions=[]
    eval_names={p.resolve() for p in evaluator if p.exists()}
    for b in blind:
        if b.is_dir():
            for e in evaluator:
                try:
                    if e.resolve().is_relative_to(b.resolve()): collisions.append(str(e.relative_to(root)))
                except Exception: pass
    if collisions: blocks.append('BLIND_EVALUATOR_PHYSICAL_COLLISION')
    report={'version':'V5.8_READER_FACING_PACKAGING_AUDIT','book_title':title,'language':lang,'top_level_entries':entries,'manuscript_entries':manuscript,'reading_entries':reading,'quick_reference_entries':quick,'engineering_top_dirs':upper_dirs,'blind_evaluator_collisions':collisions,'decision':'BLOCK' if blocks else 'PASS','blocks':sorted(set(blocks))}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
