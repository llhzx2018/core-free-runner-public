#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
from freeze_integrity_audit import audit as freeze_integrity_audit

VALID={'REQUIRED_EXISTING_CANONICAL','NOT_APPLICABLE_NEW_BOOK'}

def read(p:Path):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None

def sha(p:Path):return hashlib.sha256(p.read_bytes()).hexdigest()

def truth(v):return v is True

def deferred_external_lane(root:Path):
    st=read(root/'evidence'/'runtime_authority_status.json')
    if not isinstance(st,dict):return False
    return (str(st.get('authority_mode','')).upper()=='EXTERNAL_VERIFIER_PENDING' and str(st.get('machine_execution_status','')).upper()=='NOT_RUN' and str(st.get('runtime_acceptance_claim','')).upper() in {'BLOCK_PENDING_EXTERNAL_VERIFIER','NOT_RUN','BLOCK'})

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--new',required=True)
    ap.add_argument('--stage',choices=['PRE_DRAFT','POST_FREEZE'],required=True)
    ap.add_argument('--old')
    ap.add_argument('--json')
    a=ap.parse_args();root=Path(a.new);blocks=[];checks={}
    cp=root/'evidence'/'baseline_applicability_contract.json';contract=read(cp) if cp.exists() else None
    if not isinstance(contract,dict):
        blocks.append('BASELINE_APPLICABILITY_CONTRACT_MISSING_OR_INVALID');contract={}
    app=str(contract.get('applicability','')).upper();stage=str(contract.get('declaration_stage','')).upper()
    book_id=str(contract.get('book_id','')).strip();title=str(contract.get('book_title','')).strip()
    checks.update({'contract_path':str(cp),'contract_sha256':sha(cp) if cp.exists() else None,'applicability':app or None,'declaration_stage':stage or None,'book_id':book_id or None,'book_title':title or None})
    if app not in VALID:blocks.append('BASELINE_APPLICABILITY_VALUE_INVALID')
    if stage!='PRE_DRAFT':blocks.append('BASELINE_APPLICABILITY_NOT_DECLARED_PRE_DRAFT')
    if not book_id or not title:blocks.append('BASELINE_BOOK_IDENTITY_MISSING')
    if not truth(contract.get('same_book_identity_required')):blocks.append('SAME_BOOK_IDENTITY_REQUIREMENT_MISSING')
    if not truth(contract.get('different_book_substitution_forbidden')):blocks.append('DIFFERENT_BOOK_SUBSTITUTION_GUARD_MISSING')
    if app=='NOT_APPLICABLE_NEW_BOOK' and not truth(contract.get('postfreeze_confirmation_required')):blocks.append('NEW_BOOK_POSTFREEZE_CONFIRMATION_NOT_REQUIRED')

    decision='BLOCK'
    post=None;freeze_integrity=None
    if a.stage=='PRE_DRAFT':
        decision='PASS' if not blocks else 'BLOCK'
    else:
        pre_p=root/'evidence'/'baseline_applicability_pre_draft.json';pre=read(pre_p) if pre_p.exists() else None
        deferred=deferred_external_lane(root);external_pre_replay=None
        if not isinstance(pre,dict):blocks.append('BASELINE_APPLICABILITY_PRE_DRAFT_EVIDENCE_MISSING_OR_INVALID')
        else:
            pre_dec=str(pre.get('decision','')).upper()
            if pre_dec!='PASS':
                if deferred and pre_dec=='NOT_RUN': external_pre_replay={'decision':'PASS','basis':'EXTERNAL_REAUDIT_OF_DECLARED_PRE_DRAFT_CONTRACT'}
                else: blocks.append('BASELINE_APPLICABILITY_PRE_DRAFT_NOT_PASS')
            if pre_dec=='PASS':
                meta=pre.get('canonical_evidence',{}) if isinstance(pre.get('canonical_evidence'),dict) else {}
                if str(meta.get('gate',''))!='BASELINE_APPLICABILITY_PRE_DRAFT':blocks.append('BASELINE_APPLICABILITY_PRE_DRAFT_NOT_CANONICAL_PROMOTED')
                if cp.exists() and str((pre.get('contract') or {}).get('contract_sha256',''))!=sha(cp):blocks.append('BASELINE_APPLICABILITY_PRE_DRAFT_CONTRACT_HASH_DRIFT')
        fp=root/'evidence'/'freeze_record.json';freeze=read(fp) if fp.exists() else None
        freeze_integrity=freeze_integrity_audit(root)
        if str(freeze_integrity.get('decision','')).upper()!='PASS_FREEZE_INTEGRITY':blocks.append('FREEZE_INTEGRITY_NOT_CLOSED')
        if not isinstance(freeze,dict):blocks.append('FREEZE_RECORD_MISSING_OR_INVALID')
        if app=='REQUIRED_EXISTING_CANONICAL':
            if not a.old:blocks.append('POST_DRAFT_BASELINE_DIFFERENTIAL_NOT_RUN')
            decision='PASS_REQUIRED_BASELINE' if not blocks else 'BLOCK'
        elif app=='NOT_APPLICABLE_NEW_BOOK':
            if a.old:blocks.append('NEW_BOOK_NA_CONTRADICTED_BY_CANONICAL_ARGUMENT')
            pp=root/'evidence'/'baseline_applicability_postfreeze.json';post=read(pp) if pp.exists() else None
            if not isinstance(post,dict):
                blocks.append('NEW_BOOK_POSTFREEZE_CONFIRMATION_MISSING_OR_INVALID');post={}
            else:
                if str(post.get('decision','')).upper()!='PASS_NOT_APPLICABLE_NEW_BOOK':blocks.append('NEW_BOOK_POSTFREEZE_DECISION_NOT_PASS')
                if str(post.get('applicability','')).upper()!=app:blocks.append('NEW_BOOK_POSTFREEZE_APPLICABILITY_MISMATCH')
                if str(post.get('book_id','')).strip()!=book_id or str(post.get('book_title','')).strip()!=title:blocks.append('NEW_BOOK_POSTFREEZE_BOOK_IDENTITY_MISMATCH')
                if not truth(post.get('searched_after_freeze')):blocks.append('NEW_BOOK_CANONICAL_SEARCH_NOT_AFTER_FREEZE')
                if post.get('matching_same_book_canonical_found') is not False:blocks.append('MATCHING_SAME_BOOK_CANONICAL_FOUND_OR_UNKNOWN')
                if post.get('different_book_substitution_used') is not False:blocks.append('DIFFERENT_BOOK_BASELINE_SUBSTITUTION_USED_OR_UNKNOWN')
                if post.get('frozen_candidate_modified_after_search') is not False:blocks.append('FROZEN_CANDIDATE_MODIFIED_AFTER_BASELINE_SEARCH_OR_UNKNOWN')
                if cp.exists() and str(post.get('pre_draft_contract_sha256',''))!=sha(cp):blocks.append('BASELINE_PRE_DRAFT_CONTRACT_HASH_MISMATCH')
                if fp.exists() and str(post.get('freeze_record_sha256',''))!=sha(fp):blocks.append('BASELINE_FREEZE_RECORD_HASH_MISMATCH')
            decision='PASS_NOT_APPLICABLE_NEW_BOOK' if not blocks else 'BLOCK'
    blocks=list(dict.fromkeys(blocks))
    report={'version':'V5.5_BASELINE_APPLICABILITY_AUDIT','stage':a.stage,'new':str(root),'old':a.old,'contract':checks,'postfreeze_confirmation':post,'external_pre_draft_replay':locals().get('external_pre_replay'),'freeze_integrity':freeze_integrity,'blocks':blocks,'decision':decision}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
