#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

VERSION='V5.4_FREEZE_INTEGRITY_AUDIT'
RECORD_VERSION='V5.4_FREEZE_RECORD'
DISCOVERY='V5.4_READER_SURFACE_V1'
READER_DIRS=(
 'manuscript','chapters','book/chapters','templates','frontmatter','appendices',
 'workbook','operator_reference','operator','examples','delivery','references','reader'
)
ROOT_PATTERNS=(
 re.compile(r'^BOOK(?:\..+)?$',re.I),re.compile(r'^WORKBOOK(?:\..+)?$',re.I),
 re.compile(r'^REFERENCES(?:\..+)?$',re.I),re.compile(r'^README(?:\..+)?$',re.I),
 re.compile(r'^TOC(?:\..+)?$',re.I),re.compile(r'^START_HERE(?:\..+)?$',re.I),
 re.compile(r'^00[_ .-].+',re.I),
)
EXCLUDED_PARTS={'.git','evidence','governance','research','audit','audits','scripts','tests','node_modules','__pycache__','.pytest_cache','packages','package'}

def hbytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def hfile(p:Path)->str:return hbytes(p.read_bytes())
def read_json(p:Path):
 try:return json.loads(p.read_text(encoding='utf-8'))
 except Exception:return None

def safe_rel(rel:str)->bool:
 p=Path(rel)
 return bool(rel) and not p.is_absolute() and '..' not in p.parts and not any(part in EXCLUDED_PARTS for part in p.parts)

def discover_reader_assets(root:Path):
 out=set()
 for rel in READER_DIRS:
  d=root/rel
  if d.is_dir():
   for p in d.rglob('*'):
    if p.is_file() and not any(part in EXCLUDED_PARTS for part in p.relative_to(root).parts):out.add(p)
 for p in root.iterdir() if root.exists() else []:
  if p.is_file() and any(rx.match(p.name) for rx in ROOT_PATTERNS):out.add(p)
 return sorted(out,key=lambda p:p.relative_to(root).as_posix())

def asset_rows(root:Path):
 rows=[]
 for p in discover_reader_assets(root):
  b=p.read_bytes();rows.append({'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hbytes(b)})
 return rows

def tree_hash(rows):
 payload=''.join(f"{r['path']}\t{r['bytes']}\t{r['sha256']}\n" for r in sorted(rows,key=lambda x:x['path'])).encode()
 return hbytes(payload)

def infer_identity(root:Path):
 for name in ('evidence/baseline_applicability_contract.json','MANIFEST.json','manifest.json','evidence/reader_transformation_contract.json'):
  d=read_json(root/name)
  if not isinstance(d,dict):continue
  bid=str(d.get('book_id') or d.get('BOOK_ID') or '').strip();title=str(d.get('book_title') or d.get('BOOK_TITLE') or d.get('title') or '').strip()
  if bid or title:return bid,title
 return '',''

def build_record(root:Path,book_id:str='',book_title:str='',created_at:str=''):
 from datetime import datetime,timezone
 rows=asset_rows(root);bid,title=infer_identity(root);book_id=book_id or bid;book_title=book_title or title
 state=root/'evidence'/'canonical_evidence_state.json'
 return {
  'version':RECORD_VERSION,'stage':'FIRST_FREEZE','decision':'FROZEN','created_at':created_at or datetime.now(timezone.utc).isoformat(),
  'book_id':book_id,'book_title':book_title,'discovery_contract':DISCOVERY,
  'reader_assets':rows,'reader_asset_count':len(rows),'reader_tree_sha256':tree_hash(rows),
  'canonical_evidence_state_sha256':hfile(state) if state.is_file() else None,
 }

def audit(root:Path):
 blocks=[];rp=root/'evidence'/'freeze_record.json';r=read_json(rp) if rp.exists() else None
 if not isinstance(r,dict):blocks.append('FREEZE_RECORD_MISSING_OR_INVALID');r={}
 if str(r.get('version',''))!=RECORD_VERSION:blocks.append('FREEZE_RECORD_VERSION_INVALID')
 if str(r.get('stage','')).upper()!='FIRST_FREEZE':blocks.append('FREEZE_RECORD_STAGE_INVALID')
 if str(r.get('decision','')).upper()!='FROZEN':blocks.append('FREEZE_RECORD_DECISION_INVALID')
 if str(r.get('discovery_contract',''))!=DISCOVERY:blocks.append('FREEZE_DISCOVERY_CONTRACT_INVALID')
 if not str(r.get('book_id','')).strip() or not str(r.get('book_title','')).strip():blocks.append('FREEZE_BOOK_IDENTITY_MISSING')
 if not str(r.get('created_at','')).strip():blocks.append('FREEZE_TIMESTAMP_MISSING')
 stored=r.get('reader_assets') if isinstance(r.get('reader_assets'),list) else []
 if not stored:blocks.append('FREEZE_READER_ASSET_LIST_EMPTY')
 paths=[]
 for x in stored:
  if not isinstance(x,dict):blocks.append('FREEZE_READER_ASSET_ROW_INVALID');continue
  rel=str(x.get('path',''))
  if not safe_rel(rel):blocks.append('FREEZE_READER_ASSET_PATH_UNSAFE')
  paths.append(rel)
 if len(paths)!=len(set(paths)):blocks.append('FREEZE_READER_ASSET_DUPLICATE_PATH')
 current=asset_rows(root);sm={x.get('path'):x for x in stored if isinstance(x,dict)};cm={x['path']:x for x in current}
 missing=sorted(set(sm)-set(cm));added=sorted(set(cm)-set(sm));changed=[]
 if missing:blocks.append('FROZEN_READER_ASSET_MISSING')
 if added:blocks.append('READER_ASSET_ADDED_AFTER_FREEZE')
 for rel in sorted(set(sm)&set(cm)):
  s,c=sm[rel],cm[rel]
  try:sb=int(s.get('bytes'))
  except Exception:sb=-1
  if sb!=c['bytes'] or str(s.get('sha256',''))!=c['sha256']:changed.append(rel)
 if changed:blocks.append('FROZEN_READER_ASSET_HASH_DRIFT')
 try:count=int(r.get('reader_asset_count'))
 except Exception:count=-1
 if count!=len(stored) or count!=len(current):blocks.append('FREEZE_READER_ASSET_COUNT_MISMATCH')
 current_tree=tree_hash(current)
 if str(r.get('reader_tree_sha256',''))!=current_tree:blocks.append('FREEZE_READER_TREE_HASH_MISMATCH')
 state=root/'evidence'/'canonical_evidence_state.json';state_hash=str(r.get('canonical_evidence_state_sha256') or '')
 if not state.is_file() or len(state_hash)!=64:blocks.append('FREEZE_CANONICAL_EVIDENCE_STATE_MISSING')
 elif state_hash!=hfile(state):blocks.append('FREEZE_CANONICAL_EVIDENCE_STATE_HASH_DRIFT')
 blocks=list(dict.fromkeys(blocks))
 return {'version':VERSION,'new':str(root),'freeze_record':str(rp),'reader_asset_count_current':len(current),'reader_tree_sha256_current':current_tree,'missing_assets':missing,'added_assets':added,'changed_assets':changed,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS_FREEZE_INTEGRITY'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--json');a=ap.parse_args();report=audit(Path(a.new))
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if report['blocks'] else 0
if __name__=='__main__':raise SystemExit(main())
