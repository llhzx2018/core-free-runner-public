#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ADEQ=ROOT/'adequacy_audit.py'
DEPTH=ROOT/'practical_asset_depth_audit.py'
TRANSFER=ROOT/'reader_transfer_audit.py'
BASE=ROOT/'postdraft_baseline_audit.py'
RESP=ROOT/'generation_responsibility_audit.py'
PREF=ROOT/'prefreeze_random_open_audit.py'
OPER=ROOT/'operational_closure_audit.py'
TRAIN=ROOT/'training_feedback_audit.py'
SHADOW=ROOT/'shadow_local_value_audit.py'
STRICT=ROOT/'strict_holdout_receipt_audit.py'
POSTHOLD=ROOT/'postfreeze_holdout_audit.py'
PROMO=ROOT/'canonical_evidence_promotion_audit.py'
BASEAPP=ROOT/'baseline_applicability_audit.py'
FREEZE=ROOT/'freeze_integrity_audit.py'
AUTH=ROOT/'runtime_authority_fidelity_audit.py'
SUBSTANCE=ROOT/'full_book_substance_audit.py'
CONTREAD=ROOT/'continuous_reading_audit.py'
PACKAGING=ROOT/'reader_facing_packaging_audit.py'
RUNTIME_CONTRACT_ID='SB58-RUNTIME-CONTRACT-BF41D2E7'
EXPECTED_SKILL_VERSION='5.8'
REQUIRED_RECEIPT_EVIDENCE=(
 'evidence/reader_transformation_contract.json','evidence/baseline_applicability_pre_draft.json',
 'evidence/full_book_substance_contract.json','evidence/full_book_substance_audit.json','evidence/continuous_reading_audit.json',
 'evidence/training_feedback_pre_freeze.json','evidence/operational_closure_pre_freeze.json','evidence/reader_facing_packaging_audit.json',
 'evidence/freeze_record.json','evidence/freeze_integrity_audit.json','evidence/reader_transfer_contract.json',
 'evidence/runtime_authority_status.json','evidence/runtime_acceptance_audit.json')

def read_json(p:Path):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None
def norm_key(k): return re.sub(r'[^a-z0-9]+','',str(k).lower())
def mget(obj,*keys,default=None):
    if not isinstance(obj,dict): return default
    idx={norm_key(k):v for k,v in obj.items()}
    for key in keys:
        nk=norm_key(key)
        if nk in idx:return idx[nk]
    return default
def find_manifest(root:Path):
    for name in ('MANIFEST.json','01_MANIFEST.json','manifest.json'):
        p=root/name
        if p.exists(): return p,read_json(p)
    hits=list(root.glob('*MANIFEST*.json'))
    return (hits[0],read_json(hits[0])) if hits else (None,None)
def run_json(cmd:list[str], out:Path):
    cp=subprocess.run(cmd,capture_output=True,text=True);data=read_json(out) if out.exists() else None;return cp,data
def chapter_id(p:Path):
    for pat in (r'^0*(\d{1,3})$',r'^0*(\d{1,3})[_ .-]',r'^chapter[_ .-]*0*(\d{1,3})\b',r'第\s*0*(\d{1,3})\s*章'):
        m=re.search(pat,p.stem,re.I)
        if m:return int(m.group(1))
    return None
def chapter_paths(root:Path):
    out=[]
    for d in (root/'manuscript',root/'chapters',root/'book'/'chapters',root/'BOOK'/'chapters'):
        if d.exists(): out += sorted(p for p in d.glob('*.md') if chapter_id(p))
    return sorted(set(out),key=lambda p:(chapter_id(p) or 999,p.as_posix()))
def local_value(chunk:str):
    s=re.sub(r'\s+',' ',chunk).strip(); reasons=[]
    if len(s)<180: reasons.append('TOO_THIN')
    cues=('判断','规则','条件','输入','输出','验证','失败','恢复','步骤','完成','决策','决定','选择','信号','状态','证据','提交','请求','检查','观察','基线','样本','定义','使用','诊断','监控','例子','示例','check','test','if','when','decide','choose','signal','status','evidence','submit','request','inspect','observe','baseline','sample','definition','use','diagnose','monitor')
    if sum(1 for x in cues if x.lower() in s.lower())<2: reasons.append('LOW_ACTION_DECISION_CUES')
    return not reasons,reasons

def _bounded_chapter(parts,idx,target=320,max_parts=3):
    if not parts:return ''
    chosen=[idx];step=1
    while len(chosen)<max_parts and len(re.sub(r'\s+','', '\n\n'.join(parts[i] for i in sorted(chosen))))<target:
        cand=[]
        if idx-step>=0:cand.append(idx-step)
        if idx+step<len(parts):cand.append(idx+step)
        if not cand:break
        for j in cand:
            if j not in chosen and len(chosen)<max_parts:chosen.append(j)
        step+=1
    return '\n\n'.join(parts[i] for i in sorted(chosen))

def holdout(root:Path):
    import random
    paths=chapter_paths(root); rows=[]
    if not paths:return rows
    for seed in range(49901,49913):
        r=random.Random(seed); p=r.choice(paths);sections=[];cur=None
        for line in p.read_text(encoding='utf-8',errors='replace').splitlines():
            if re.match(r'^##\s+',line):
                if cur: sections.append('\n'.join(cur))
                cur=[line]
            elif cur is not None: cur.append(line)
        if cur: sections.append('\n'.join(cur))
        sections=[x for x in sections if x.strip()]
        if not sections:
            rows.append({'seed':seed,'path':p.relative_to(root).as_posix(),'chars':0,'result':'FAIL','reasons':['NO_H2_SECTION']});continue
        idx=r.randrange(len(sections));sec=_bounded_chapter(sections,idx,320,3);ok,why=local_value(sec)
        rows.append({'seed':seed,'path':p.relative_to(root).as_posix(),'window_index':idx,'bounded_parts_max':3,'chars':len(re.sub(r'\s+','',sec)),'result':'PASS' if ok else 'FAIL','reasons':why})
    return rows

def real_reader_status(root:Path,manifest:dict):
    val=str(mget(manifest,'REAL_READER_EVIDENCE','real_reader_evidence_status',default='') or '').upper()
    candidates=[root/'evidence'/'real_reader_evidence.json',root/'evidence'/'REAL_READER_EVIDENCE.json'];ep=None;evidence=None
    for p in candidates:
        if p.exists():ep=p;evidence=read_json(p);break
    if val in ('','NOT_RUN','NONE','NOTVERIFIED'):return True,{'status':val or 'NOT_RUN','evidence':None}
    source=str(mget(evidence or {},'source_type',default='') or '').upper();ok=bool(evidence) and 'REAL_READER' in source
    return ok,{'status':val,'evidence':str(ep) if ep else None,'source_type':source or None}
def deferred_external_lane(root:Path):
    st=read_json(root/'evidence'/'runtime_authority_status.json')
    if not isinstance(st,dict):return False
    return str(mget(st,'authority_mode',default='') or '').upper()=='EXTERNAL_VERIFIER_PENDING' and str(mget(st,'machine_execution_status',default='') or '').upper()=='NOT_RUN' and str(mget(st,'runtime_acceptance_claim',default='') or '').upper() in {'BLOCK_PENDING_EXTERNAL_VERIFIER','NOT_RUN','BLOCK'}

def validate_receipt(root:Path,sealed=False):
    p=root/'evidence'/'runtime_entry_receipt.json'
    if not p.exists():return False,{'status':'MISSING','path':str(p)},[]
    data=read_json(p)
    if not isinstance(data,dict):return False,{'status':'INVALID_JSON','path':str(p)},[]
    cid=str(mget(data,'runtime_contract_id',default='') or '');name=str(mget(data,'skill_name',default='') or '');ver=str(mget(data,'declared_skill_version','skill_version',default='') or '');stage=str(mget(data,'entry_stage',default='') or '').upper();mandatory=mget(data,'mandatory_evidence',default=[])
    source=str(mget(data,'runtime_contract_id_source',default='') or '').upper();exposed=mget(data,'benchmark_prompt_contract_id_exposed',default=None);canary=str(mget(data,'benchmark_canary_applicability',default='') or '').upper();warn=[]
    base=(cid==RUNTIME_CONTRACT_ID and name=='skill-book' and ver==EXPECTED_SKILL_VERSION and stage in {'PRE_DRAFT','BEFORE_DRAFT','RUNTIME_ENTRY'} and isinstance(mandatory,list) and set(REQUIRED_RECEIPT_EVIDENCE).issubset(set(str(x) for x in mandatory)))
    canary_ok=True
    if sealed:
        if canary=='REQUIRED': canary_ok=(source=='SKILL_INTERNAL' and exposed is False)
        elif canary=='CONTAMINATED_HISTORICAL_INPUT':
            canary_ok=source in {'EXTERNAL_REPLAY_FROM_PRIOR_VERSION','SKILL_INTERNAL'};warn.append('BENCHMARK_CANARY_CONTAMINATED_NO_RUNTIME_IDENTITY_CLAIM')
        else: canary_ok=False
    elif canary and canary not in {'REQUIRED','NOT_APPLICABLE_NON_BENCHMARK','CONTAMINATED_HISTORICAL_INPUT'}:canary_ok=False
    ok=base and canary_ok
    return ok,{'status':'PASS' if ok else 'INVALID','path':str(p),'runtime_contract_id':cid or None,'skill_name':name or None,'declared_skill_version':ver or None,'entry_stage':stage or None,'runtime_contract_id_source':source or None,'benchmark_prompt_contract_id_exposed':exposed,'benchmark_canary_applicability':canary or None},warn

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--old');ap.add_argument('--json');a=ap.parse_args();root=Path(a.new); blocks=[]; warnings=[]
    mp,manifest=find_manifest(root)
    if not manifest: blocks.append('MANIFEST_MISSING_OR_INVALID'); manifest={}
    mode=str(mget(manifest,'TEST_MODE','GENERATION_MODE','test_mode','generation_mode',default='') or '').upper();final=str(mget(manifest,'FINAL_DECISION','final_decision',default='') or '').upper()
    sealed=('SEALED_STANDALONE' in mode);deferred=deferred_external_lane(root)
    receipt_ok,receipt,receipt_warnings=validate_receipt(root,sealed=sealed);warnings.extend(receipt_warnings)
    if not receipt_ok: blocks.append('RUNTIME_ENTRY_RECEIPT_MISSING' if receipt.get('status')=='MISSING' else 'RUNTIME_ENTRY_RECEIPT_INVALID')
    contract=root/'evidence'/'adequacy_contract.json'
    if not contract.exists(): blocks.append('ADEQUACY_CONTRACT_EVIDENCE_MISSING')
    declared_adequacy=root/'evidence'/'adequacy_audit.json'
    if not declared_adequacy.exists(): blocks.append('ADEQUACY_AUDIT_EVIDENCE_MISSING')
    depth_contract=root/'evidence'/'practical_asset_depth_contract.json'
    if not depth_contract.exists(): blocks.append('PRACTICAL_ASSET_DEPTH_CONTRACT_EVIDENCE_MISSING')
    declared_depth=root/'evidence'/'practical_asset_depth_audit.json'
    if not declared_depth.exists(): blocks.append('PRACTICAL_ASSET_DEPTH_AUDIT_EVIDENCE_MISSING')
    transfer_contract=root/'evidence'/'reader_transfer_contract.json'
    transfer_proxy=root/'evidence'/'reader_transfer_proxy.json'
    declared_transfer=root/'evidence'/'reader_transfer_audit.json'
    if not transfer_contract.exists(): blocks.append('READER_TRANSFER_CONTRACT_EVIDENCE_MISSING')
    if not transfer_proxy.exists(): blocks.append('READER_TRANSFER_PROXY_EVIDENCE_MISSING')
    if not declared_transfer.exists(): blocks.append('READER_TRANSFER_AUDIT_EVIDENCE_MISSING')
    reader_contract=root/'evidence'/'reader_transformation_contract.json'
    responsibility_contract=root/'evidence'/'generation_responsibility_contract.json'
    responsibility_pre=root/'evidence'/'generation_responsibility_pre_draft.json'
    responsibility_freeze=root/'evidence'/'generation_responsibility_pre_freeze.json'
    operational_contract=root/'evidence'/'operational_closure_contract.json'
    operational_pre=root/'evidence'/'operational_closure_pre_draft.json'
    operational_freeze=root/'evidence'/'operational_closure_pre_freeze.json'
    training_contract=root/'evidence'/'training_feedback_contract.json'
    training_freeze=root/'evidence'/'training_feedback_pre_freeze.json'
    prefreeze_initial=root/'evidence'/'prefreeze_random_open.json'
    shadow_local=root/'evidence'/'shadow_local_value.json'
    strict_receipt=root/'evidence'/'strict_unseen_holdout_receipt.json'
    postfreeze_holdout=root/'evidence'/'postfreeze_local_holdout.json'
    canonical_state=root/'evidence'/'canonical_evidence_state.json'
    canonical_requirements=root/'evidence'/'canonical_evidence_requirements.json'
    baseline_contract=root/'evidence'/'baseline_applicability_contract.json'
    baseline_pre=root/'evidence'/'baseline_applicability_pre_draft.json'
    freeze_integrity_report=root/'evidence'/'freeze_integrity_audit.json'
    runtime_authority_status=root/'evidence'/'runtime_authority_status.json'
    if not runtime_authority_status.exists(): blocks.append('RUNTIME_AUTHORITY_STATUS_EVIDENCE_MISSING')
    substance_contract=root/'evidence'/'full_book_substance_contract.json'
    substance_audit=root/'evidence'/'full_book_substance_audit.json'
    continuous_audit=root/'evidence'/'continuous_reading_audit.json'
    packaging_audit=root/'evidence'/'reader_facing_packaging_audit.json'
    for path,block in ((substance_contract,'FULL_BOOK_SUBSTANCE_CONTRACT_EVIDENCE_MISSING'),(substance_audit,'FULL_BOOK_SUBSTANCE_AUDIT_EVIDENCE_MISSING'),(continuous_audit,'CONTINUOUS_READING_AUDIT_EVIDENCE_MISSING'),(packaging_audit,'READER_FACING_PACKAGING_AUDIT_EVIDENCE_MISSING')):
        if not path.exists(): blocks.append(block)
    required=((reader_contract,'READER_TRANSFORMATION_MACHINE_CONTRACT_MISSING'),(responsibility_contract,'GENERATION_RESPONSIBILITY_CONTRACT_EVIDENCE_MISSING'),(responsibility_pre,'GENERATION_RESPONSIBILITY_PRE_DRAFT_EVIDENCE_MISSING'),(responsibility_freeze,'GENERATION_RESPONSIBILITY_PRE_FREEZE_EVIDENCE_MISSING'),(operational_contract,'OPERATIONAL_CLOSURE_CONTRACT_EVIDENCE_MISSING'),(operational_pre,'OPERATIONAL_CLOSURE_PRE_DRAFT_EVIDENCE_MISSING'),(operational_freeze,'OPERATIONAL_CLOSURE_PRE_FREEZE_EVIDENCE_MISSING'),(training_contract,'TRAINING_FEEDBACK_CONTRACT_EVIDENCE_MISSING'),(training_freeze,'TRAINING_FEEDBACK_PRE_FREEZE_EVIDENCE_MISSING'),(prefreeze_initial,'PREFREEZE_RANDOM_OPEN_EVIDENCE_MISSING'),(shadow_local,'SHADOW_LOCAL_VALUE_EVIDENCE_MISSING'),(canonical_state,'CANONICAL_EVIDENCE_STATE_MISSING'),(canonical_requirements,'CANONICAL_EVIDENCE_REQUIREMENTS_MISSING'))
    for path,block in required:
        if not path.exists(): blocks.append(block)
    if 'SEALED_STANDALONE' in mode:
        for path,block in ((baseline_contract,'BASELINE_APPLICABILITY_CONTRACT_EVIDENCE_MISSING'),(baseline_pre,'BASELINE_APPLICABILITY_PRE_DRAFT_EVIDENCE_MISSING'),(freeze_integrity_report,'FREEZE_INTEGRITY_EVIDENCE_MISSING')):
            if not path.exists(): blocks.append(block)
    declared_runtime=root/'evidence'/'runtime_acceptance_audit.json';output_is_declared=False
    if a.json:
        try: output_is_declared=Path(a.json).resolve()==declared_runtime.resolve()
        except Exception: output_is_declared=False
    if not declared_runtime.exists() and not output_is_declared: blocks.append('RUNTIME_ACCEPTANCE_EVIDENCE_MISSING')
    with tempfile.TemporaryDirectory() as td:
        au=Path(td)/'runtime_authority_fidelity.json';cpa,ausp=run_json([sys.executable,str(AUTH),'--new',str(root),'--json',str(au)],au)
        if cpa.returncode!=0 or not ausp or ausp.get('decision')!='PASS': blocks.append('RUNTIME_AUTHORITY_FIDELITY_BLOCK')
        fbo=Path(td)/'full_book_substance.json'
        if substance_audit.exists():
            cpfb,fbr=run_json([sys.executable,str(SUBSTANCE),'--new',str(root),'--audit',str(substance_audit),'--json',str(fbo)],fbo)
            if cpfb.returncode!=0 or not fbr or fbr.get('decision')!='PASS': blocks.append('FULL_BOOK_SUBSTANCE_EXTERNAL_REAUDIT_BLOCK')
        cro=Path(td)/'continuous_reading.json'
        if continuous_audit.exists():
            cpcr,crr=run_json([sys.executable,str(CONTREAD),'--audit',str(continuous_audit),'--json',str(cro)],cro)
            if cpcr.returncode!=0 or not crr or crr.get('decision')!='PASS': blocks.append('CONTINUOUS_READING_EXTERNAL_REAUDIT_BLOCK')
        pko=Path(td)/'reader_facing_packaging.json'
        if packaging_audit.exists():
            pk=read_json(packaging_audit) or {}
            title=str(pk.get('book_title') or mget(manifest,'BOOK_TITLE','book_title',default='') or '')
            lang=str(pk.get('language') or mget(manifest,'LANGUAGE','language',default='') or '')
            if not title or not lang:
                blocks.append('READER_FACING_PACKAGING_IDENTITY_MISSING')
            else:
                cppk,pkr=run_json([sys.executable,str(PACKAGING),'--new',str(root),'--book-title',title,'--language',lang,'--json',str(pko)],pko)
                if cppk.returncode!=0 or not pkr or pkr.get('decision')!='PASS': blocks.append('READER_FACING_PACKAGING_EXTERNAL_REAUDIT_BLOCK')
        ao=Path(td)/'adequacy.json';cp,ar=run_json([sys.executable,str(ADEQ),'--new',str(root),'--json',str(ao)],ao)
        if cp.returncode!=0 or not ar or ar.get('decision')!='PASS': blocks.append('ADEQUACY_EXTERNAL_REAUDIT_BLOCK')
        deptho=Path(td)/'practical_asset_depth.json';cpd,drsp=run_json([sys.executable,str(DEPTH),'--new',str(root),'--json',str(deptho)],deptho)
        if cpd.returncode!=0 or not drsp or drsp.get('decision')!='PASS': blocks.append('PRACTICAL_ASSET_DEPTH_EXTERNAL_REAUDIT_BLOCK')
        tro=Path(td)/'reader_transfer.json';cpt,trsp=run_json([sys.executable,str(TRANSFER),'--new',str(root),'--json',str(tro)],tro)
        if cpt.returncode!=0 or not trsp or trsp.get('decision')!='PASS' or trsp.get('real_reader_evidence')!='NOT_RUN': blocks.append('READER_TRANSFER_EXTERNAL_REAUDIT_BLOCK')
        ro=Path(td)/'responsibility.json';cpr,rrsp=run_json([sys.executable,str(RESP),'--new',str(root),'--stage','PRE_FREEZE','--json',str(ro)],ro)
        if cpr.returncode!=0 or not rrsp or rrsp.get('decision')!='PASS': blocks.append('GENERATION_RESPONSIBILITY_EXTERNAL_REAUDIT_BLOCK')
        pro=Path(td)/'prefreeze_random.json';cppref,prefsp=run_json([sys.executable,str(PREF),'--new',str(root),'--phase','GENERATION','--json',str(pro)],pro)
        if cppref.returncode!=0 or not prefsp or prefsp.get('decision')!='PASS': blocks.append('PREFREEZE_RANDOM_OPEN_EXTERNAL_REAUDIT_BLOCK')
        oo=Path(td)/'operational.json';cpo,orsp=run_json([sys.executable,str(OPER),'--new',str(root),'--stage','PRE_FREEZE','--json',str(oo)],oo)
        if cpo.returncode!=0 or not orsp or orsp.get('decision')!='PASS': blocks.append('OPERATIONAL_CLOSURE_EXTERNAL_REAUDIT_BLOCK')
        to=Path(td)/'training.json';cpt,trsp=run_json([sys.executable,str(TRAIN),'--new',str(root),'--stage','PRE_FREEZE','--json',str(to)],to)
        if cpt.returncode!=0 or not trsp or trsp.get('decision')!='PASS': blocks.append('TRAINING_FEEDBACK_EXTERNAL_REAUDIT_BLOCK')
        so=Path(td)/'shadow.json';cps,shsp=run_json([sys.executable,str(SHADOW),'--new',str(root),'--json',str(so)],so)
        if cps.returncode!=0 or not shsp or shsp.get('decision')!='PASS': blocks.append('SHADOW_LOCAL_VALUE_EXTERNAL_REAUDIT_BLOCK')
        st=Path(td)/'strict.json';cpst,stsp=run_json([sys.executable,str(STRICT),'--receipt',str(strict_receipt),'--json',str(st)],st) if strict_receipt.exists() else (None,None)
        strict_ok=bool(cpst is not None and cpst.returncode==0 and isinstance(stsp,dict) and stsp.get('decision')=='PASS')
        if strict_receipt.exists() and not strict_ok: warnings.append('STRICT_UNSEEN_HOLDOUT_PRESENT_BUT_INVALID')
        pr=Path(td)/'promotion.json';cppm,pmsp=run_json([sys.executable,str(PROMO),'--new',str(root),'--json',str(pr)],pr)
        if deferred:
            warnings.append('GENERATOR_CANONICAL_PROMOTION_DEFERRED_EXTERNAL_REAUDITS_AUTHORITATIVE')
        elif cppm.returncode!=0 or not pmsp or pmsp.get('decision')!='PASS': blocks.append('CANONICAL_EVIDENCE_PROMOTION_NOT_CLOSED')
        for path,block in ((responsibility_pre,'GENERATION_RESPONSIBILITY_PRE_DRAFT_NOT_PASS'),(responsibility_freeze,'GENERATION_RESPONSIBILITY_PRE_FREEZE_NOT_PASS'),(operational_pre,'OPERATIONAL_CLOSURE_PRE_DRAFT_NOT_PASS'),(operational_freeze,'OPERATIONAL_CLOSURE_PRE_FREEZE_NOT_PASS'),(training_freeze,'TRAINING_FEEDBACK_PRE_FREEZE_NOT_PASS'),(prefreeze_initial,'PREFREEZE_RANDOM_OPEN_NOT_PASS'),(shadow_local,'SHADOW_LOCAL_VALUE_NOT_PASS')):
            data=read_json(path) if path.exists() else None
            if path.exists():
                dec=str(data.get('decision','')).upper() if isinstance(data,dict) else ''
                if dec!='PASS':
                    if deferred and dec in {'NOT_RUN','BLOCK_PENDING_EXTERNAL_VERIFIER'}: warnings.append(block+'_DEFERRED_TO_EXTERNAL_REAUDIT')
                    else: blocks.append(block)
        br=None;bar=None;fisp=None
        if 'SEALED_STANDALONE' in mode:
            fio=Path(td)/'freeze_integrity.json';cpfi,fisp=run_json([sys.executable,str(FREEZE),'--new',str(root),'--json',str(fio)],fio)
            canon_fi=read_json(freeze_integrity_report) if freeze_integrity_report.exists() else None
            if cpfi.returncode!=0 or not isinstance(fisp,dict) or str(fisp.get('decision','')).upper()!='PASS_FREEZE_INTEGRITY': blocks.append('FREEZE_INTEGRITY_NOT_CLOSED')
            if freeze_integrity_report.exists() and (not isinstance(canon_fi,dict) or str(canon_fi.get('decision','')).upper()!='PASS_FREEZE_INTEGRITY'):
                if deferred and isinstance(canon_fi,dict) and str(canon_fi.get('decision','')).upper()=='NOT_RUN': warnings.append('FREEZE_INTEGRITY_CANONICAL_EVIDENCE_DEFERRED_TO_EXTERNAL_REAUDIT')
                else: blocks.append('FREEZE_INTEGRITY_CANONICAL_EVIDENCE_NOT_PASS')
            pho=Path(td)/'postfreeze_holdout.json';cpph,phsp=run_json([sys.executable,str(POSTHOLD),'--new',str(root),'--json',str(pho)],pho)
            canon_ph=read_json(postfreeze_holdout) if postfreeze_holdout.exists() else None
            if not postfreeze_holdout.exists(): blocks.append('POSTFREEZE_LOCAL_HOLDOUT_EVIDENCE_MISSING')
            if cpph.returncode!=0 or not isinstance(phsp,dict) or str(phsp.get('decision','')).upper()!='PASS_LOCAL_POSTFREEZE_HOLDOUT': blocks.append('POSTFREEZE_LOCAL_HOLDOUT_NOT_CLOSED')
            if postfreeze_holdout.exists() and (not isinstance(canon_ph,dict) or str(canon_ph.get('decision','')).upper()!='PASS_LOCAL_POSTFREEZE_HOLDOUT'):
                if deferred and isinstance(canon_ph,dict) and str(canon_ph.get('decision','')).upper()=='NOT_RUN': warnings.append('POSTFREEZE_LOCAL_HOLDOUT_CANONICAL_EVIDENCE_DEFERRED_TO_EXTERNAL_REAUDIT')
                else: blocks.append('POSTFREEZE_LOCAL_HOLDOUT_CANONICAL_EVIDENCE_NOT_PASS')
            if not strict_ok: warnings.append('STRICT_UNSEEN_HOLDOUT_NOT_RUN_OR_NOT_PROVEN_LOCAL_FROZEN_LANE_USED')
            bao=Path(td)/'baseline_applicability.json';bacmd=[sys.executable,str(BASEAPP),'--new',str(root),'--stage','POST_FREEZE','--json',str(bao)]
            if a.old: bacmd += ['--old',str(a.old)]
            cpba,bar=run_json(bacmd,bao)
            badecision=str(bar.get('decision','')).upper() if isinstance(bar,dict) else ''
            if cpba.returncode!=0 or badecision=='BLOCK':
                if isinstance(bar,dict) and 'POST_DRAFT_BASELINE_DIFFERENTIAL_NOT_RUN' in bar.get('blocks',[]): blocks.append('POST_DRAFT_BASELINE_DIFFERENTIAL_NOT_RUN')
                else: blocks.append('BASELINE_APPLICABILITY_NOT_CLOSED')
            elif badecision=='PASS_REQUIRED_BASELINE':
                if a.old:
                    bo=Path(td)/'baseline.json';cp2,br=run_json([sys.executable,str(BASE),'--old',str(a.old),'--new',str(root),'--json',str(bo)],bo)
                    if cp2.returncode!=0 or not br or str(br.get('decision','')).startswith('BLOCK'): blocks.append('POST_DRAFT_BASELINE_DIFFERENTIAL_BLOCK')
                else: blocks.append('POST_DRAFT_BASELINE_DIFFERENTIAL_NOT_RUN')
            elif badecision=='PASS_NOT_APPLICABLE_NEW_BOOK':
                br={'version':'V5.8_POST_DRAFT_BASELINE_APPLICABILITY','decision':'PASS_NOT_APPLICABLE_NEW_BOOK','blocks':[],'reason':'VALID_NEW_BOOK_NO_SAME_BOOK_CANONICAL'}
            else:
                blocks.append('BASELINE_APPLICABILITY_DECISION_INVALID')
    ho=holdout(root);hof=[x for x in ho if x['result']!='PASS']
    if not (root/'evidence'/'random_open_holdout.json').exists(): blocks.append('RANDOM_OPEN_HOLDOUT_EVIDENCE_MISSING')
    if not ho: blocks.append('RANDOM_OPEN_HOLDOUT_NO_CHAPTERS')
    elif hof: blocks.append('RANDOM_OPEN_HOLDOUT_FAIL')
    rr_ok,rr=real_reader_status(root,manifest)
    if not rr_ok: blocks.append('REAL_READER_EVIDENCE_CATEGORY_ERROR')
    optimistic=any(x in final for x in ('ACCEPT','PASS','REPLACE','PROMOTE','READY'))
    if blocks and optimistic: blocks.append('FINAL_DECISION_FALSE_GREEN')
    blocks=list(dict.fromkeys(blocks))
    report={'version':'V5.8_RUNTIME_ACCEPTANCE_AUDIT','runtime_contract_id':RUNTIME_CONTRACT_ID,'new':str(root),'old':a.old,'manifest':str(mp) if mp else None,'test_mode':mode or None,'runtime_entry_receipt':receipt,'runtime_authority_fidelity_external':ausp if 'ausp' in locals() else None,'full_book_substance_external':fbr if 'fbr' in locals() else None,'continuous_reading_external':crr if 'crr' in locals() else None,'reader_facing_packaging_external':pkr if 'pkr' in locals() else None,'adequacy_external':ar if 'ar' in locals() else None,'practical_asset_depth_external':drsp if 'drsp' in locals() else None,'generation_responsibility_external':rrsp if 'rrsp' in locals() else None,'prefreeze_random_open_external':prefsp if 'prefsp' in locals() else None,'operational_closure_external':orsp if 'orsp' in locals() else None,'training_feedback_external':trsp if 'trsp' in locals() else None,'shadow_local_value_external':shsp if 'shsp' in locals() else None,'strict_holdout_receipt_external':stsp if 'stsp' in locals() else None,'holdout_strength':('EXTERNAL_OPAQUE_PLUS_LOCAL_FROZEN' if 'strict_ok' in locals() and strict_ok else 'LOCAL_FROZEN_NON_OPAQUE'),'postfreeze_local_holdout_external':phsp if 'phsp' in locals() else None,'canonical_evidence_promotion_external':pmsp if 'pmsp' in locals() else None,'freeze_integrity_external':fisp if 'fisp' in locals() else None,'baseline_applicability_external':bar if 'bar' in locals() else None,'postdraft_baseline_external':br if 'br' in locals() else None,'random_open_holdout':{'samples':len(ho),'failed':len(hof),'details':ho},'real_reader_truth':rr,'manifest_final_decision':final or None,'blocks':blocks,'warnings':warnings,'decision':'BLOCK' if blocks else 'PASS_RUNTIME_ACCEPTANCE'}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
