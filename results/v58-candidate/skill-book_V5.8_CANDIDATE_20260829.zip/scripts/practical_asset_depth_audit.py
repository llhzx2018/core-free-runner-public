#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

TEXT_EXT={'.md','.markdown','.txt','.csv','.tsv'}
ROLE_HINTS={
 'evidence_capture':('evidence','ledger','research','interview','observation','证据','访谈','观察'),
 'decision_record':('decision','selection','choice','judge','决策','选择','判断'),
 'plan_or_contract':('plan','contract','scope','计划','合同','范围'),
 'execution_brief_or_log':('brief','run','execution','incident','recovery','执行','运行','恢复','日志'),
 'acceptance_record':('acceptance','readiness','verify','验收','就绪','验证'),
 'baseline_snapshot':('baseline','snapshot','基线','快照'),
 'iteration_log':('iteration','experiment','retro','迭代','实验','复盘'),
 'next_decision':('next_decision','next-decision','下一决策','下一决定'),
}

# A signal group is a semantic sub-responsibility, not a word-count score.
GROUPS={
 'context_task':{
  'actor':('actor','owner','operator','participant','user','角色','负责人','参与者','用户'),
  'trigger_moment':('trigger','when','moment','before','after','触发','何时','之前','之后'),
  'objective':('goal','objective','purpose','目标','目的'),
  'scope':('scope','non-goal','in scope','out of scope','范围','不做'),
  'handoff':('handoff','next action','output','交接','下一步','产出'),
 },
 'input_evidence':{
  'evidence_item':('evidence id','observation','raw statement','evidence item','sample','观察','原始陈述','证据项','样本'),
  'provenance':('source /','source:','source id','provenance','participant:','participant source','来源','证据来源','参与者'),
  'time_context':('date:','time:','timestamp','session context','version:','日期','时间','场景','版本'),
  'quality_uncertainty':('confidence','counter-evidence','contradiction','unknown','uncertainty','quality','置信','反证','矛盾','未知','不确定'),
  'interpretation_boundary':('raw statement','interpretation','raw fact','原始陈述','解释','原始事实'),
  'downstream_link':('decision informed','action informed','linked decision','linked action','follow-up evidence','支持决策','关联决策','后续证据'),
 },
 'decision_rule':{
  'options':('options:','option a','option b','alternatives','候选','选项'),
  'criteria':('criteria','threshold','decision rule','rule:','标准','阈值','规则'),
  'evidence_link':('evidence source','supporting evidence','evidence used','证据来源','支持证据'),
  'outcome':('selected option','decision:','accept / reject','accept/reject','continue','revise','选择结果','决定','决策结果'),
  'rationale':('rationale','tradeoff','because','why:','理由','权衡','因为'),
  'uncertainty':('uncertainty','exception','unknown','tie','不确定','例外','未知'),
  'revisit_trigger':('revisit trigger','reconsider if','reverse if','revisit if','重新评估条件','重审条件','反转条件'),
 },
 'state_boundary':{
  'ready_state':('ready','not_ready','not ready','就绪','未就绪'),
  'unknown_state':('unknown','invalid','incomplete','未知','无效','不完整'),
  'scope_boundary':('in scope','out of scope','non-goal','范围内','范围外','不做'),
  'exception':('exception','escalation','例外','升级处理'),
  'progression_guard':('only when','must not proceed','prevent progression','仅当','不得进入','禁止进入'),
 },
 'execution_steps':{
  'ordered_actions':('1.','2.','steps:','ordered','步骤','流程'),
  'inputs_dependencies':('inputs:','dependency','precondition','输入','依赖','前置'),
  'owner':('owner:','actor:','负责人','执行人'),
  'checkpoint':('checkpoint','check before','检查点','进入前检查'),
  'exception_path':('exception path','if blocked','异常路径','受阻时'),
  'handoff':('handoff','next action','交接','下一步'),
 },
 'validation_acceptance':{
  'expected':('expected:','expected state','预期','期望'),
  'actual':('actual:','actual state','实际'),
  'method':('verification method','verify by','validation method','验证方法','检查方法'),
  'evidence':('verification evidence','evidence log','evidence:','验证证据'),
  'result_state':('pass/fail','pass / fail','pass/ fail','partial','通过/失败','部分通过'),
  'defect_rework':('defect','rework','gap','缺陷','返工','差距'),
  'closure':('closure','close only','acceptance decision','关闭','验收决定'),
 },
 'evidence_log':{
  'stable_id':('evidence id','event id','record id','trace id','证据 id','事件 id','记录 id'),
  'provenance':('source/actor','source / actor','source / participant','source:','来源','证据来源'),
  'timestamp_version':('date:','time |','| time |','timestamp','version:','日期','时间','版本'),
  'observation_action':('action/observation','action / observation','observation:','raw statement','动作/观察','观察','原始陈述'),
  'result':('| result |','result:','outcome:','结果'),
  'interpretation':('interpretation','解释','判断说明'),
  'linkage':('linked decision','linked decision/change','decision informed','linked change','关联决策','关联变更','支持决策'),
 },
 'failure_recovery':{
  'trigger':('failure trigger','anomaly','problem:','failure:','失败触发','异常','问题'),
  'diagnosis':('diagnosis','likely cause','root cause','原因诊断','可能原因','根因'),
  'recovery_action':('recovery action','correction action','rollback','恢复动作','纠错动作','回滚'),
  'retry_condition':('retry condition','retry only when','retry when','重试条件','仅当.*重试'),
  'post_retry_evidence':('post-retry evidence','post retry evidence','retry result','重试后证据','重试结果'),
  'escalation_stop':('escalate','pause when','stop when','stop after','升级','暂停条件','停止条件'),
 },
 'change_control':{
  'baseline_version':('baseline version','current version','frozen scope','baseline plan','基线版本','当前版本','冻结范围'),
  'proposed_change':('proposed change','change proposal','change:','拟议变更','变更项'),
  'change_reason':('change reason','reason and supporting evidence','reason / evidence','变更原因','原因与证据'),
  'authority':('owner / authority','change owner','approver','变更负责人','批准人','authority'),
  'impact':('impact:','affected assumptions','affected scope','影响','受影响假设'),
  'revalidation':('revalidation','re-validate','revalidate','重新验证','复验'),
  'supersession':('superseded','rollback target','freeze state','被替代','回滚目标','冻结状态'),
  'disposition':('accept / reject / defer','accept/reject/defer','approve / reject','接受/拒绝/推迟'),
 },
 'completion':{
  'exit_criteria':('completion:','close only','ready only','done only','完成条件','仅当.*完成','关闭条件'),
  'required_evidence_state':('evidence is','evidence attached','trace is complete','required evidence','证据完整','证据已附'),
  'blocker_unknown':('blocker','unknown remains','unresolved','阻塞','未知项','未解决'),
  'next_stage_closure':('handoff','next stage','close','closure','进入下一阶段','交接','关闭'),
 },
 'example_guidance':{
  'worked_example':('worked example','filled example','example:','示例','填写示例'),
  'reference_judgment':('reference judgment','reference answer','参考判断','参考答案'),
  'why':('why:','because','why this','为什么','因为'),
  'common_wrong':('common mistake','common error','wrong interpretation','常见错误','错误理解'),
  'adaptation':('adaptation','adapt when','different case','调整指南','换一种情况','适配'),
 },
}

ROLE_REQUIREMENTS={
 'evidence_capture':{
  'input_evidence':({'evidence_item','provenance','quality_uncertainty','downstream_link'},4),
  'evidence_log':({'stable_id','provenance','observation_action','linkage'},4),
 },
 'decision_record':{
  'decision_rule':({'options','criteria','outcome','rationale','revisit_trigger'},5),
 },
 'plan_or_contract':{
  'change_control':({'baseline_version','proposed_change','change_reason','revalidation'},4),
 },
 'execution_brief_or_log':{
  'execution_steps':({'ordered_actions'},1),
  'evidence_log':({'stable_id','provenance','observation_action','result','linkage'},5),
  'failure_recovery':({'trigger','diagnosis','recovery_action','retry_condition','escalation_stop'},5),
 },
 'acceptance_record':{
  'validation_acceptance':({'expected','actual','method','result_state','defect_rework'},5),
 },
 'baseline_snapshot':{
  'input_evidence':({'provenance','time_context'},2),
  'change_control':({'baseline_version','supersession'},2),
 },
 'iteration_log':{
  'evidence_log':({'stable_id','timestamp_version','result','interpretation','linkage'},5),
  'decision_rule':({'criteria','outcome','rationale'},3),
 },
 'next_decision':{
  'decision_rule':({'criteria','outcome','rationale','revisit_trigger'},4),
 },
}

DIM_MIN={'context_task':2,'input_evidence':3,'decision_rule':4,'state_boundary':1,'execution_steps':2,'validation_acceptance':4,'evidence_log':4,'failure_recovery':4,'change_control':4,'completion':1,'example_guidance':3}
SPECIAL_BLOCK={
 'evidence_log':'PRACTICAL_ASSET_EVIDENCE_LOG_SHALLOW',
 'change_control':'PRACTICAL_ASSET_CHANGE_CONTROL_SHALLOW',
 'example_guidance':'PRACTICAL_ASSET_EXAMPLE_GUIDANCE_SHALLOW',
 'failure_recovery':'PRACTICAL_ASSET_RECOVERY_LOOP_INCOMPLETE',
}

def read_text(p:Path): return p.read_text(encoding='utf-8',errors='replace')
def contains(low:str, token:str):
 if '.*' in token:
  return bool(re.search(token,low,re.I))
 return token.lower() in low

def group_hits(text:str,dimension:str):
 low=text.lower(); groups=GROUPS.get(dimension,{})
 return {name for name,tokens in groups.items() if any(contains(low,t) for t in tokens)}

def infer_roles(path:str,text:str):
 low=(path+' '+text[:500]).lower(); out=set()
 for role,hints in ROLE_HINTS.items():
  if any(h.lower() in low for h in hints): out.add(role)
 return out

def asset_paths(root:Path):
 out=[]
 for d in (root/'templates',root/'assets'):
  if d.exists(): out.extend(p for p in d.iterdir() if p.is_file() and p.suffix.lower() in TEXT_EXT)
 return sorted(set(out))

def load_contract(root:Path,explicit:str|None):
 ps=[]
 if explicit: ps.append(Path(explicit))
 ps += [root/'evidence'/'practical_asset_depth_contract.json',root/'frontmatter'/'practical_asset_depth_contract.json']
 for p in ps:
  if p.exists():
   try:return p,json.loads(read_text(p))
   except Exception:return p,{'parse_error':True}
 return None,None

def rel(root:Path,p:Path): return p.relative_to(root).as_posix()

def audit_asset(root:Path,p:Path,profile:dict):
 path=rel(root,p); text=read_text(p); declared=set(profile.get('roles') or []); inferred=infer_roles(path,text)
 complexity=str(profile.get('complexity','MEDIUM')).upper(); required=list(profile.get('required_dimensions') or [])
 reasons=[]; blocks=[]; details={}
 if not declared: reasons.append('NO_ROLE_DECLARED'); blocks.append('PRACTICAL_ASSET_ROLE_UNDERDECLARED')
 # Filename/text inference is a guard only when it finds a single strong role absent from the profile.
 strong_inferred={r for r in inferred if r in {'evidence_capture','decision_record','plan_or_contract','execution_brief_or_log','acceptance_record','baseline_snapshot','iteration_log','next_decision'}}
 if len(strong_inferred)==1 and declared and not (declared & strong_inferred):
  reasons.append('ROLE_MISMATCH:'+','.join(sorted(strong_inferred))); blocks.append('PRACTICAL_ASSET_ROLE_UNDERDECLARED')

 required_by_role={}
 for role in declared:
  for dim,(anchors,minn) in ROLE_REQUIREMENTS.get(role,{}).items():
   prev=required_by_role.get(dim,(set(),0)); required_by_role[dim]=(prev[0]|set(anchors),max(prev[1],minn))

 # A HIGH asset cannot omit dimensions that are structurally mandatory for its declared role.
 if complexity=='HIGH':
  missing_role_dims=sorted(set(required_by_role)-set(required))
  if missing_role_dims:
   reasons.append('ROLE_REQUIRED_DIMENSIONS_UNDERDECLARED:'+','.join(missing_role_dims)); blocks.append('PRACTICAL_ASSET_DEPTH_UNDERDECLARED')

 for dim in required:
  hits=group_hits(text,dim); mandatory,min_role=required_by_role.get(dim,(set(),0)); min_hits=max(DIM_MIN.get(dim,1),min_role)
  missing=sorted(mandatory-hits)
  details[dim]={'hits':sorted(hits),'hit_count':len(hits),'minimum':min_hits,'mandatory':sorted(mandatory),'missing_mandatory':missing}
  shallow=bool(missing) or len(hits)<min_hits
  if shallow:
   reasons.append(f'{dim}:DEPTH_LOW:{len(hits)}<{min_hits}' + (':MISSING='+','.join(missing) if missing else ''))
   blocks.append(SPECIAL_BLOCK.get(dim,'PRACTICAL_ASSET_REQUIRED_SUBRESPONSIBILITY_MISSING'))

 # Examples are particularly vulnerable to token samples pretending to be guidance.
 if 'example_guidance' in required:
  h=set(details['example_guidance']['hits'])
  if 'worked_example' in h and not ({'reference_judgment','why'}<=h):
   blocks.append('PRACTICAL_ASSET_EXAMPLE_GUIDANCE_SHALLOW')

 return {'path':path,'complexity':complexity,'declared_roles':sorted(declared),'inferred_roles':sorted(inferred),'required_dimensions':required,'depth':details,'reasons':reasons,'decision':'BLOCK' if blocks else 'PASS'},blocks

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--new',required=True); ap.add_argument('--contract'); ap.add_argument('--json'); a=ap.parse_args(); root=Path(a.new)
 cp,contract=load_contract(root,a.contract); blocks=[]; rows=[]
 if contract is None: blocks.append('PRACTICAL_ASSET_DEPTH_CONTRACT_MISSING'); contract={'assets':[]}
 elif contract.get('parse_error'): blocks.append('PRACTICAL_ASSET_DEPTH_CONTRACT_PARSE_ERROR'); contract={'assets':[]}
 profiles={str(x.get('path')):x for x in contract.get('assets',[]) if isinstance(x,dict) and x.get('path')}
 for p in asset_paths(root):
  path=rel(root,p); prof=profiles.get(path)
  if not prof:
   rows.append({'path':path,'decision':'BLOCK','reasons':['MISSING_ASSET_DEPTH_PROFILE']}); blocks.append('PRACTICAL_ASSET_DEPTH_UNDERDECLARED'); continue
  row,b=audit_asset(root,p,prof); rows.append(row); blocks.extend(b)
 for path in sorted(set(profiles)-{rel(root,p) for p in asset_paths(root)}):
  rows.append({'path':path,'decision':'BLOCK','reasons':['PROFILE_ASSET_MISSING']}); blocks.append('PRACTICAL_ASSET_REQUIRED_SUBRESPONSIBILITY_MISSING')
 blocks=sorted(set(blocks))
 report={'version':'V5.6_PRACTICAL_ASSET_DEPTH_AUDIT_WIP','new':str(root),'contract':str(cp) if cp else None,'assets':len(rows),'details':rows,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
 if a.json: Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2)); return 1 if blocks else 0

if __name__=='__main__': raise SystemExit(main())
