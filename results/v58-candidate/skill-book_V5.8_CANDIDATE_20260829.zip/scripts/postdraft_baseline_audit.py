#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from adequacy_audit import templates,chapters,refs,t,compact,dim_hits,structure

def stem_tokens(p:Path):
 s=re.sub(r'^\d+[_ .-]*','',p.stem.lower())
 toks=set(re.findall(r'[a-z0-9]+|[\u4e00-\u9fff]{2,}',s))
 stop={'template','模板','record','sheet','decision','plan','contract','brief','acceptance','log','sop','决定','决策','计划','合同','验收','日志'}
 return {x for x in toks if x not in stop}
def similarity(a:Path,b:Path):
 at,bt=stem_tokens(a),stem_tokens(b);name=(len(at&bt)/len(at|bt)) if at|bt else 0
 ad,bd=set(dim_hits(t(a))),set(dim_hits(t(b)));dim=(len(ad&bd)/len(ad|bd)) if ad|bd else 0
 return .65*name+.35*dim
def build_matches(oldps,newps):
 matches={}
 for op in oldps:
  exact=[np for np in newps if np.name==op.name]
  if exact:
   matches[op]=(exact[0],1.0,'EXACT_BASENAME');continue
  ot=stem_tokens(op)
  exact_topic=[np for np in newps if ot and stem_tokens(np)==ot]
  if exact_topic:
   np=max(exact_topic,key=lambda x:similarity(op,x));matches[op]=(np,similarity(op,np),'EXACT_TOPIC');continue
  if newps:
   np=max(newps,key=lambda x:similarity(op,x));matches[op]=(np,similarity(op,np),'BEST_EFFORT')
 return matches

def bundle_chars(root):
 return sum(len(compact(t(p))) for p in chapters(root)+refs(root))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--old',required=True);ap.add_argument('--new',required=True);ap.add_argument('--json');a=ap.parse_args();old=Path(a.old);new=Path(a.new)
 ots,nts=templates(old),templates(new);mapping=build_matches(ots,nts);rows=[];reg=[];alignment_warnings=[]
 for op in ots:
  np,score,align=mapping.get(op,(None,0,'UNALIGNED'))
  oc=len(compact(t(op)));nc=len(compact(t(np))) if np else 0;ratio=(nc/oc if oc else None)
  od=set(dim_hits(t(op)));nd=set(dim_hits(t(np))) if np else set();lost=sorted(od-nd)
  os=structure(t(op))['units'];ns=structure(t(np))['units'] if np else 0;sr=(ns/os if os else None)
  high_conf=bool(np) and (align in {'EXACT_BASENAME','EXACT_TOPIC'} or score>=.45)
  row={'old':op.name,'new':np.name if np else None,'alignment':align,'alignment_confidence':'HIGH' if high_conf else 'LOW','match_score':round(score,3),'old_chars':oc,'new_chars':nc,'char_ratio':round(ratio,3) if ratio is not None else None,'old_dimensions':sorted(od),'new_dimensions':sorted(nd),'lost_dimensions':lost,'structure_ratio':round(sr,3) if sr is not None else None}
  rows.append(row)
  substantial=oc>=700
  if substantial and not high_conf: alignment_warnings.append({'old':op.name,'best_new':np.name if np else None,'match_score':round(score,3),'reason':'SUBSTANTIAL_ASSET_LOW_CONFIDENCE_ALIGNMENT_REQUIRES_HUMAN_REVIEW'})
  # Machine blocker requires a substantial old asset AND a high-confidence alignment. Low-confidence topology cannot prove regression.
  if substantial and high_conf and ratio is not None and (ratio<.35 or (ratio<.55 and (lost or (sr is not None and sr<.70)))):reg.append(row)
 old_bundle=bundle_chars(old);new_bundle=bundle_chars(new);br=(new_bundle/old_bundle if old_bundle else None)
 blocks=[]
 if reg:blocks.append('PRACTICAL_ASSET_BASELINE_DIFFERENTIAL')
 if br is not None and br<.65:blocks.append('LEARNING_BUNDLE_DEPTH_DIFFERENTIAL')
 report={'version':'V5.5_POST_DRAFT_BASELINE_AUDIT','old':str(old),'new':str(new),'asset_rows':rows,'asset_regressions':reg,'alignment_warnings':alignment_warnings,'learning_bundle':{'old_chars':old_bundle,'new_chars':new_bundle,'ratio':round(br,3) if br is not None else None},'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS_REVIEW_NO_MACHINE_TRIGGER'}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
