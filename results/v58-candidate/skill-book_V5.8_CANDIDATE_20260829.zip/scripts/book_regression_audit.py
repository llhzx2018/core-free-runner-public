#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,random,re
from collections import Counter
from pathlib import Path
TEXT={'.md','.markdown','.txt','.csv','.tsv'}
PLACE=('待填写','tbd','current value','result：`not_run`','state：`not_run`')
SPEC=('参数','字段','输入','输出','规则','条件','边界','示例','案例','错误','失败','恢复','回滚','验证','验收','判断','决策','完成')
def files(root): return sorted(p for p in Path(root).rglob('*') if p.is_file() and p.suffix.lower() in TEXT)
def text(p): return p.read_text(encoding='utf-8',errors='replace')
def cid(p):
 for pat in (r'第\s*0*(\d{1,3})\s*章',r'^0*(\d{1,3})[_ .-]'):
  m=re.search(pat,p.stem,re.I)
  if m and int(m.group(1))>0:return int(m.group(1))
 return None
def kind(p):
 s=p.as_posix().lower()
 if '/depth_plan/' in s or '/evidence/' in s or '/validation/' in s or '/machine_record/' in s:return 'other'
 if 'operator_reference' in s or '/references/operator/' in s:return 'reference'
 if '/templates/' in s:return 'template'
 if '/assets/' in s:
  n=p.name.lower()
  if any(x in n for x in ('reader_transformation','depth_plan','worked_example','example_filled')): return 'other'
  return 'template'
 # V4.7 forbids generic numeric-filename fallback: Manifest/asset files such as
 # 01_MANIFEST.md must never become chapters just because they start with a number.
 if ('/manuscript/' in s or '/chapters/' in s) and cid(p):return 'chapter'
 return 'other'
def normalize(line):
 s=re.sub(r'`[^`]+`','<id>',line.strip().lower());s=re.sub(r'\d{2,}','<n>',s);return re.sub(r'\s+',' ',s)
def uniformity(paths):
 if len(paths)<4:return 0.0
 sets=[]
 for p in paths:
  ss={normalize(x) for x in text(p).splitlines() if len(normalize(x))>=18};sets.append(ss)
 c=Counter(x for s in sets for x in s);th=max(2,math.ceil(len(sets)*.5));rs=[]
 for s in sets:rs.append(sum(1 for x in s if c[x]>=th)/len(s) if s else 0)
 return round(sum(rs)/len(rs),4)
def heading_uniformity(paths):
 if len(paths)<4:return 0.0
 sets=[]
 for p in paths:
  hs=set()
  for line in text(p).splitlines():
   if re.match(r'^#{2,3}\s+',line):
    h=re.sub(r'^#{2,3}\s+','',line).strip().lower();h=re.sub(r'\d+','<n>',h);h=re.sub(r'`[^`]+`','<id>',h)
    if len(h)>=4:hs.add(h)
  sets.append(hs)
 c=Counter(x for ss in sets for x in ss);th=max(2,math.ceil(len(sets)*.5));rs=[]
 for ss in sets:rs.append(sum(1 for x in ss if c[x]>=th)/len(ss) if ss else 0)
 return round(sum(rs)/len(rs),4)
def local_value(chunk):
 s=re.sub(r'\s+',' ',chunk).strip();reasons=[]
 if len(s)<160:reasons.append('TOO_THIN')
 if sum(1 for x in SPEC if x in s)<2:reasons.append('LOW_SPECIFICITY')
 lines=[x.strip().lower() for x in chunk.splitlines() if x.strip()]
 if lines and sum(1 for x in lines if any(t in x for t in PLACE))/len(lines)>=.2:reasons.append('PLACEHOLDER_DOMINANT')
 return not reasons,reasons
def random_samples(paths):
 out=[]
 for seed in range(4401,4409):
  r=random.Random(seed);p=r.choice(paths);paras=[x.strip() for x in re.split(r'\n\s*\n',text(p)) if x.strip()];i=r.randrange(len(paras));w=[paras[i]];j=i+1
  while len('\n\n'.join(w))<420 and j<len(paras):w.append(paras[j]);j+=1
  j=i-1
  while len('\n\n'.join(w))<300 and j>=0:w.insert(0,paras[j]);j-=1
  chunk='\n\n'.join(w);ok,why=local_value(chunk);out.append({'seed':seed,'path':p.as_posix(),'chars':len(chunk),'result':'PASS' if ok else 'FAIL','reasons':why})
 return out
def snap(root):
 ps=files(root);chs=[p for p in ps if kind(p)=='chapter'];refs=[p for p in ps if kind(p)=='reference'];tmpls=[p for p in ps if kind(p)=='template'];cm={cid(p):len(text(p)) for p in chs if cid(p)}
 return {'path':str(root),'chapter_count':len(cm),'chapter_chars':cm,'references':len(refs),'templates':len(tmpls),'reference_uniformity':uniformity(refs),'template_uniformity':uniformity(tmpls),'manuscript_heading_uniformity':heading_uniformity(chs),'random_open':random_samples(chs+refs+tmpls) if chs+refs+tmpls else []}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--old',action='append',required=True);ap.add_argument('--new',required=True);ap.add_argument('--expected-old-chapters',type=int,required=True);ap.add_argument('--mode',choices=['STANDALONE','SEALED_STANDALONE_FORWARD','CONSOLIDATE'],required=True);ap.add_argument('--json');a=ap.parse_args()
 olds=[snap(x) for x in a.old];new=snap(a.new);canonical=max(olds,key=lambda s:(s['chapter_count'],sum(s['chapter_chars'].values())));blocks=[];warnings=[]
 if canonical['chapter_count']!=a.expected_old_chapters:blocks.append('CANONICAL_BASELINE_TRUTH')
 sealed=a.mode=='SEALED_STANDALONE_FORWARD'
 if not sealed and new['chapter_count']!=a.expected_old_chapters:blocks.append('CHAPTER_COUNT')
 elif sealed and new['chapter_count']!=a.expected_old_chapters:warnings.append('CHAPTER_COUNT_DIFFERENCE_REQUIRES_POST_DRAFT_RESPONSIBILITY_AUDIT')
 ratios=[]
 if not sealed:
  for i in range(1,a.expected_old_chapters+1):
   o=canonical['chapter_chars'].get(i,0);n=new['chapter_chars'].get(i,0);ratio=(n/o if o else None);ratios.append({'chapter':i,'old_chars':o,'new_chars':n,'ratio':round(ratio,3) if ratio is not None else None})
  compression=[x for x in ratios if x['ratio'] is not None and x['ratio']<.75]
  if compression:blocks.append('PER_CHAPTER_COMPRESSION')
 else:compression=[]
 ro_fail=[x for x in new['random_open'] if x['result']=='FAIL']
 if ro_fail:blocks.append('RANDOM_OPEN_LOCAL_VALUE')
 if new['reference_uniformity']>=.55 or new['template_uniformity']>=.55:blocks.append('UNIFORMITY_DRIFT_REVIEW')
 if new['manuscript_heading_uniformity']>=.35:blocks.append('READING_CORE_STRUCTURAL_UNIFORMITY')
 report={'version':'V5.4_BOOK_REGRESSION_AUDIT','mode':a.mode,'canonical':canonical,'new':new,'chapter_ratios':ratios,'compression_count':len(compression),'random_open_fail_count':len(ro_fail),'warnings':warnings,'decision':'BLOCK_REPLACEMENT' if blocks else 'PASS_NO_MACHINE_TRIGGER','blocks':blocks}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
