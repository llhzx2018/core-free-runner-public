#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
FORBIDDEN=('seed','seeds','path','paths','window','windows','sample_details','details')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--receipt',required=True);ap.add_argument('--json');a=ap.parse_args();p=Path(a.receipt);fails=[]
    try:d=json.loads(p.read_text(encoding='utf-8'))
    except Exception:d=None
    if not isinstance(d,dict):fails.append('STRICT_HOLDOUT_RECEIPT_MISSING_OR_INVALID');d={}
    decision=str(d.get('decision','')).upper();exposure=str(d.get('generator_exposure','')).upper();count=int(d.get('sample_count',0) or 0);failed=int(d.get('failed_count',0) or 0)
    if decision!='PASS':fails.append('STRICT_HOLDOUT_NOT_PASS')
    if count<12:fails.append('STRICT_HOLDOUT_SAMPLE_COUNT_LOW')
    if failed!=0:fails.append('STRICT_HOLDOUT_HAS_FAILURES')
    if exposure not in {'NONE','OPAQUE_AGGREGATE_ONLY'}:fails.append('GENERATOR_EXPOSURE_NOT_OPAQUE')
    if len(str(d.get('seed_commitment','')).strip())<16:fails.append('SEED_COMMITMENT_MISSING')
    if not str(d.get('evaluator_id','')).strip() or not str(d.get('run_id','')).strip():fails.append('EVALUATOR_IDENTITY_MISSING')
    low_keys={str(k).lower() for k in d.keys()}
    leaked=sorted(k for k in FORBIDDEN if k in low_keys)
    if leaked:fails.append('HOLDOUT_SAMPLE_OR_SEED_LEAK')
    report={'version':'V5.4_STRICT_HOLDOUT_RECEIPT_AUDIT','receipt':str(p),'sample_count':count,'failed_count':failed,'generator_exposure':exposure or None,'leaked_fields':leaked,'failures':fails,'decision':'BLOCK' if fails else 'PASS'}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if fails else 0
if __name__=='__main__':raise SystemExit(main())
