#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path

REQ=('chapters','entry_reader_state','carry_over','capability_progression','rhythm_variation','output_input_handoff','end_reader_state','remove_one_chapter_impact','decision')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--audit',required=True);ap.add_argument('--json');a=ap.parse_args();p=Path(a.audit);blocks=[]
    if not p.exists(): data={};blocks.append('CONTINUOUS_READING_AUDIT_MISSING')
    else:data=json.loads(p.read_text(encoding='utf-8'))
    windows=data.get('windows',[])
    if len(windows)<2:blocks.append('CONTIGUOUS_WINDOW_COVERAGE')
    weak=[]
    for i,w in enumerate(windows):
        miss=[k for k in REQ if k not in w]
        ch=w.get('chapters',[])
        if len(ch)!=3 or not all(isinstance(x,int) for x in ch) or not (ch[1]==ch[0]+1 and ch[2]==ch[1]+1):miss.append('three_adjacent_chapters')
        for k in ('carry_over','capability_progression','rhythm_variation','output_input_handoff','remove_one_chapter_impact'):
            v=w.get(k)
            if not isinstance(v,str) or len(v.strip())<30:miss.append(k+'_evidence')
        if w.get('decision')!='PASS':blocks.append('WINDOW_BLOCK')
        if miss:weak.append({'window':i,'missing_or_weak':sorted(set(miss))})
    if weak:blocks.append('CONTINUOUS_READING_EVIDENCE_WEAK')
    report={'version':'V5.8_CONTINUOUS_READING_AUDIT','windows':len(windows),'weak_windows':weak,'decision':'BLOCK' if blocks else 'PASS','blocks':sorted(set(blocks))}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
