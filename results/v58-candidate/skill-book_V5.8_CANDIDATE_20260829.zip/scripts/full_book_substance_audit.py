#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

BAD={'THIN_SHELL','OUTLINE_EXPANSION','CHECKLIST_DOMINANT','REFERENCE_DEPENDENT'}
ALLOWED=BAD|{'SUBSTANTIVE','BORDERLINE'}

def chapter_id_from_name(name:str):
    stem=Path(name).stem
    for pat in (r'^0*(\d{1,3})$',r'^0*(\d{1,3})[_ .-]',r'^chapter[_ .-]*0*(\d{1,3})\b',r'第\s*0*(\d{1,3})\s*章'):
        m=re.search(pat,stem,re.I)
        if m:return int(m.group(1))
    return None

def split_combined(text:str,path_label:str):
    # Read-only, language-friendly. Chinese chapter headings are the main combined-manuscript fallback.
    pat=re.compile(r'(?m)^#{1,2}\s*第\s*(\d+)\s*章[^\n]*\n')
    ms=list(pat.finditer(text));out=[]
    for i,m in enumerate(ms):
        n=int(m.group(1));start=m.end();end=ms[i+1].start() if i+1<len(ms) else len(text)
        out.append({'chapter':n,'path':f'{path_label}#第{n}章','text':text[start:end]})
    return out

def chapter_records(root:Path):
    out=[];seen=set()
    dirs=[root/'manuscript',root/'chapters',root/'book'/'chapters',root/'BOOK'/'chapters']
    for d in dirs:
        if not d.exists():continue
        for p in d.glob('*.md'):
            n=chapter_id_from_name(p.name)
            if n is None or n in seen:continue
            out.append({'chapter':n,'path':p.relative_to(root).as_posix(),'text':p.read_text(encoding='utf-8',errors='replace')});seen.add(n)
    if out:return sorted(out,key=lambda x:x['chapter'])
    # Discover one obvious combined manuscript without assuming A1 or English engineering names.
    candidates=[]
    for p in root.rglob('*.md'):
        rel=p.relative_to(root).as_posix().lower()
        name=p.name.lower()
        score=0
        if '完整正文' in p.name:score+=5
        if 'manuscript' in name:score+=4
        if '/book/' in '/'+rel or rel.startswith('book/'):score+=1
        if any(x in rel for x in ('evidence/','audit/','template','workbook','reference')):score-=5
        if score>0:candidates.append((score,p))
    for _,p in sorted(candidates,key=lambda x:(-x[0],x[1].as_posix())):
        sections=split_combined(p.read_text(encoding='utf-8',errors='replace'),p.relative_to(root).as_posix())
        if len(sections)>=2:return sections
    return []

def content_units(text:str):
    body=re.sub(r'```.*?```','',text,flags=re.S)
    cjk=len(re.findall(r'[\u3400-\u9fff]',body))
    words=len(re.findall(r"\b[A-Za-z0-9][A-Za-z0-9'_-]*\b",body))
    return cjk+words*2

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--audit',required=True);ap.add_argument('--json');ap.add_argument('--short-risk-units',type=int,default=1800);a=ap.parse_args()
    root=Path(a.new);audit_path=Path(a.audit);blocks=[]
    if not audit_path.exists():blocks.append('FULL_BOOK_SUBSTANCE_AUDIT_MISSING');audit={}
    else:
        try:audit=json.loads(audit_path.read_text(encoding='utf-8'))
        except Exception:audit={};blocks.append('FULL_BOOK_SUBSTANCE_AUDIT_INVALID_JSON')
    if audit.get('product_class')!='FULL_BOOK':blocks.append('PRODUCT_CLASS_NOT_FULL_BOOK')
    chapters=chapter_records(root)
    if not chapters:blocks.append('CHAPTERS_NOT_FOUND')
    judgments={int(x['chapter']):x for x in audit.get('chapters',[]) if isinstance(x,dict) and str(x.get('chapter','')).isdigit()}
    core=[int(x) for x in audit.get('core_chapters',[]) if str(x).isdigit()]
    if not core:core=[x['chapter'] for x in chapters]
    if not core:blocks.append('CORE_CHAPTERS_MISSING')
    by_id={x['chapter']:x for x in chapters};thin=[];short=[];missing=[];evidence_weak=[];metrics=[]
    for n in core:
        rec=by_id.get(n)
        if not rec:missing.append(n);continue
        units=content_units(rec['text']);metrics.append({'chapter':n,'path':rec['path'],'content_units':units})
        if units<a.short_risk_units:short.append(n)
        j=judgments.get(n)
        if not j:missing.append(n);continue
        cls=j.get('classification')
        if cls not in ALLOWED:evidence_weak.append({'chapter':n,'reason':'INVALID_CLASSIFICATION'})
        if cls in BAD:thin.append(n)
        ev=j.get('evidence',[])
        if not isinstance(ev,list) or len([x for x in ev if isinstance(x,str) and len(x.strip())>=20])<2:evidence_weak.append({'chapter':n,'reason':'EVIDENCE_TOO_WEAK'})
    if missing:blocks.append('CORE_CHAPTER_JUDGMENT_COVERAGE')
    if evidence_weak:blocks.append('SEMANTIC_EVIDENCE_WEAK')
    denom=max(len(core),1);thin_ratio=len(set(thin))/denom;short_ratio=len(set(short))/denom
    if thin_ratio>=0.40:blocks.append('THIN_CORE_CHAPTER_RATIO')
    # A generator cannot self-override obvious machine shell risk. Only independent evaluator authority can close it.
    if short_ratio>=0.40 and audit.get('semantic_override_authority')!='EXTERNAL_REVIEWER':blocks.append('UNRESOLVED_MACHINE_SHELL_RISK')
    report={'version':'V5.8_FULL_BOOK_SUBSTANCE_AUDIT','product_class':audit.get('product_class'),'core_chapters':core,'chapter_metrics':metrics,'short_risk_chapters':sorted(set(short)),'short_risk_ratio':round(short_ratio,4),'thin_classified_chapters':sorted(set(thin)),'thin_classified_ratio':round(thin_ratio,4),'missing_or_unmapped':missing,'evidence_weak':evidence_weak,'reader_bytes_mutated_by_audit':False,'decision':'BLOCK' if blocks else 'PASS','blocks':sorted(set(blocks))}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
