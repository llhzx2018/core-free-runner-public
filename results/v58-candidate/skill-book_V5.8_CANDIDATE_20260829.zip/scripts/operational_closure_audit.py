#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path

RESPONSIBILITIES=(
 'economics_viability','acquisition_funnel','execution_implementation','measurement_attribution',
 'experiment_change_control','diagnosis_incident_recovery','quality_acceptance','scale_resource_constraints',
 'operating_cadence','end_to_end_repeatable_workflow'
)
CORE_PRACTICAL={
 'execution_implementation','measurement_attribution','experiment_change_control',
 'diagnosis_incident_recovery','quality_acceptance','operating_cadence','end_to_end_repeatable_workflow'
}
INFER={
 'economics_viability':('revenue','profit','price','pricing','commission','cashflow','margin','monetiz','收入','利润','定价','佣金','现金流','毛利','商业模式'),
 'acquisition_funnel':('traffic','acquisition','funnel','seo','marketing','conversion','lead','流量','获客','漏斗','转化率','营销','搜索'),
 'scale_resource_constraints':('scale','capacity','budget','resource','cashflow','扩量','规模','容量','预算','资源','现金流')
}
TEXT_EXT={'.md','.markdown','.txt','.csv','.tsv'}
SIGNALS=('判断','决策','条件','规则','执行','步骤','验证','验收','恢复','重试','完成','decision','rule','execute','step','validation','acceptance','recovery','retry','completion')

def read_json(p:Path):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None

def compact(s):return re.sub(r'\s+','',s)
def locate(root:Path,rel):
    p=root/str(rel);return p if p.is_file() else None

def reader_contract_text(rtc):
    if not isinstance(rtc,dict):return ''
    bits=[]
    for k,v in rtc.items():
        if isinstance(v,str):bits.append(v)
        elif isinstance(v,list):
            for x in v:
                if isinstance(x,str):bits.append(x)
                elif isinstance(x,dict):bits.extend(str(y) for y in x.values() if isinstance(y,(str,int,float)))
    return ' '.join(bits).lower()

def inferred_required(name,book_type,rtc_text):
    if book_type in {'PRACTICAL_PROJECT','PRACTICAL_SKILL'} and name in CORE_PRACTICAL:return True,'PRACTICAL_CORE'
    kws=INFER.get(name,())
    if kws and any(k.lower() in rtc_text for k in kws):return True,'READER_CONTRACT_SIGNAL'
    return False,None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--stage',required=True,choices=['PRE_DRAFT','PRE_FREEZE']);ap.add_argument('--json');a=ap.parse_args()
    root=Path(a.new);blocks=[];failures=[];details=[]
    rtc_p=root/'evidence'/'reader_transformation_contract.json';con_p=root/'evidence'/'operational_closure_contract.json'
    rtc=read_json(rtc_p) if rtc_p.exists() else None;con=read_json(con_p) if con_p.exists() else None
    if not rtc:blocks.append('READER_TRANSFORMATION_MACHINE_CONTRACT_MISSING_OR_INVALID');rtc={}
    if not con:blocks.append('OPERATIONAL_CLOSURE_CONTRACT_MISSING_OR_INVALID');con={}
    book_type=str(con.get('book_type') or rtc.get('BOOK_TYPE') or '').upper();text=reader_contract_text(rtc)
    if book_type not in {'PRACTICAL_PROJECT','PRACTICAL_SKILL','CONCEPTUAL_REFERENCE'}:blocks.append('BOOK_TYPE_MISSING_OR_INVALID')
    rows=con.get('responsibilities',[]) if isinstance(con,dict) else []
    idx={str(x.get('responsibility','')).lower():x for x in rows if isinstance(x,dict) and x.get('responsibility')}
    for name in RESPONSIBILITIES:
        row=idx.get(name);must,why=inferred_required(name,book_type,text)
        if not row:
            failures.append({'responsibility':name,'reason':'MISSING_RESPONSIBILITY_ENTRY','inferred_required':must,'inference':why});continue
        app=str(row.get('applicability','')).upper();item={'responsibility':name,'applicability':app,'inferred_required':must,'inference':why,'checks':[]}
        if app not in {'REQUIRED','OPTIONAL','N_A','NA','N/A'}:
            failures.append({'responsibility':name,'reason':'INVALID_APPLICABILITY','value':app});details.append(item);continue
        if must and app!='REQUIRED':
            failures.append({'responsibility':name,'reason':'INFERRED_REQUIRED_NOT_REQUIRED','value':app,'inference':why})
        if app in {'N_A','NA','N/A'}:
            if len(str(row.get('rationale','')).strip())<24:failures.append({'responsibility':name,'reason':'N_A_WITHOUT_SPECIFIC_RATIONALE'})
            details.append(item);continue
        if app=='REQUIRED':
            chapters=[str(x) for x in row.get('chapter_paths',[]) if str(x).strip()];assets=[str(x) for x in row.get('asset_paths',[]) if str(x).strip()]
            fields={k:str(row.get(k,'')).strip() for k in ('judgment','execution','validation')}
            if not chapters:failures.append({'responsibility':name,'reason':'NO_CHAPTER_MAPPING'})
            if not assets:failures.append({'responsibility':name,'reason':'NO_PRACTICAL_ASSET_MAPPING'})
            for k,v in fields.items():
                if len(v)<12:failures.append({'responsibility':name,'reason':f'{k.upper()}_CONTRACT_TOO_THIN'})
            item.update({'chapter_paths':chapters,'asset_paths':assets,**fields})
            if a.stage=='PRE_FREEZE':
                for rel in chapters:
                    p=locate(root,rel)
                    if not p:failures.append({'responsibility':name,'path':rel,'reason':'CHAPTER_PATH_MISSING'});continue
                    s=p.read_text(encoding='utf-8',errors='replace');hits=sum(1 for x in SIGNALS if x.lower() in s.lower());item['checks'].append({'path':rel,'kind':'chapter','chars':len(compact(s)),'signals':hits})
                    if hits<4:failures.append({'responsibility':name,'path':rel,'reason':'CHAPTER_OPERATIONAL_SIGNAL_LOW','signals':hits})
                for rel in assets:
                    p=locate(root,rel)
                    if not p:failures.append({'responsibility':name,'path':rel,'reason':'ASSET_PATH_MISSING'});continue
                    s=p.read_text(encoding='utf-8',errors='replace');hits=sum(1 for x in SIGNALS if x.lower() in s.lower());chars=len(compact(s));item['checks'].append({'path':rel,'kind':'asset','chars':chars,'signals':hits})
                    if chars<420 or hits<5:failures.append({'responsibility':name,'path':rel,'reason':'ASSET_OPERATIONAL_SHELL_RISK','chars':chars,'signals':hits})
        details.append(item)
    if failures:blocks.append('OPERATIONAL_CLOSURE_GAP')
    report={'version':'V5.4_OPERATIONAL_CLOSURE_AUDIT','stage':a.stage,'book_type':book_type or None,'reader_contract':str(rtc_p),'operational_closure_contract':str(con_p),'responsibilities':details,'failures':failures,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
