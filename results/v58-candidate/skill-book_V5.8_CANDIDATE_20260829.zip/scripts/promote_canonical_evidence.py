#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,tempfile
from datetime import datetime,timezone
from pathlib import Path

PASS_DECISIONS={'PASS','PASS_RUNTIME_ACCEPTANCE','PASS_REVIEW_NO_MACHINE_TRIGGER'}
def sha(b):return hashlib.sha256(b).hexdigest()
def atomic_write(path:Path,data:bytes):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--candidate',required=True);ap.add_argument('--canonical',required=True);ap.add_argument('--state',required=True);ap.add_argument('--gate',required=True);ap.add_argument('--run-id',required=True);a=ap.parse_args()
    cand=Path(a.candidate);canonical=Path(a.canonical);state=Path(a.state)
    obj=json.loads(cand.read_text(encoding='utf-8'));decision=str(obj.get('decision','')).upper()
    if decision not in PASS_DECISIONS:raise SystemExit('CANDIDATE_EVIDENCE_NOT_PASS')
    raw=cand.read_bytes();candidate_sha=sha(raw);ts=datetime.now(timezone.utc).isoformat()
    obj['canonical_evidence']={'gate':a.gate,'run_id':a.run_id,'promoted_at':ts,'candidate_sha256':candidate_sha}
    out=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8');atomic_write(canonical,out);canon_sha=sha(out)
    try:st=json.loads(state.read_text(encoding='utf-8')) if state.exists() else {}
    except Exception:st={}
    entries=st.setdefault('entries',{});entries[a.gate]={'canonical_path':canonical.as_posix(),'run_id':a.run_id,'promoted_at':ts,'candidate_sha256':candidate_sha,'canonical_sha256':canon_sha,'decision':decision}
    st['version']='V5.4_CANONICAL_EVIDENCE_STATE';atomic_write(state,(json.dumps(st,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'gate':a.gate,'canonical_path':canonical.as_posix(),'canonical_sha256':canon_sha,'run_id':a.run_id,'decision':'PROMOTED'},ensure_ascii=False))
    return 0
if __name__=='__main__':raise SystemExit(main())
