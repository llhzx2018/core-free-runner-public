#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,random,re
from pathlib import Path
from freeze_integrity_audit import audit as freeze_audit

VERSION='V5.5_POSTFREEZE_FROZEN_HOLDOUT_AUDIT'
SALT='SB55-POSTFREEZE-FROZEN-HOLDOUT-V1'
TEXT_EXT={'.md','.markdown','.txt','.html','.htm','.csv','.tsv'}
CUE_GROUPS={
 'judgment':('判断','决策','规则','条件','阈值','基线','信号','观察','样本','定义','证据','decision','rule','condition','baseline','signal','observation','sample','definition','evidence'),
 'action':('执行','步骤','操作','输入','输出','提交','请求','运行','使用','选择','action','step','input','output','submit','request','run','use','choose'),
 'validation':('验证','验收','检查','预期','状态','测试','证据','数量','定义','validation','acceptance','check','expected','status','test','inspect','evidence','count','definition'),
 'recovery':('失败','错误','恢复','回滚','重试','纠错','排查','诊断','failure','error','recovery','rollback','retry','troubleshoot','diagnose'),
}

def read_json(p:Path):
 try:return json.loads(p.read_text(encoding='utf-8'))
 except Exception:return None

def compact(s):return re.sub(r'\s+','',s)
def bounded(parts,idx,target=300,max_parts=3):
 chosen=[idx];step=1
 while parts and len(chosen)<max_parts and len(compact('\n\n'.join(parts[i] for i in sorted(chosen))))<target:
  cand=[]
  if idx-step>=0:cand.append(idx-step)
  if idx+step<len(parts):cand.append(idx+step)
  if not cand:break
  for j in cand:
   if j not in chosen and len(chosen)<max_parts:chosen.append(j)
  step+=1
 return '\n\n'.join(parts[i] for i in sorted(chosen)) if parts else ''

def windows_for(path:Path):
 s=path.read_text(encoding='utf-8',errors='replace')
 parts=[];cur=[]
 for line in s.splitlines():
  if re.match(r'^##\s+',line) or re.match(r'^<h[2-4][^>]*>',line,re.I):
   if cur and len(compact('\n'.join(cur)))>=40:parts.append('\n'.join(cur))
   cur=[line]
  elif cur:cur.append(line)
 if cur and len(compact('\n'.join(cur)))>=40:parts.append('\n'.join(cur))
 if not parts:parts=[x.strip() for x in re.split(r'\n\s*\n',s) if len(compact(x))>=40]
 is_asset=any(x in path.parts for x in ('templates','operator_reference','references'))
 max_parts=7 if is_asset else 3
 return [bounded(parts,i,300,max_parts) for i in range(len(parts))]

def local_value(s,full_text=None):
 chars=len(compact(s));groups=[k for k,words in CUE_GROUPS.items() if any(w.lower() in s.lower() for w in words)];reasons=[]
 full=full_text if full_text is not None else s
 local_h2=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in s.splitlines() if x.strip())
 full_h2=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in full.splitlines() if x.strip())
 form_margin=(len(compact(full))>=700 and full_h2>=7 and chars>=150 and local_h2>=5 and len(groups)>=3)
 if chars<180 and not form_margin:reasons.append('TOO_THIN')
 if len(groups)<2:reasons.append('LOW_LOCAL_VALUE_DIMENSION_COUNT')
 return not reasons,chars,groups,reasons

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new);blocks=[]
 fi=freeze_audit(root)
 if fi.get('decision')!='PASS_FREEZE_INTEGRITY':blocks.append('FREEZE_INTEGRITY_NOT_CLOSED')
 fr=read_json(root/'evidence'/'freeze_record.json') or {};tree=str(fr.get('reader_tree_sha256') or '')
 candidates=[]
 for row in fr.get('reader_assets',[]) if isinstance(fr,dict) else []:
  if not isinstance(row,dict):continue
  rel=str(row.get('path',''));p=root/rel
  if not p.is_file() or p.suffix.lower() not in TEXT_EXT:continue
  for i,sec in enumerate(windows_for(p)):
   candidates.append((rel,i,sec,p.read_text(encoding='utf-8',errors='replace')))
 if len(candidates)<4:blocks.append('LOCAL_FROZEN_HOLDOUT_WINDOW_COUNT_LOW')
 seed_commitment=hashlib.sha256((SALT+'|'+tree).encode()).hexdigest() if tree else None
 rows=[]
 if len(candidates)>=4 and not blocks:
  rng=random.Random(int(seed_commitment[:16],16));selected=(rng.sample(candidates,12) if len(candidates)>=12 else [rng.choice(candidates) for _ in range(12)])
  for rel,idx,sec,full in selected:
   ok,chars,groups,reasons=local_value(sec,full);rows.append({'path':rel,'window_index':idx,'chars':chars,'value_dimensions':groups,'result':'PASS' if ok else 'FAIL','reasons':reasons})
 if any(x['result']!='PASS' for x in rows):blocks.append('LOCAL_FROZEN_HOLDOUT_FAIL')
 decision='BLOCK' if blocks else 'PASS_LOCAL_POSTFREEZE_HOLDOUT'
 report={'version':VERSION,'new':str(root),'strength':'LOCAL_FROZEN_NON_OPAQUE','freeze_tree_sha256':tree or None,'seed_commitment':('sha256:'+seed_commitment) if seed_commitment else None,'candidate_window_count':len(candidates),'sample_count':len(rows),'failed_count':sum(x['result']!='PASS' for x in rows),'context_policy':'CHAPTER_MAX_3_ASSET_MAX_7_STRUCTURED_FORM_MARGIN','samples':rows,'freeze_integrity':fi,'blocks':blocks,'decision':decision}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
