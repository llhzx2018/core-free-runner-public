#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,random,re
from pathlib import Path
TEXT_EXT={'.md','.markdown','.txt','.csv','.tsv'}
CUES=('判断','规则','条件','输入','输出','步骤','执行','验证','验收','错误','失败','恢复','重试','完成','decision','rule','input','output','step','validation','failure','retry','completion','example','示例')
def cid(p):
 m=re.match(r'^0*(\d{1,3})[_ .-]',p.name)
 if m:return int(m.group(1))
 m=re.search(r'第\s*0*(\d{1,3})\s*章',p.stem);return int(m.group(1)) if m else None
def chapters(root):
 out=[]
 for d in (root/'chapters',root/'manuscript',root/'book'/'chapters'):
  if d.exists():out += [p for p in d.glob('*.md') if cid(p)]
 return sorted(set(out))
def templates(root):
 d=root/'templates';return sorted(p for p in d.iterdir() if p.is_file() and p.suffix.lower() in TEXT_EXT) if d.exists() else []
def refs(root):
 out=[]
 for d in (root/'operator_reference',root/'references'/'operator',root/'references'/'operator_reference'):
  if d.exists():out += [p for p in d.glob('*.md')]
 return sorted(set(out))
def compact(s):return re.sub(r'\s+','',s)
def split_h2(s):
 parts=[];cur=[]
 for line in s.splitlines():
  if re.match(r'^##\s+',line):
   if cur:parts.append('\n'.join(cur))
   cur=[line]
  elif cur:cur.append(line)
 if cur:parts.append('\n'.join(cur))
 return [x for x in parts if compact(x)]
def paragraphs(s):return [x.strip() for x in re.split(r'\n\s*\n',s) if len(compact(x.strip()))>=40]
def bounded(parts,idx,target=320,max_parts=3):
 if not parts:return ''
 chosen=[idx];step=1
 while len(chosen)<max_parts and len(compact('\n\n'.join(parts[i] for i in sorted(chosen))))<target:
  cand=[]
  if idx-step>=0:cand.append(idx-step)
  if idx+step<len(parts):cand.append(idx+step)
  if not cand:break
  for j in cand:
   if j not in chosen and len(chosen)<max_parts:chosen.append(j)
  step+=1
 return '\n\n'.join(parts[i] for i in sorted(chosen))
def local_value(chunk,kind,full_text=None):
 s=compact(chunk);low=chunk.lower();reasons=[];floor=180 if kind=='chapter' else 220
 hits=sum(1 for x in CUES if x.lower() in low);need=2 if kind=='chapter' else 3
 source=full_text if full_text is not None else chunk
 full_lines=[x for x in source.splitlines() if x.strip()]
 full_structure=sum(bool(re.match(r'^(?:#{2,4}\s+|\s*[-*]\s+|\s*\d+[.)]\s+|\|.*\|$)',x)) for x in full_lines) if kind!='chapter' else 0
 local_h2=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in chunk.splitlines() if x.strip()) if kind!='chapter' else 0
 full_h2=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in source.splitlines() if x.strip()) if kind!='chapter' else 0
 form_margin=(kind!='chapter' and len(compact(source))>=700 and full_h2>=7 and len(s)>=150 and local_h2>=5 and hits>=need+2)
 if len(s)<floor and not form_margin:reasons.append(f'TOO_THIN:{len(s)}<{floor}')
 if hits<need:reasons.append(f'LOW_ACTION_DECISION_CUES:{hits}<{need}')
 if kind!='chapter' and full_structure<2:reasons.append(f'LOW_TOOL_STRUCTURE:{full_structure}<2')
 return not reasons,reasons
def sample(root,seed_base):
 pools=[('chapter',p) for p in chapters(root)]+[('template',p) for p in templates(root)]+[('reference',p) for p in refs(root)];rows=[]
 if not pools:return []
 for i in range(12):
  r=random.Random(seed_base+i);kind,p=r.choice(pools);text=p.read_text(encoding='utf-8',errors='replace')
  parts=split_h2(text) if kind=='chapter' else (split_h2(text) or paragraphs(text))
  if not parts:chunk=text;idx=0;max_parts=1
  else:
   idx=r.randrange(len(parts));max_parts=3 if kind=='chapter' else 7;chunk=bounded(parts,idx,320,max_parts)
  ok,why=local_value(chunk,kind,text);rows.append({'seed':seed_base+i,'kind':kind,'path':p.relative_to(root).as_posix(),'window_index':idx,'bounded_parts_max':max_parts,'chars':len(compact(chunk)),'result':'PASS' if ok else 'FAIL','reasons':why})
 return rows
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--phase',choices=['GENERATION'],required=True);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new)
 rows=sample(root,49100);fails=[x for x in rows if x['result']!='PASS'];blocks=[]
 if not rows:blocks.append('NO_READER_PATHS')
 if fails:blocks.append('PREFREEZE_RANDOM_OPEN_FAIL')
 report={'version':'V5.5_PREFREEZE_RANDOM_OPEN_AUDIT','phase':a.phase,'context_policy':'CHAPTER_MAX_3_ASSET_MAX_7_STRUCTURED_FORM_MARGIN','samples':len(rows),'failed':len(fails),'details':rows,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
