#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from freeze_integrity_audit import build_record

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--book-id',default='');ap.add_argument('--book-title',default='');ap.add_argument('--out');a=ap.parse_args();root=Path(a.new);out=Path(a.out) if a.out else root/'evidence'/'freeze_record.json';out.parent.mkdir(parents=True,exist_ok=True)
 r=build_record(root,a.book_id,a.book_title);out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(r,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
