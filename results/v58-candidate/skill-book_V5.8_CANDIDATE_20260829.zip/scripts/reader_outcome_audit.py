#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, statistics
from collections import Counter
from pathlib import Path

INTERNAL_MARKERS=(
    '本轮不复制旧正文表达','补回旧版高价值职责','审阅时特别检查',
    'post-generation review required','repair note','audit instruction'
)
FEEDBACK_HEADINGS=('参考判断','参考答案','答案解析','为什么错','纠错','错误诊断','重试','re-check','quality bar','worked answer','improved output')
PENDING_EVIDENCE=('post-generation review required','pending review','review required','not reviewed','待审阅','待复核')
EXERCISE_MARKERS=('迁移练习','guided practice','independent transfer','阶段挑战','诊断任务')
RHYTHM_MOTIFS=('四个常见误判','决策树','迁移练习','完成产物后做四项自检','错误路径通常是')
TEXT_EXT={'.md','.markdown','.txt','.csv','.tsv'}

def txt(p:Path): return p.read_text(encoding='utf-8',errors='replace')
def chapter_id(p:Path):
    m=re.match(r'^0*(\d{1,3})[_ .-]',p.name)
    if m:return int(m.group(1))
    m=re.search(r'第\s*0*(\d{1,3})\s*章',p.stem)
    return int(m.group(1)) if m else None

def manuscripts(root:Path):
    out=[]
    for d in (root/'manuscript',root/'chapters',root/'book'/'chapters'):
        if d.exists(): out += [p for p in d.glob('*.md') if chapter_id(p)]
    return sorted(set(out),key=lambda p:(chapter_id(p) or 999,p.name))
def templates(root:Path):
    d=root/'templates'; return sorted(p for p in d.iterdir() if p.is_file() and p.suffix.lower() in TEXT_EXT) if d.exists() else []
def refs(root:Path):
    out=[]
    for d in (root/'operator_reference',root/'operator',root/'references'/'operator',root/'references'/'operator_reference'):
        if d.exists(): out += list(d.glob('*.md'))
    return sorted(set(out))

def norm_para(s:str):
    s=' '.join(s.split()).lower()
    s=re.sub(r'`[^`]+`','<id>',s)
    s=re.sub(r'\*\*.*?\*\*','**topic**',s)
    s=re.sub(r'\d+','<n>',s)
    s=re.sub(r'第\s*<n>\s*章','第<n>章',s)
    return s

def repeated_paragraph_skeletons(chs):
    per=[]
    for p in chs:
        ss=set()
        for para in re.split(r'\n\s*\n',txt(p)):
            n=norm_para(para)
            if len(n)>=140:ss.add(n)
        per.append(ss)
    c=Counter(x for s in per for x in s)
    threshold=max(4,(len(per)+1)//2)
    common={x:n for x,n in c.items() if n>=threshold}
    return common,threshold

def feedback_by_chapter(root:Path,chs):
    tm=templates(root); rf=refs(root)
    out=[]
    for p in chs:
        i=chapter_id(p)
        assets=[p]+[x for x in tm+rf if chapter_id(x)==i]
        joined='\n'.join(txt(x).lower() for x in assets)
        hits=[h for h in FEEDBACK_HEADINGS if h.lower() in joined]
        # Require explicit feedback/correction language, not generic Failure Recovery alone.
        out.append({'chapter':i,'feedback_signals':hits,'pass':bool(hits)})
    return out

def exercise_stats(chs):
    rows=[]
    generic_phrase='不要先问“能不能做”'
    for p in chs:
        t=txt(p); n=sum(t.count(m) for m in EXERCISE_MARKERS)
        rows.append({'chapter':chapter_id(p),'exercise_markers':n,'generic_prompt_occurrences':t.count(generic_phrase)})
    return rows

def preservation_check(path:Path|None):
    if not path or not path.exists():return {'provided':False,'false_passes':[],'unspecific_mappings':[]}
    try:data=json.loads(txt(path))
    except Exception:return {'provided':True,'parse_error':True,'false_passes':['PARSE_ERROR'],'unspecific_mappings':['PARSE_ERROR']}
    assets=data.get('old_assets',data.get('assets',[])) if isinstance(data,dict) else []
    bad=[]; vague=[]
    for a in assets:
        if not isinstance(a,dict):continue
        old_asset=str(a.get('old') or a.get('old_asset') or '')
        status=str(a.get('status','')).upper(); ev=str(a.get('evidence','')).lower()
        mapping=str(a.get('mapping') or a.get('new') or a.get('new_asset') or '').strip()
        if status in {'PRESERVED','IMPROVED','SUPERSEDED'} and any(x in ev for x in PENDING_EVIDENCE):
            bad.append({'old':old_asset,'status':status,'evidence':a.get('evidence')})
        # Reader-value assets require a concrete target path, not a directory/category or a promise to review later.
        reader_asset = old_asset.startswith(('manuscript/','templates/','appendices/','operator_reference/','workbook/'))
        if reader_asset and status in {'PRESERVED','IMPROVED','SUPERSEDED'}:
            low=mapping.lower()
            path_like=bool(re.search(r'[^/\\]+\.(?:md|markdown|txt|csv|tsv|json|ya?ml)$',mapping,re.I))
            vague_words=('functional equivalence review','mapped delivery asset','package metadata','review','待审','待复核','assets;')
            if (not mapping) or (not path_like) or any(w in low for w in vague_words):
                vague.append({'old':old_asset,'status':status,'mapping':mapping})
    return {'provided':True,'asset_count':len(assets),'false_passes':bad,'unspecific_mappings':vague}

def _asset_dims(text:str):
    low=text.lower()
    groups={
      'context_task':('目标','场景','purpose','context'),
      'input_evidence':('输入','证据','input','evidence'),
      'decision_rule':('判断','决策','规则','decision','rule'),
      'execution_steps':('步骤','执行','step','execute'),
      'validation_acceptance':('验证','验收','validation','acceptance','pass','fail'),
      'failure_recovery':('错误','失败','恢复','重试','error','failure','recovery','retry'),
      'completion':('完成条件','completion','quality bar'),
      'tracking_log':('记录','日志','baseline','metric','log','date'),
      'change_control':('版本','变更','冻结','version','change','freeze'),
    }
    return {k for k,vals in groups.items() if any(v in low for v in vals)}

def _preservation_mapping(path:Path|None):
    if not path or not path.exists():return {}
    try:data=json.loads(txt(path))
    except Exception:return {}
    assets=data.get('old_assets',data.get('assets',[])) if isinstance(data,dict) else []
    out={}
    for a in assets:
        if not isinstance(a,dict):continue
        old=str(a.get('old') or a.get('old_asset') or '').strip();new=str(a.get('mapping') or a.get('new') or a.get('new_asset') or '').strip()
        if old and new:out[old]=new
    return out

def practical_asset_fidelity(old:Path|None,new:Path,preservation_ledger:Path|None=None):
    if not old:return {'provided':False,'regressions':[]}
    mapping=_preservation_mapping(preservation_ledger)
    old_assets=[]
    for d in (old/'templates',old/'operator_reference',old/'references'/'operator',old/'workbook'):
        if d.exists():old_assets += [p for p in d.rglob('*') if p.is_file() and p.suffix.lower() in TEXT_EXT]
    rows=[];regress=[]
    for op in sorted(set(old_assets)):
        rel=op.relative_to(old).as_posix();target=mapping.get(rel)
        np=None;mode='mapping' if target else 'same_name'
        if target:
            q=new/target
            if q.is_file():np=q
        if np is None:
            candidates=[p for p in templates(new)+refs(new) if p.name==op.name]
            if candidates:np=candidates[0]
        ot=txt(op);nt=txt(np) if np else '';od=_asset_dims(ot);nd=_asset_dims(nt)
        dim_ratio=(len(od & nd)/len(od)) if od else 1.0;char_ratio=(len(nt)/len(ot)) if ot else 1.0
        row={'old_asset':rel,'new_asset':np.relative_to(new).as_posix() if np else None,'resolution':mode,'old_chars':len(ot),'new_chars':len(nt),'char_ratio':round(char_ratio,3),'old_dimensions':sorted(od),'new_dimensions':sorted(nd),'dimension_retention':round(dim_ratio,3)}
        rows.append(row)
        if len(ot)>=1200 and (np is None or dim_ratio<0.70 or char_ratio<0.45):regress.append(row)
    return {'provided':True,'mapping_aware_rows':rows,'regressions':regress}

def workbook_status(root:Path):
    paths=[]
    direct=root/'WORKBOOK.md'
    if direct.is_file():paths.append(direct)
    d=root/'workbook'
    if d.exists():paths += [p for p in d.rglob('*') if p.is_file() and p.suffix.lower() in TEXT_EXT]
    for name in ('MANIFEST.json','01_MANIFEST.json','manifest.json'):
        mp=root/name
        if not mp.exists():continue
        try:m=json.loads(txt(mp))
        except Exception:continue
        vals=[]
        for key in ('WORKBOOK_PATH','workbook_path'):
            if isinstance(m,dict) and m.get(key):vals.append(m.get(key))
        ra=m.get('reader_assets',{}) if isinstance(m,dict) else {}
        if isinstance(ra,dict) and ra.get('workbook_path'):vals.append(ra.get('workbook_path'))
        for rel in vals:
            q=root/str(rel)
            if q.is_file():paths.append(q)
    paths=sorted(set(paths))
    if not paths:return {'present':False,'status':'NOT_RUN','paths':[]}
    text='\n'.join(txt(p) for p in paths);statuses=re.findall(r'\b(PASS|FAIL|BLOCK|NOT_RUN)\b',text);c=Counter(statuses)
    if c['PASS'] and not (c['FAIL'] or c['BLOCK'] or c['NOT_RUN']):status='PASS'
    elif c['FAIL'] or c['BLOCK']:status='FAIL'
    else:status='NOT_RUN'
    return {'present':True,'paths':[p.relative_to(root).as_posix() for p in paths],'counts':dict(c),'status':status}

def external_gate_report(path_value, expected_pass):
    if not path_value:return {'provided':False,'decision':'NOT_RUN'}
    p=Path(path_value)
    if not p.exists():return {'provided':False,'decision':'MISSING'}
    try:
        data=json.loads(txt(p));decision=str(data.get('decision','UNKNOWN')).upper() if isinstance(data,dict) else 'UNKNOWN'
        return {'provided':True,'decision':decision,'pass':decision in expected_pass,'report':data}
    except Exception:return {'provided':True,'decision':'PARSE_ERROR','pass':False}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--new',required=True)
    ap.add_argument('--old')
    ap.add_argument('--preservation-ledger')
    ap.add_argument('--execution-evidence')
    ap.add_argument('--real-reader-evidence')
    ap.add_argument('--adequacy-report')
    ap.add_argument('--postdraft-baseline-report')
    ap.add_argument('--runtime-acceptance-report')
    ap.add_argument('--freeze-integrity-report')
    ap.add_argument('--json')
    a=ap.parse_args(); new=Path(a.new); old=Path(a.old) if a.old else None
    chs=manuscripts(new); blocks=[]
    marker_rows=[]
    for m in INTERNAL_MARKERS:
        n=sum(txt(p).lower().count(m.lower()) for p in chs)
        if n:marker_rows.append({'marker':m,'occurrences':n,'chapters':sum(m.lower() in txt(p).lower() for p in chs)})
    if marker_rows:blocks.append('READER_FACING_SCAFFOLD_LEAK')

    common,threshold=repeated_paragraph_skeletons(chs)
    common_rows=sorted(({'coverage':n,'skeleton':s[:260]} for s,n in common.items()),key=lambda x:x['coverage'],reverse=True)
    motif_rows=[]
    for m in RHYTHM_MOTIFS:
        cov=sum(m.lower() in txt(p).lower() for p in chs)
        motif_rows.append({'motif':m,'chapter_coverage':cov})
    systemic_motifs=[x for x in motif_rows if chs and x['chapter_coverage']/len(chs)>=.75]
    if len(common_rows)>=3 or len(systemic_motifs)>=3:blocks.append('PEDAGOGICAL_RHYTHM_DRIFT')

    ex=exercise_stats(chs)
    med=statistics.median([x['exercise_markers'] for x in ex]) if ex else 0
    generic_ch=sum(x['generic_prompt_occurrences']>0 for x in ex)
    if chs and med>3 and generic_ch/len(chs)>=.5:blocks.append('PRACTICE_QUANTITY_OVERLOAD')

    fb=feedback_by_chapter(new,chs)
    fb_fail=[x for x in fb if not x['pass']]
    if chs and len(fb_fail)/len(chs)>.25:blocks.append('TRAIN_FEEDBACK_GAP')

    pres=preservation_check(Path(a.preservation_ledger) if a.preservation_ledger else None)
    if pres.get('false_passes'):blocks.append('PRESERVATION_STATE_FALSE_PASS')
    if pres.get('unspecific_mappings'):blocks.append('PRESERVATION_MAPPING_NOT_SPECIFIC')

    fidelity=practical_asset_fidelity(old,new,Path(a.preservation_ledger) if a.preservation_ledger else None)
    if fidelity.get('regressions'):blocks.append('PRACTICAL_ASSET_FIDELITY_REGRESSION')

    adequacy=external_gate_report(a.adequacy_report,{'PASS'})
    if a.adequacy_report and not adequacy.get('pass'):blocks.append('ADEQUACY_NOT_CLOSED')
    baseline_diff=external_gate_report(a.postdraft_baseline_report,{'PASS','PASS_REVIEW_NO_MACHINE_TRIGGER','PASS_NOT_APPLICABLE_NEW_BOOK'})
    if a.postdraft_baseline_report and not baseline_diff.get('pass'):blocks.append('POST_DRAFT_BASELINE_DIFFERENTIAL')

    runtime_acceptance={'provided':False,'decision':'NOT_RUN'}
    if a.runtime_acceptance_report:
        rp=Path(a.runtime_acceptance_report); runtime_acceptance['provided']=rp.exists()
        if rp.exists():
            try:
                rd=json.loads(txt(rp))
                if isinstance(rd,dict): runtime_acceptance=rd
            except Exception:
                runtime_acceptance={'provided':True,'decision':'BLOCK','error':'PARSE_ERROR'}
        if str(runtime_acceptance.get('decision','')).upper()!='PASS_RUNTIME_ACCEPTANCE':
            blocks.append('RUNTIME_ACCEPTANCE_NOT_CLOSED')

    freeze_path=Path(a.freeze_integrity_report) if a.freeze_integrity_report else (new/'evidence'/'freeze_integrity_audit.json' if (new/'evidence'/'freeze_integrity_audit.json').exists() else None)
    freeze_integrity=external_gate_report(str(freeze_path) if freeze_path else None,{'PASS_FREEZE_INTEGRITY'})
    if freeze_integrity.get('provided') and not freeze_integrity.get('pass'):blocks.append('FREEZE_INTEGRITY_NOT_CLOSED')

    wb=workbook_status(new)
    execution={'provided':False,'status':'NOT_RUN'}
    if a.execution_evidence:
        ep=Path(a.execution_evidence);execution={'provided':ep.exists(),'status':'NOT_RUN'}
        if ep.exists():
            try:
                ed=json.loads(txt(ep));execution=ed if isinstance(ed,dict) else execution
            except Exception: execution={'provided':True,'status':'BLOCK','error':'PARSE_ERROR'}
        execution['status']=str(execution.get('status','NOT_RUN')).upper()

    real_reader={'provided':False,'READ_CONTINUE':'NOT_RUN','LEARN_TRANSFER':'NOT_RUN','TRAIN_FEEDBACK':'NOT_RUN'}
    if a.real_reader_evidence:
        rp=Path(a.real_reader_evidence); real_reader['provided']=rp.exists()
        if rp.exists():
            try:
                rd=json.loads(txt(rp))
                if isinstance(rd,dict):
                    for k in ('READ_CONTINUE','LEARN_TRANSFER','TRAIN_FEEDBACK'):
                        real_reader[k]=str(rd.get(k,'NOT_RUN')).upper()
                    real_reader['source_type']=str(rd.get('source_type','REAL_READER')).upper()
                    real_reader['evidence_boundary']=rd.get('evidence_boundary')
            except Exception:
                real_reader={'provided':True,'READ_CONTINUE':'BLOCK','LEARN_TRANSFER':'BLOCK','TRAIN_FEEDBACK':'BLOCK','error':'PARSE_ERROR'}
    if real_reader.get('provided') and 'REAL_READER' not in str(real_reader.get('source_type','')).upper():
        blocks.append('REAL_READER_EVIDENCE_CATEGORY_ERROR')
        real_reader['READ_CONTINUE']='BLOCK';real_reader['LEARN_TRANSFER']='BLOCK';real_reader['TRAIN_FEEDBACK']='BLOCK'

    read_status='FAIL' if ('READER_FACING_SCAFFOLD_LEAK' in blocks or 'PEDAGOGICAL_RHYTHM_DRIFT' in blocks) else (real_reader['READ_CONTINUE'] if real_reader['provided'] else 'PASS_SIMULATED_ONLY')
    learn_status=real_reader['LEARN_TRANSFER'] if real_reader['provided'] else 'NOT_RUN_REAL_READER'
    train_status='FAIL' if ('TRAIN_FEEDBACK_GAP' in blocks or 'PRACTICE_QUANTITY_OVERLOAD' in blocks) else (real_reader['TRAIN_FEEDBACK'] if real_reader['provided'] else 'PASS_STRUCTURE_ONLY')
    reader={
      'READ_CONTINUE':read_status,
      'LEARN_TRANSFER':learn_status,
      'TRAIN_FEEDBACK':train_status,
      'DO_VERIFIED_OUTPUT':execution['status']
    }
    report={
      'version':'V5.4_READER_OUTCOME_AUDIT',
      'new':str(new),'old':str(old) if old else None,'chapters':len(chs),
      'reader_outcome':reader,
      'reader_facing_markers':marker_rows,
      'repeated_paragraph_threshold_chapters':threshold,
      'repeated_long_skeleton_count':len(common_rows),'repeated_long_skeletons':common_rows[:20],'rhythm_motifs':motif_rows,'systemic_rhythm_motifs':systemic_motifs,
      'practice':{'median_exercise_markers_per_chapter':med,'generic_prompt_chapter_coverage':generic_ch,'chapters':ex},
      'feedback':{'failed_chapters':[x['chapter'] for x in fb_fail],'details':fb},
      'preservation':pres,
      'practical_asset_fidelity':fidelity,
      'adequacy_gate':adequacy,
      'postdraft_baseline_gate':baseline_diff,
      'runtime_acceptance_gate':runtime_acceptance,
      'reader_workbook_observation':wb,'freeze_integrity':freeze_integrity,
      'forward_execution_evidence':execution,
      'real_reader_forward_evidence':real_reader,
    }
    closure_blocks=[]
    if reader['READ_CONTINUE']!='PASS': closure_blocks.append('REAL_READER_READ_NOT_CLOSED')
    if reader['LEARN_TRANSFER']!='PASS': closure_blocks.append('REAL_READER_LEARN_NOT_CLOSED')
    if reader['TRAIN_FEEDBACK']!='PASS': closure_blocks.append('REAL_READER_TRAIN_NOT_CLOSED')
    if execution['status']!='PASS': closure_blocks.append('DO_FORWARD_EXECUTION_NOT_CLOSED')
    report['blocks']=blocks+closure_blocks
    report['decision']='BLOCK_REPLACEMENT' if report['blocks'] else 'PASS_READER_OUTCOME_CLOSURE'
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 1 if report['decision'].startswith('BLOCK') else 0
if __name__=='__main__':raise SystemExit(main())
