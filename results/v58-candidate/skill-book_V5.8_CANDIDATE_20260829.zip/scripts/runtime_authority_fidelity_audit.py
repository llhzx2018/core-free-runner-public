#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

RID='SB58-RUNTIME-CONTRACT-BF41D2E7'
VERSION='5.8'
CORE_CANONICAL_INPUTS=(
 'evidence/runtime_entry_receipt.json',
 'evidence/reader_transformation_contract.json',
 'evidence/baseline_applicability_pre_draft.json',
 'evidence/full_book_substance_contract.json',
 'evidence/full_book_substance_audit.json',
 'evidence/continuous_reading_audit.json',
 'evidence/training_feedback_pre_freeze.json',
 'evidence/operational_closure_pre_freeze.json',
 'evidence/reader_facing_packaging_audit.json',
 'evidence/freeze_record.json',
 'evidence/freeze_integrity_audit.json',
 'evidence/reader_transfer_contract.json',
 'evidence/runtime_acceptance_audit.json',
)
RETAINED_RUNTIME_INPUTS=(
 'evidence/practical_asset_depth_contract.json',
 'evidence/practical_asset_depth_audit.json',
 'evidence/reader_transfer_proxy.json',
 'evidence/reader_transfer_audit.json',
)
OPTIMISTIC=('PASS','ACCEPT','READY','REPLACE','PROMOTE')

def read_json(p:Path):
 try:return json.loads(p.read_text(encoding='utf-8'))
 except Exception:return None

def norm_key(k):return re.sub(r'[^a-z0-9]+','',str(k).lower())
def mget(obj,*keys,default=None):
 if not isinstance(obj,dict):return default
 idx={norm_key(k):v for k,v in obj.items()}
 for k in keys:
  nk=norm_key(k)
  if nk in idx:return idx[nk]
 return default

def manifest(root:Path):
 for n in ('MANIFEST.json','manifest.json','01_MANIFEST.json'):
  p=root/n
  if p.exists():return p,read_json(p)
 hits=list(root.glob('*MANIFEST*.json'))
 return (hits[0],read_json(hits[0])) if hits else (None,None)

def optimistic(v):
 s=str(v or '').upper()
 return any(x in s for x in OPTIMISTIC) and not any(x in s for x in ('BLOCK','NOT_RUN','NOT AUTHORIZED','NOT_AUTHORIZED'))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new)
 blocks=[];warnings=[];sp=root/'evidence'/'runtime_authority_status.json';status=read_json(sp) if sp.exists() else None
 mp,m=manifest(root);m=m if isinstance(m,dict) else {}
 if not mp or not isinstance(m,dict):blocks.append('ROOT_MANIFEST_MISSING_OR_INVALID')
 if not isinstance(status,dict):
  blocks.append('RUNTIME_AUTHORITY_STATUS_MISSING_OR_INVALID');status={}
 rid=str(mget(status,'runtime_contract_id',default='') or '')
 ver=str(mget(status,'declared_skill_version','skill_version',default='') or '')
 mode=str(mget(status,'authority_mode',default='') or '').upper()
 execution=str(mget(status,'machine_execution_status','bundled_verifier_execution',default='') or '').upper()
 claim=str(mget(status,'runtime_acceptance_claim','acceptance_claim',default='') or '').upper()
 declared=mget(status,'canonical_inputs','mandatory_canonical_inputs',default=[])
 declared=[str(x) for x in declared] if isinstance(declared,list) else []
 if rid!=RID:blocks.append('RUNTIME_AUTHORITY_CONTRACT_ID_MISMATCH')
 if ver!=VERSION:blocks.append('RUNTIME_AUTHORITY_SKILL_VERSION_MISMATCH')
 if mode not in {'BUNDLED_VERIFIER','EXTERNAL_VERIFIER_PENDING'}:blocks.append('RUNTIME_AUTHORITY_MODE_INVALID')
 if execution not in {'EXECUTED','NOT_RUN'}:blocks.append('RUNTIME_AUTHORITY_MACHINE_EXECUTION_STATUS_INVALID')
 required=CORE_CANONICAL_INPUTS + RETAINED_RUNTIME_INPUTS
 missing_decl=[p for p in required if p not in declared]
 if missing_decl:blocks.append('CANONICAL_RUNTIME_INPUT_DECLARATION_INCOMPLETE')
 missing_actual=[p for p in required if not (root/p).is_file()]
 if missing_actual:blocks.append('CANONICAL_RUNTIME_INPUTS_MISSING')
 if execution=='NOT_RUN':
  if mode!='EXTERNAL_VERIFIER_PENDING':blocks.append('NOT_RUN_REQUIRES_EXTERNAL_VERIFIER_PENDING')
  if claim not in {'NOT_RUN','BLOCK','BLOCK_PENDING_EXTERNAL_VERIFIER'}:blocks.append('NOT_RUN_CANNOT_CLAIM_RUNTIME_PASS')
  test_mode=str(mget(m,'TEST_MODE','GENERATION_MODE','test_mode','generation_mode',default='') or '').upper()
  if 'SEALED_STANDALONE' in test_mode and not (root/'evidence'/'freeze_record.json').is_file():blocks.append('DEFERRED_SEALED_REQUIRES_FIRST_FREEZE_RECORD')
 if execution=='EXECUTED':
  if mode!='BUNDLED_VERIFIER':blocks.append('EXECUTED_REQUIRES_BUNDLED_VERIFIER_AUTHORITY')
  if claim not in {'PASS_RUNTIME_ACCEPTANCE','BLOCK'}:blocks.append('EXECUTED_RUNTIME_CLAIM_INVALID')
 manifest_exec=str(mget(m,'machine_execution_status','runtime_machine_execution_status',default='') or '').upper()
 manifest_final=str(mget(m,'FINAL_DECISION','final_decision',default='') or '').upper()
 if manifest_exec and execution and manifest_exec!=execution:blocks.append('MANIFEST_MACHINE_EXECUTION_STATUS_DRIFT')
 if execution=='NOT_RUN' and optimistic(manifest_final):blocks.append('RUNTIME_AUTHORITY_FALSE_GREEN')
 alt=[]
 for rel in ('AUDITS/RUNTIME_ACCEPTANCE.json','audit/RUNTIME_ACCEPTANCE.json','audit/runtime_acceptance.json','audit/run_audit.json'):
  p=root/rel
  if p.is_file():
   d=read_json(p);dec=str(mget(d or {},'decision','status','final_decision',default='') or '')
   alt.append({'path':rel,'decision':dec or None})
   if optimistic(dec) and execution!='EXECUTED':blocks.append('WEAK_ALTERNATE_RUNTIME_AUDIT_CANNOT_AUTHORIZE')
 blocks=list(dict.fromkeys(blocks))
 report={'version':'V5.8_RUNTIME_AUTHORITY_FIDELITY_AUDIT','runtime_contract_id':RID,'new':str(root),'status_path':str(sp),'manifest':str(mp) if mp else None,'authority_mode':mode or None,'machine_execution_status':execution or None,'runtime_acceptance_claim':claim or None,'declared_canonical_inputs':declared,'missing_declared_canonical_inputs':missing_decl,'missing_actual_canonical_inputs':missing_actual,'alternate_runtime_audits':alt,'blocks':blocks,'warnings':warnings,'decision':'BLOCK' if blocks else 'PASS'}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
