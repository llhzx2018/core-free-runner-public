#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

PHASES=('DISCOVER','DECIDE','PLAN','EXECUTE','VERIFY','RELEASE_OR_USE','OBSERVE','ITERATE')
PROJECT_REQUIRED=set(PHASES)-{'RELEASE_OR_USE'}
SKILL_REQUIRED={'DECIDE','PLAN','EXECUTE','VERIFY','ITERATE'}
PHASE_DEPTH_V54=('PROBLEM_DISCOVERY','OPPORTUNITY_SELECTION','ALTERNATIVE_PRESSURE','PREBUILD_VALIDATION','DEVELOPMENT_ENTRY_DECISION','SCOPE','BUILD','ACCEPTANCE','PRODUCTION','DISCOVERABILITY','ACTIVATION','OBSERVABILITY_DECISION')
PROJECT_CLASSES=(
 'evidence_capture','decision_record','plan_or_contract','execution_brief_or_log',
 'acceptance_record','baseline_snapshot','iteration_log','next_decision'
)
SKILL_CLASSES=('decision_record','plan_or_contract','execution_brief_or_log','acceptance_record','iteration_log')
TEXT_EXT={'.md','.markdown','.txt','.csv','.tsv'}

PROMISE_RESPONSIBILITIES={
 'real_world_delivery':{
   'keywords':('launch','deploy','publish','production','ship','release','go live','上线','部署','发布','交付','生产环境'),
   'dimensions':('candidate_identity','preview_vs_production','production_readback','rollback')},
 'access_identity_routing':{
   'keywords':('domain','dns','https','url','redirect','routing','域名','重定向'),
   'dimensions':('identity','routing','secure_access','negative_path')},
 'discoverability_distribution':{
   'keywords':('seo','search','index','search console','discoverability','distribution','搜索','收录','索引','发现'),
   'dimensions':('channel_access','index_or_distribution_control','diagnostic_surface','time_window')},
 'user_acquisition_activation':{
   'keywords':('first users','real users','acquisition','traffic','activation','首批用户','第一批用户','真实用户','获客','流量','激活'),
   'dimensions':('reach','start','value_action','feedback')},
 'observability_decision':{
   'keywords':('analytics','metric','data','signal','observe','decision','数据','信号','分析','指标','观察','决策'),
   'dimensions':('baseline','signal_interpretation','change_control','next_decision')},
 'rollback_recovery':{
   'keywords':('rollback','recovery','incident','回滚','恢复','故障'),
   'dimensions':('rollback_target','rollback_method','stateful_caveat','retest')},
}

PREBUILD_RESPONSIBILITIES={
 'problem_opportunity_selection':{
   'keywords':('problem','need','demand','idea','opportunity','pain','friction','问题','需求','点子','机会','痛点','摩擦'),
   'dimensions':('evidence_quality','alternative_candidates','selection_rule','rejection_rule')},
 'alternative_pressure':{
   'keywords':('competitor','competition','alternative','existing solution','supply','serp','竞品','竞争','替代','现有方案','供给','搜索结果'),
   'dimensions':('existing_supply','task_fit','switching_cost','disconfirming_evidence')},
 'prebuild_behavioral_validation':{
   'keywords':('validate','validation','prove demand','real need','behavior evidence','test demand','验证','伪需求','真实需求','行为证据','需求验证'),
   'dimensions':('critical_unknown','lightest_test','observable_behavior','decision_rule')},
 'development_entry_decision':{
   'keywords':('build','develop','mvp','implementation','launch','开发','构建','第一版','mvp','上线'),
   'dimensions':('entry_evidence','continue_rule','revise_pause_stop','next_risk')},
}
EARLY_PHASE_MAP={
 'problem_opportunity_selection':('PROBLEM_DISCOVERY','OPPORTUNITY_SELECTION'),
 'alternative_pressure':('ALTERNATIVE_PRESSURE',),
 'prebuild_behavioral_validation':('PREBUILD_VALIDATION',),
 'development_entry_decision':('DEVELOPMENT_ENTRY_DECISION',),
}

WEB_SIGNALS=('website','web site','site','webapp','web app','网站','网页','站点')
def infer_prebuild_responsibilities(rtc):
    text=reader_contract_text(rtc); required=set()
    for name,spec in PREBUILD_RESPONSIBILITIES.items():
        if any(k.lower() in text for k in spec['keywords']): required.add(name)
    practical=bool(str(rtc.get('BOOK_TYPE','')).upper()=='PRACTICAL_PROJECT') if isinstance(rtc,dict) else False
    buildish=any(k in text for k in ('build','develop','mvp','launch','ship','上线','开发','构建','第一版'))
    demandish=any(k in text for k in ('problem','need','demand','opportunity','问题','需求','机会','伪需求','真实需求'))
    web=any(k.lower() in text for k in WEB_SIGNALS)
    # First-principles coupling: a practical project that promises demand-to-build must not skip
    # opportunity selection, alternative pressure, pre-build behavior validation, or the entry gate.
    if practical and buildish and demandish:
        required.update({'problem_opportunity_selection','prebuild_behavioral_validation','development_entry_decision'})
        if web: required.add('alternative_pressure')
    return text,required

def semantic_signal_sufficient(kind,chars,sig,headings,min_chars,min_sig):
    if sig>=min_sig:return True,False
    margin=(kind!='chapter' and sig==min_sig-1 and chars>=min_chars and headings>=5)
    return margin,margin

def prebuild_check(root,rtc,contract,stage):
    text,required=infer_prebuild_responsibilities(rtc)
    rows=contract.get('prebuild_responsibilities',[]) if isinstance(contract,dict) else []
    idx={str(x.get('responsibility','')).lower():x for x in rows if isinstance(x,dict) and x.get('responsibility')}
    bad=[];details=[]
    used_assets={}
    for name in sorted(required):
        row=idx.get(name);spec=PREBUILD_RESPONSIBILITIES[name]
        if not row:
            bad.append({'responsibility':name,'reason':'INFERRED_PREBUILD_RESPONSIBILITY_MISSING'});continue
        app=str(row.get('applicability','REQUIRED')).upper();dims=[str(x) for x in row.get('dimensions',[]) if str(x).strip()]
        ch=[str(x) for x in row.get('chapter_paths',[]) if str(x).strip()];refs=[str(x) for x in row.get('operator_reference_paths',[]) if str(x).strip()];assets=[str(x) for x in row.get('asset_paths',[]) if str(x).strip()]
        fields={k:str(row.get(k,'')).strip() for k in ('judgment','execution','validation','failure_recovery','completion')};reasons=[]
        if app!='REQUIRED': reasons.append('INFERRED_PREBUILD_NOT_REQUIRED')
        miss=[d for d in spec['dimensions'] if d not in dims]
        if miss: reasons.append('PREBUILD_DIMENSIONS_MISSING:'+','.join(miss))
        if not ch: reasons.append('PREBUILD_NO_READING_CORE_MAPPING')
        if not refs: reasons.append('PREBUILD_NO_OPERATOR_REFERENCE_MAPPING')
        if not assets: reasons.append('PREBUILD_NO_PRACTICAL_ASSET_MAPPING')
        for k,v in fields.items():
            if len(v)<18: reasons.append('PREBUILD_'+k.upper()+'_TOO_THIN')
        checks=[]
        if stage=='PRE_FREEZE':
            for kind,paths,min_chars,min_sig in (('chapter',ch,1800,6),('operator_reference',refs,650,7),('asset',assets,700,8)):
                for rel in paths:
                    fp=locate(root,rel)
                    if not fp: reasons.append('PREBUILD_'+kind.upper()+'_PATH_MISSING:'+rel);continue
                    body=fp.read_text(encoding='utf-8',errors='replace');chars=len(compact(body));sig=sum(1 for x in PROMISE_SIGNALS if x.lower() in body.lower());headings=sum(1 for line in body.splitlines() if re.match(r'^#{2,4}\s+',line))
                    checks.append({'kind':kind,'path':rel,'chars':chars,'signals':sig,'headings':headings})
                    if chars<min_chars: reasons.append(f'PREBUILD_{kind.upper()}_DEPTH_LOW:{rel}:{chars}<{min_chars}')
                    ok_sig,margin=semantic_signal_sufficient(kind,chars,sig,headings,min_chars,min_sig)
                    if margin: checks[-1]['semantic_margin']='STRUCTURED_ONE_SIGNAL_MARGIN'
                    if not ok_sig: reasons.append(f'PREBUILD_{kind.upper()}_SIGNAL_LOW:{rel}:{sig}<{min_sig}')
                    if kind!='chapter' and headings<3: reasons.append(f'PREBUILD_{kind.upper()}_STRUCTURE_LOW:{rel}:{headings}<3')
        for rel in assets: used_assets.setdefault(rel,[]).append(name)
        item={'responsibility':name,'applicability':app,'dimensions':dims,'chapter_paths':ch,'operator_reference_paths':refs,'asset_paths':assets,**fields,'checks':checks,'reasons':reasons};details.append(item)
        if reasons: bad.append(item)
    for rel,names in used_assets.items():
        if len(names)>2:
            row=next((x for x in rows if isinstance(x,dict) and rel in (x.get('asset_paths') or [])),{})
            rationale=str(row.get('multi_role_rationale','')).strip()
            if len(rationale)<30: bad.append({'path':rel,'responsibilities':names,'reason':'PREBUILD_ASSET_OVER_COLLAPSED_WITHOUT_RATIONALE'})
    return {'inferred_required':sorted(required),'details':details,'reader_contract_signal_text_present':bool(text)},bad

def phase_depth_check(rtc,contract):
    book_type=str((contract or {}).get('book_type') or (rtc or {}).get('BOOK_TYPE') or '').upper()
    if book_type!='PRACTICAL_PROJECT':
        return {'inferred_required':[],'details':[],'applicability':'NOT_REQUIRED_FOR_'+(book_type or 'UNKNOWN')},[]
    rows=contract.get('phase_depth',[]) if isinstance(contract,dict) else []
    idx={str(x.get('phase','')).upper():x for x in rows if isinstance(x,dict) and x.get('phase')};bad=[]
    _,pre=infer_prebuild_responsibilities(rtc);_,prom=infer_promise_responsibilities(rtc)
    required=set()
    for r in pre: required.update(EARLY_PHASE_MAP.get(r,()))
    if 'real_world_delivery' in prom: required.update({'SCOPE','BUILD','ACCEPTANCE','PRODUCTION'})
    if 'discoverability_distribution' in prom: required.add('DISCOVERABILITY')
    if 'user_acquisition_activation' in prom: required.add('ACTIVATION')
    if 'observability_decision' in prom: required.add('OBSERVABILITY_DECISION')
    details=[]
    for phase in PHASE_DEPTH_V54:
        row=idx.get(phase)
        if not row:
            bad.append({'phase':phase,'reason':'MISSING_PHASE_DEPTH_ENTRY'});continue
        app=str(row.get('applicability','')).upper(); rationale=str(row.get('rationale','')).strip()
        if app not in {'REQUIRED','OPTIONAL','N_A','NA','N/A'}: bad.append({'phase':phase,'reason':'INVALID_PHASE_DEPTH_APPLICABILITY','value':app})
        if phase in required and app!='REQUIRED': bad.append({'phase':phase,'reason':'INFERRED_REQUIRED_PHASE_NOT_REQUIRED','value':app})
        if app in {'N_A','NA','N/A'} and len(rationale)<20: bad.append({'phase':phase,'reason':'PHASE_N_A_WITHOUT_TASK_RATIONALE'})
        details.append({'phase':phase,'applicability':app,'rationale':rationale})
    return {'inferred_required':sorted(required),'details':details},bad

PROMISE_SIGNALS=('判断','决策','规则','条件','输入','输出','执行','步骤','验证','验收','失败','恢复','重试','完成','状态','边界','decision','rule','input','output','execute','step','validation','acceptance','failure','recovery','retry','completion','state','boundary')

def reader_contract_text(rtc):
    bits=[]
    if isinstance(rtc,dict):
        for k,v in rtc.items():
            if isinstance(v,str):bits.append(v)
            elif isinstance(v,list):
                for x in v:
                    if isinstance(x,str):bits.append(x)
                    elif isinstance(x,dict):bits.extend(str(y) for y in x.values() if isinstance(y,(str,int,float)))
    return ' '.join(bits).lower()

def infer_promise_responsibilities(rtc):
    text=reader_contract_text(rtc); required=set()
    for name,spec in PROMISE_RESPONSIBILITIES.items():
        if any(k.lower() in text for k in spec['keywords']):required.add(name)
    web=any(k.lower() in text for k in WEB_SIGNALS)
    if 'real_world_delivery' in required:
        required.add('rollback_recovery')
        if web:required.add('access_identity_routing')
    if web and 'user_acquisition_activation' in required:required.add('discoverability_distribution')
    return text,required

def promise_check(root,rtc,contract,stage):
    text,required=infer_promise_responsibilities(rtc)
    rows=contract.get('promise_responsibilities',[]) if isinstance(contract,dict) else []
    idx={str(x.get('responsibility','')).lower():x for x in rows if isinstance(x,dict) and x.get('responsibility')}
    bad=[];details=[]
    for name in sorted(required):
        row=idx.get(name);spec=PROMISE_RESPONSIBILITIES[name]
        if not row:
            bad.append({'responsibility':name,'reason':'INFERRED_BOOK_PROMISE_RESPONSIBILITY_MISSING'});continue
        app=str(row.get('applicability','REQUIRED')).upper()
        dims=[str(x) for x in row.get('dimensions',[]) if str(x).strip()]
        ch=[str(x) for x in row.get('chapter_paths',[]) if str(x).strip()]
        refs=[str(x) for x in row.get('operator_reference_paths',[]) if str(x).strip()]
        assets=[str(x) for x in row.get('asset_paths',[]) if str(x).strip()]
        fields={k:str(row.get(k,'')).strip() for k in ('judgment','execution','validation','failure_recovery','completion')}
        reasons=[]
        if app!='REQUIRED':reasons.append('INFERRED_PROMISE_NOT_REQUIRED')
        miss=[d for d in spec['dimensions'] if d not in dims]
        if miss:reasons.append('PROMISE_DIMENSIONS_MISSING:'+','.join(miss))
        if not ch:reasons.append('PROMISE_NO_READING_CORE_MAPPING')
        if not refs:reasons.append('PROMISE_NO_OPERATOR_REFERENCE_MAPPING')
        if not assets:reasons.append('PROMISE_NO_PRACTICAL_ASSET_MAPPING')
        for k,v in fields.items():
            if len(v)<18:reasons.append('PROMISE_'+k.upper()+'_TOO_THIN')
        checks=[]
        if stage=='PRE_FREEZE':
            for kind,paths,min_chars,min_sig in (('chapter',ch,1800,6),('operator_reference',refs,650,7),('asset',assets,650,7)):
                for rel in paths:
                    fp=locate(root,rel)
                    if not fp:
                        reasons.append('PROMISE_'+kind.upper()+'_PATH_MISSING:'+rel);continue
                    body=fp.read_text(encoding='utf-8',errors='replace');chars=len(compact(body));sig=sum(1 for x in PROMISE_SIGNALS if x.lower() in body.lower())
                    headings=sum(1 for line in body.splitlines() if re.match(r'^#{2,4}\s+',line))
                    checks.append({'kind':kind,'path':rel,'chars':chars,'signals':sig,'headings':headings})
                    if chars<min_chars:reasons.append(f'PROMISE_{kind.upper()}_DEPTH_LOW:{rel}:{chars}<{min_chars}')
                    ok_sig,margin=semantic_signal_sufficient(kind,chars,sig,headings,min_chars,min_sig)
                    if margin:checks[-1]['semantic_margin']='STRUCTURED_ONE_SIGNAL_MARGIN'
                    if not ok_sig:reasons.append(f'PROMISE_{kind.upper()}_SIGNAL_LOW:{rel}:{sig}<{min_sig}')
                    if kind!='chapter' and headings<3:reasons.append(f'PROMISE_{kind.upper()}_STRUCTURE_LOW:{rel}:{headings}<3')
        item={'responsibility':name,'applicability':app,'dimensions':dims,'chapter_paths':ch,'operator_reference_paths':refs,'asset_paths':assets,**fields,'checks':checks,'reasons':reasons}
        details.append(item)
        if reasons:bad.append(item)
    # If the contract declares promise rows that are not inferred, retain them as optional visible declarations but do not fail.
    return {'inferred_required':sorted(required),'details':details,'reader_contract_signal_text_present':bool(text)},bad


def infer_prebuild_responsibilities(rtc):
    text=reader_contract_text(rtc); required=set()
    for name,spec in PREBUILD_RESPONSIBILITIES.items():
        if any(k.lower() in text for k in spec['keywords']): required.add(name)
    practical=bool(str(rtc.get('BOOK_TYPE','')).upper()=='PRACTICAL_PROJECT') if isinstance(rtc,dict) else False
    buildish=any(k in text for k in ('build','develop','mvp','launch','ship','上线','开发','构建','第一版'))
    demandish=any(k in text for k in ('problem','need','demand','opportunity','问题','需求','机会','伪需求','真实需求'))
    web=any(k.lower() in text for k in WEB_SIGNALS)
    # First-principles coupling: a practical project that promises demand-to-build must not skip
    # opportunity selection, alternative pressure, pre-build behavior validation, or the entry gate.
    if practical and buildish and demandish:
        required.update({'problem_opportunity_selection','prebuild_behavioral_validation','development_entry_decision'})
        if web: required.add('alternative_pressure')
    return text,required

def prebuild_check(root,rtc,contract,stage):
    text,required=infer_prebuild_responsibilities(rtc)
    rows=contract.get('prebuild_responsibilities',[]) if isinstance(contract,dict) else []
    idx={str(x.get('responsibility','')).lower():x for x in rows if isinstance(x,dict) and x.get('responsibility')}
    bad=[];details=[]
    used_assets={}
    for name in sorted(required):
        row=idx.get(name);spec=PREBUILD_RESPONSIBILITIES[name]
        if not row:
            bad.append({'responsibility':name,'reason':'INFERRED_PREBUILD_RESPONSIBILITY_MISSING'});continue
        app=str(row.get('applicability','REQUIRED')).upper();dims=[str(x) for x in row.get('dimensions',[]) if str(x).strip()]
        ch=[str(x) for x in row.get('chapter_paths',[]) if str(x).strip()];refs=[str(x) for x in row.get('operator_reference_paths',[]) if str(x).strip()];assets=[str(x) for x in row.get('asset_paths',[]) if str(x).strip()]
        fields={k:str(row.get(k,'')).strip() for k in ('judgment','execution','validation','failure_recovery','completion')};reasons=[]
        if app!='REQUIRED': reasons.append('INFERRED_PREBUILD_NOT_REQUIRED')
        miss=[d for d in spec['dimensions'] if d not in dims]
        if miss: reasons.append('PREBUILD_DIMENSIONS_MISSING:'+','.join(miss))
        if not ch: reasons.append('PREBUILD_NO_READING_CORE_MAPPING')
        if not refs: reasons.append('PREBUILD_NO_OPERATOR_REFERENCE_MAPPING')
        if not assets: reasons.append('PREBUILD_NO_PRACTICAL_ASSET_MAPPING')
        for k,v in fields.items():
            if len(v)<18: reasons.append('PREBUILD_'+k.upper()+'_TOO_THIN')
        checks=[]
        if stage=='PRE_FREEZE':
            for kind,paths,min_chars,min_sig in (('chapter',ch,1800,6),('operator_reference',refs,650,7),('asset',assets,700,8)):
                for rel in paths:
                    fp=locate(root,rel)
                    if not fp: reasons.append('PREBUILD_'+kind.upper()+'_PATH_MISSING:'+rel);continue
                    body=fp.read_text(encoding='utf-8',errors='replace');chars=len(compact(body));sig=sum(1 for x in PROMISE_SIGNALS if x.lower() in body.lower());headings=sum(1 for line in body.splitlines() if re.match(r'^#{2,4}\s+',line))
                    checks.append({'kind':kind,'path':rel,'chars':chars,'signals':sig,'headings':headings})
                    if chars<min_chars: reasons.append(f'PREBUILD_{kind.upper()}_DEPTH_LOW:{rel}:{chars}<{min_chars}')
                    ok_sig,margin=semantic_signal_sufficient(kind,chars,sig,headings,min_chars,min_sig)
                    if margin: checks[-1]['semantic_margin']='STRUCTURED_ONE_SIGNAL_MARGIN'
                    if not ok_sig: reasons.append(f'PREBUILD_{kind.upper()}_SIGNAL_LOW:{rel}:{sig}<{min_sig}')
                    if kind!='chapter' and headings<3: reasons.append(f'PREBUILD_{kind.upper()}_STRUCTURE_LOW:{rel}:{headings}<3')
        for rel in assets: used_assets.setdefault(rel,[]).append(name)
        item={'responsibility':name,'applicability':app,'dimensions':dims,'chapter_paths':ch,'operator_reference_paths':refs,'asset_paths':assets,**fields,'checks':checks,'reasons':reasons};details.append(item)
        if reasons: bad.append(item)
    for rel,names in used_assets.items():
        if len(names)>2:
            row=next((x for x in rows if isinstance(x,dict) and rel in (x.get('asset_paths') or [])),{})
            rationale=str(row.get('multi_role_rationale','')).strip()
            if len(rationale)<30: bad.append({'path':rel,'responsibilities':names,'reason':'PREBUILD_ASSET_OVER_COLLAPSED_WITHOUT_RATIONALE'})
    return {'inferred_required':sorted(required),'details':details,'reader_contract_signal_text_present':bool(text)},bad

def phase_depth_check(rtc,contract):
    book_type=str((contract or {}).get('book_type') or (rtc or {}).get('BOOK_TYPE') or '').upper()
    if book_type!='PRACTICAL_PROJECT':
        return {'inferred_required':[],'details':[],'applicability':'NOT_REQUIRED_FOR_'+(book_type or 'UNKNOWN')},[]
    rows=contract.get('phase_depth',[]) if isinstance(contract,dict) else []
    idx={str(x.get('phase','')).upper():x for x in rows if isinstance(x,dict) and x.get('phase')};bad=[]
    _,pre=infer_prebuild_responsibilities(rtc);_,prom=infer_promise_responsibilities(rtc)
    required=set()
    for r in pre: required.update(EARLY_PHASE_MAP.get(r,()))
    if 'real_world_delivery' in prom: required.update({'SCOPE','BUILD','ACCEPTANCE','PRODUCTION'})
    if 'discoverability_distribution' in prom: required.add('DISCOVERABILITY')
    if 'user_acquisition_activation' in prom: required.add('ACTIVATION')
    if 'observability_decision' in prom: required.add('OBSERVABILITY_DECISION')
    details=[]
    for phase in PHASE_DEPTH_V54:
        row=idx.get(phase)
        if not row:
            bad.append({'phase':phase,'reason':'MISSING_PHASE_DEPTH_ENTRY'});continue
        app=str(row.get('applicability','')).upper(); rationale=str(row.get('rationale','')).strip()
        if app not in {'REQUIRED','OPTIONAL','N_A','NA','N/A'}: bad.append({'phase':phase,'reason':'INVALID_PHASE_DEPTH_APPLICABILITY','value':app})
        if phase in required and app!='REQUIRED': bad.append({'phase':phase,'reason':'INFERRED_REQUIRED_PHASE_NOT_REQUIRED','value':app})
        if app in {'N_A','NA','N/A'} and len(rationale)<20: bad.append({'phase':phase,'reason':'PHASE_N_A_WITHOUT_TASK_RATIONALE'})
        details.append({'phase':phase,'applicability':app,'rationale':rationale})
    return {'inferred_required':sorted(required),'details':details},bad

SIGNALS=('判断','决策','规则','条件','输入','输出','步骤','执行','验证','验收','失败','恢复','重试','完成','decision','rule','input','output','step','validation','failure','retry','completion')

def semantic_signal_sufficient(kind,chars,sig,headings,min_chars,min_sig):
    if sig>=min_sig:return True,False
    margin=(kind!='chapter' and sig==min_sig-1 and chars>=min_chars and headings>=5)
    return margin,margin


def read_json(p:Path):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return None
def norm(s):return re.sub(r'\s+',' ',str(s).strip().lower())
def compact(s):return re.sub(r'\s+','',s)
def item_id(x, prefix, i):
    if isinstance(x,dict):
        return str(x.get('id') or x.get('capability_id') or f'{prefix}_{i}')
    return f'{prefix}_{i}'
def item_statement(x):
    if isinstance(x,dict):return str(x.get('statement') or x.get('text') or x.get('capability') or '')
    return str(x)
def key_for(x,prefix,i):
    ident=item_id(x,prefix,i).strip();stmt=item_statement(x).strip()
    return ident if ident else norm(stmt)
def locate(root:Path, rel):
    p=root/str(rel);return p if p.is_file() else None

def mapping_index(contract):
    out={}
    for row in contract.get('capability_mappings',[]) if isinstance(contract,dict) else []:
        if not isinstance(row,dict):continue
        keys=[str(row.get('capability_id') or '').strip(), norm(row.get('statement') or row.get('capability') or '')]
        for k in keys:
            if k:out[k]=row
    return out

def lifecycle_check(contract, book_type):
    rows=contract.get('lifecycle',[]) if isinstance(contract,dict) else []
    idx={str(x.get('phase','')).upper():x for x in rows if isinstance(x,dict) and x.get('phase')};bad=[]
    for phase in PHASES:
        row=idx.get(phase)
        if not row:
            bad.append({'phase':phase,'reason':'MISSING_PHASE_ENTRY'});continue
        app=str(row.get('applicability','')).upper()
        if app not in {'REQUIRED','OPTIONAL','N_A','NA','N/A'}:
            bad.append({'phase':phase,'reason':'INVALID_APPLICABILITY','value':app});continue
        required=(book_type=='PRACTICAL_PROJECT' and phase in PROJECT_REQUIRED) or (book_type=='PRACTICAL_SKILL' and phase in SKILL_REQUIRED)
        if required and app!='REQUIRED':bad.append({'phase':phase,'reason':'REQUIRED_PHASE_NOT_REQUIRED','value':app})
        if app in {'N_A','NA','N/A'} and len(str(row.get('rationale','')).strip())<20:bad.append({'phase':phase,'reason':'N_A_WITHOUT_TASK_RATIONALE'})
    return rows,bad

def class_check(root,contract,book_type,stage):
    need=PROJECT_CLASSES if book_type=='PRACTICAL_PROJECT' else SKILL_CLASSES if book_type=='PRACTICAL_SKILL' else ()
    rows=contract.get('operator_responsibility_classes',[]) if isinstance(contract,dict) else []
    idx={str(x.get('class','')).lower():x for x in rows if isinstance(x,dict) and x.get('class')};bad=[];details=[]
    for cls in need:
        row=idx.get(cls)
        if not row:
            bad.append({'class':cls,'reason':'MISSING_RESPONSIBILITY_CLASS'});continue
        app=str(row.get('applicability','REQUIRED')).upper()
        if app!='REQUIRED':
            bad.append({'class':cls,'reason':'REQUIRED_CLASS_NOT_REQUIRED','value':app});continue
        assets=[str(x) for x in row.get('asset_paths',[]) if str(x).strip()]
        if not assets:
            bad.append({'class':cls,'reason':'NO_ASSET_MAPPING'});continue
        item={'class':cls,'asset_paths':assets,'checks':[]}
        if stage=='PRE_FREEZE':
            for rel in assets:
                p=locate(root,rel)
                if not p:
                    bad.append({'class':cls,'path':rel,'reason':'MAPPED_ASSET_MISSING'});continue
                s=p.read_text(encoding='utf-8',errors='replace');chars=len(compact(s));sig=sum(1 for x in SIGNALS if x.lower() in s.lower())
                min_chars=180 if cls in {'evidence_capture','baseline_snapshot'} else 420
                min_sig=3 if cls in {'evidence_capture','baseline_snapshot'} else 5
                reasons=[]
                if chars<min_chars:reasons.append(f'ASSET_SHELL_RISK:{chars}<{min_chars}')
                if sig<min_sig:reasons.append(f'ASSET_RESPONSIBILITY_SIGNAL_LOW:{sig}<{min_sig}')
                item['checks'].append({'path':rel,'chars':chars,'signals':sig,'reasons':reasons})
                if reasons:bad.append({'class':cls,'path':rel,'reason':'ASSET_NOT_SELF_SUFFICIENT','details':reasons})
        details.append(item)
    if need:
        uniq={p for row in rows if isinstance(row,dict) for p in row.get('asset_paths',[]) if p};floor=5 if book_type=='PRACTICAL_PROJECT' else 3
        if len(uniq)<floor:bad.append({'reason':'RESPONSIBILITY_CLASSES_OVER_COLLAPSED','unique_assets':len(uniq),'floor':floor})
    return details,bad

def capability_check(root,rtc,contract,stage):
    mi=mapping_index(contract);bad=[];rows=[];specs=[]
    for kind,key in (('JUDGE','MUST_BE_ABLE_TO_JUDGE'),('DO','MUST_BE_ABLE_TO_DO')):
        for i,x in enumerate(rtc.get(key,[]) if isinstance(rtc,dict) else [],1):specs.append((kind,key_for(x,key,i),item_statement(x),x))
    if not specs:bad.append({'reason':'NO_CRITICAL_READER_CAPABILITIES'})
    for kind,k,stmt,raw in specs:
        row=mi.get(k) or mi.get(norm(stmt))
        if not row:
            item={'kind':kind,'capability':k,'statement':stmt,'reason':'CAPABILITY_UNMAPPED'};bad.append(item);rows.append(item);continue
        ch=[str(x) for x in row.get('chapter_paths',[]) if str(x).strip()];assets=[str(x) for x in row.get('asset_paths',[]) if str(x).strip()];reasons=[]
        if not ch:reasons.append('NO_CHAPTER_MAPPING')
        if kind=='DO' and not assets:reasons.append('DO_WITHOUT_PRACTICAL_ASSET')
        if stage=='PRE_FREEZE':
            for rel in ch:
                p=locate(root,rel)
                if not p:reasons.append('CHAPTER_PATH_MISSING:'+rel)
                else:
                    s=p.read_text(encoding='utf-8',errors='replace');sig=sum(1 for x in SIGNALS if x.lower() in s.lower())
                    if sig<4:reasons.append('CHAPTER_RESPONSIBILITY_SIGNAL_LOW:'+rel)
            for rel in assets:
                if not locate(root,rel):reasons.append('ASSET_PATH_MISSING:'+rel)
        item={'kind':kind,'capability':k,'statement':stmt,'chapter_paths':ch,'asset_paths':assets,'reasons':reasons};rows.append(item)
        if reasons:bad.append(item)
    return rows,bad

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--stage',required=True,choices=['PRE_DRAFT','PRE_FREEZE']);ap.add_argument('--json');a=ap.parse_args()
    root=Path(a.new);blocks=[];rtc_path=root/'evidence'/'reader_transformation_contract.json';con_path=root/'evidence'/'generation_responsibility_contract.json'
    rtc=read_json(rtc_path) if rtc_path.exists() else None;con=read_json(con_path) if con_path.exists() else None
    if not rtc:blocks.append('READER_TRANSFORMATION_MACHINE_CONTRACT_MISSING_OR_INVALID');rtc={}
    if not con:blocks.append('GENERATION_RESPONSIBILITY_CONTRACT_MISSING_OR_INVALID');con={}
    book_type=str(con.get('book_type') or rtc.get('BOOK_TYPE') or '').upper()
    if book_type not in {'PRACTICAL_PROJECT','PRACTICAL_SKILL','CONCEPTUAL_REFERENCE'}:blocks.append('BOOK_TYPE_MISSING_OR_INVALID')
    lrows,lbad=lifecycle_check(con,book_type);crows,cbad=capability_check(root,rtc,con,a.stage);arows,abad=class_check(root,con,book_type,a.stage);prows,pbad=promise_check(root,rtc,con,a.stage);pre_rows,pre_bad=prebuild_check(root,rtc,con,a.stage);phase_rows,phase_bad=phase_depth_check(rtc,con)
    if lbad:blocks.append('LIFECYCLE_RESPONSIBILITY_GAP')
    if cbad:blocks.append('CRITICAL_CAPABILITY_TRACEABILITY_GAP')
    if abad:blocks.append('OPERATOR_RESPONSIBILITY_CLASS_GAP')
    if pbad:blocks.append('BOOK_PROMISE_RESPONSIBILITY_GAP')
    if pre_bad:blocks.append('PREBUILD_RESPONSIBILITY_GAP')
    if phase_bad:blocks.append('PHASE_DEPTH_PRESERVATION_GAP')
    blocks=list(dict.fromkeys(blocks))
    report={'version':'V5.4_GENERATION_RESPONSIBILITY_AUDIT','stage':a.stage,'book_type':book_type or None,'reader_contract':str(rtc_path),'responsibility_contract':str(con_path),'lifecycle':{'details':lrows,'failures':lbad},'capability_traceability':{'details':crows,'failures':cbad},'operator_responsibility_classes':{'details':arows,'failures':abad},'book_promise_responsibilities':{**prows,'failures':pbad},'prebuild_responsibilities':{**pre_rows,'failures':pre_bad},'phase_depth':{**phase_rows,'failures':phase_bad},'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
    if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
