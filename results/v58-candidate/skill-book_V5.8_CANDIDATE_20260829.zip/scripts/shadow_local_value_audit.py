#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,random,re
from pathlib import Path
CUES=('判断','规则','条件','动作','执行','验证','验收','恢复','重试','完成','状态','输入','输出','证据','失败','错误','下一步','decision','rule','action','execute','validation','acceptance','recovery','retry','completion','status','input','output','evidence','failure','error','next')
def cid(p):
 m=re.match(r'^0*(\d{1,3})[_ .-]',p.name)
 if m:return int(m.group(1))
 m=re.search(r'第\s*0*(\d{1,3})\s*章',p.stem);return int(m.group(1)) if m else None
def compact(s):return re.sub(r'\s+','',s)
def paths(root):
 out=[]
 for d in (root/'chapters',root/'manuscript',root/'book'/'chapters'):
  if d.exists():out += [('chapter',p) for p in d.glob('*.md') if cid(p)]
 for d in (root/'templates',root/'operator_reference',root/'references'/'operator',root/'references'/'operator_reference'):
  if d.exists():out += [('asset',p) for p in d.iterdir() if p.is_file() and p.suffix.lower() in {'.md','.txt','.csv','.tsv'}]
 return sorted(set(out),key=lambda x:x[1].as_posix())
def h2(text):
 chunks=[];cur=[]
 for line in text.splitlines():
  if re.match(r'^##\s+',line):
   if cur:chunks.append('\n'.join(cur))
   cur=[line]
  elif cur:cur.append(line)
 if cur:chunks.append('\n'.join(cur))
 return [x for x in chunks if compact(x)]
def paras(text):return [x.strip() for x in re.split(r'\n\s*\n',text) if len(compact(x.strip()))>=40]
def bounded(parts,idx,target=360,max_parts=3):
 chosen=[idx];step=1
 while parts and len(chosen)<max_parts and len(compact('\n\n'.join(parts[i] for i in sorted(chosen))))<target:
  cand=[]
  if idx-step>=0:cand.append(idx-step)
  if idx+step<len(parts):cand.append(idx+step)
  if not cand:break
  for j in cand:
   if j not in chosen and len(chosen)<max_parts:chosen.append(j)
  step+=1
 return '\n\n'.join(parts[i] for i in sorted(chosen)) if parts else ''
def judge(chunk,kind,full):
 chars=len(compact(chunk));hits=sum(1 for x in CUES if x.lower() in chunk.lower());reasons=[];floor=210 if kind=='chapter' else 260;need=3 if kind=='chapter' else 4
 structure=sum(bool(re.match(r'^(?:#{2,4}\s+|\s*[-*]\s+|\s*\d+[.)]\s+|\|.*\|$)',x)) for x in full.splitlines() if x.strip()) if kind!='chapter' else 0
 local_h2=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in chunk.splitlines() if x.strip()) if kind!='chapter' else 0
 full_h2=sum(bool(re.match(r'^#{2,4}\s+',x)) for x in full.splitlines() if x.strip()) if kind!='chapter' else 0
 short_margin=(kind!='chapter' and chars>=int(floor*0.90) and hits>=need and structure>=3)
 form_margin=(kind!='chapter' and len(compact(full))>=700 and full_h2>=7 and chars>=150 and local_h2>=5 and hits>=need+2)
 if chars<floor and not (short_margin or form_margin):reasons.append(f'TOO_THIN:{chars}<{floor}')
 semantic_structure_margin=(kind!='chapter' and chars>=floor*2 and hits>=2 and structure>=5)
 if hits<need and not semantic_structure_margin:reasons.append(f'LOW_ACTION_DECISION_CUES:{hits}<{need}')
 if kind!='chapter' and structure<3:reasons.append(f'LOW_TOOL_STRUCTURE:{structure}<3')
 return reasons
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new);pool=paths(root);rows=[]
 for i in range(12):
  r=random.Random(50300+i)
  if not pool:break
  kind,p=r.choice(pool);text=p.read_text(encoding='utf-8',errors='replace');parts=h2(text) if kind=='chapter' else (h2(text) or paras(text))
  if parts:
   idx=r.randrange(len(parts));max_parts=3 if kind=='chapter' else 7;chunk=bounded(parts,idx,360,max_parts)
  else:idx=0;chunk=text;max_parts=1
  why=judge(chunk,kind,text);rows.append({'seed':50300+i,'kind':kind,'path':p.relative_to(root).as_posix(),'window_index':idx,'bounded_parts_max':max_parts,'chars':len(compact(chunk)),'result':'FAIL' if why else 'PASS','reasons':why})
 fails=[x for x in rows if x['result']=='FAIL'];blocks=[]
 if not rows:blocks.append('NO_READER_PATHS')
 if fails:blocks.append('SHADOW_LOCAL_VALUE_FAIL')
 report={'version':'V5.5_SHADOW_LOCAL_VALUE_AUDIT','context_policy':'CHAPTER_MAX_3_ASSET_MAX_7_STRUCTURED_FORM_MARGIN','samples':len(rows),'failed':len(fails),'details':rows,'blocks':blocks,'decision':'BLOCK' if blocks else 'PASS'}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
