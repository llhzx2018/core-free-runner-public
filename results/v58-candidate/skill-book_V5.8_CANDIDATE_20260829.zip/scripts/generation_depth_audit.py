#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path
REQ=('Reader Entry','Chapter Job','Must Explain','Must Judge','Must Demonstrate','Worked Example','Practice','Feedback','Failure Recovery','Completion Criteria','Operator Reference Scope','Template/Worksheet Scope','Promise Responsibility IDs','Operator Depth Bundle','Random Open Value Promise')

def cid(p):
 for pat in (r'^0*(\d{1,3})$',r'^0*(\d{1,3})[_ .-]',r'^chapter[_ .-]*0*(\d{1,3})\b',r'第\s*0*(\d{1,3})\s*章'):
  m=re.search(pat,p.stem,re.I)
  if m:return int(m.group(1))
 return None

def chapter_files(root):
 out=[]
 for d in (root/'manuscript',root/'chapters',root/'book'/'chapters'):
  if d.exists():out += [p for p in d.glob('*.md') if cid(p)]
 return sorted(set(out),key=lambda p:(cid(p) or 999,p.as_posix()))

def plan_files(root):
 out=[]
 for d in (root/'depth_plan',root/'evidence'/'depth_plan',root/'governance'/'depth_plan'):
  if d.exists():out += list(d.glob('*.md'))
 return sorted(set(out))

def aggregate_plan(root):
 candidates=(
  root/'frontmatter'/'06_generation_depth_plan.md',root/'frontmatter'/'generation_depth_plan.md',root/'generation_depth_plan.md',
  root/'governance'/'DEPTH_PLAN.md',root/'governance'/'generation_depth_plan.md',root/'evidence'/'DEPTH_PLAN.md'
 )
 for p in candidates:
  if p.exists():return p
 return None

def aggregate_sections(s):
 pats=[r'^##\s+(?:Ch(?:apter)?\s*)?0*(\d{1,3})\b.*$',r'^##\s*第\s*0*(\d{1,3})\s*章.*$']
 starts=[]
 for pat in pats:starts += list(re.finditer(pat,s,re.I|re.M))
 starts=sorted(starts,key=lambda m:m.start())
 out=[]
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else len(s);out.append((int(m.group(1)),s[m.start():end]))
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--new',required=True);ap.add_argument('--expected-chapters',type=int,required=True);ap.add_argument('--json');a=ap.parse_args();root=Path(a.new)
 plans=plan_files(root);chapters=chapter_files(root);weak=[];coverage=0;source='individual';source_path=None
 if plans:
  coverage=len(plans);source_path=';'.join(p.relative_to(root).as_posix() for p in plans)
  for p in plans:
   s=p.read_text(encoding='utf-8',errors='replace');miss=[x for x in REQ if x.lower() not in s.lower()]
   if 'Template/Worksheet Scope' in miss and 'template scope' in s.lower():miss.remove('Template/Worksheet Scope')
   if miss:weak.append({'path':p.relative_to(root).as_posix(),'missing':miss})
 else:
  apath=aggregate_plan(root);source='aggregate' if apath else 'missing';source_path=apath.relative_to(root).as_posix() if apath else None
  if apath:
   secs=aggregate_sections(apath.read_text(encoding='utf-8',errors='replace'));coverage=len(secs)
   for num,s in secs:
    miss=[x for x in REQ if x.lower() not in s.lower()]
    if 'Template/Worksheet Scope' in miss and 'template scope' in s.lower():miss.remove('Template/Worksheet Scope')
    if miss:weak.append({'chapter':num,'missing':miss})
 blocks=[]
 if coverage!=a.expected_chapters:blocks.append('DEPTH_PLAN_COVERAGE')
 if len(chapters)!=a.expected_chapters:blocks.append('CHAPTER_COVERAGE')
 if weak:blocks.append('DEPTH_PLAN_REQUIRED_FIELDS')
 report={'version':'V5.4_GENERATION_DEPTH_AUDIT','depth_plan_source':source,'depth_plan_path':source_path,'depth_plans':coverage,'chapters':len(chapters),'chapter_paths':[p.relative_to(root).as_posix() for p in chapters],'weak_plans':weak,'decision':'BLOCK' if blocks else 'PASS','blocks':blocks}
 if a.json:Path(a.json).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if blocks else 0
if __name__=='__main__':raise SystemExit(main())
